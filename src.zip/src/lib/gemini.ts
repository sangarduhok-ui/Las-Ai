const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Models tried in priority order for the grapher (fastest/most available first)
const GRAPHER_MODELS = ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-2.5-flash"];

export async function fetchGemini(body: Record<string, unknown>): Promise<Response> {
  const keys = [process.env.GEMINI_API_KEY_1, process.env.GEMINI_API_KEY_2].filter(
    Boolean,
  ) as string[];

  if (keys.length === 0) {
    throw new Error(
      "No AI API key found. Please configure GEMINI_API_KEY_1 or GEMINI_API_KEY_2 in your .env file.",
    );
  }

  let lastError: unknown = null;
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    const url = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";

    try {
      console.log(`Attempting request with key index ${i + 1} to Gemini Direct...`);

      let resp = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (resp.status === 429 || resp.status === 503) {
        console.warn(`Gemini Direct request with key index ${i + 1} failed with ${resp.status}. Retrying in 2 seconds...`);
        await delay(2000);
        resp = await fetch(url, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
        });
      }

      if (resp.ok) {
        return resp; // Return the successful response
      }

      const status = resp.status;
      const text = await resp.text();
      console.error(
        `Gemini request with key index ${i + 1} failed: status=${status}, body=${text}`,
      );

      lastError = { status, text };
    } catch (e) {
      console.error(`Gemini request with key index ${i + 1} threw network error:`, e);
      lastError = e;
    }
  }

  // All keys failed
  const lastErrorObj = lastError as Record<string, unknown> | null;
  const errMsg =
    lastErrorObj && typeof lastErrorObj === "object" && "text" in lastErrorObj
      ? String(lastErrorObj.text)
      : lastError instanceof Error
        ? lastError.message
        : "All Gemini API keys failed.";
  const errStatus =
    lastErrorObj && typeof lastErrorObj === "object" && "status" in lastErrorObj
      ? Number(lastErrorObj.status)
      : 500;

  // Create a mock failed response so the handlers can catch it nicely
  return new Response(
    JSON.stringify({ error: `All keys failed. Status ${errStatus}: ${errMsg}` }),
    {
      status: errStatus,
      headers: { "Content-Type": "application/json" },
    },
  );
}

/**
 * Specialized fetch for the grapher tool: tries fast models in sequence
 * (gemini-2.0-flash → gemini-1.5-flash → gemini-2.5-flash) to find one
 * that is available and returns quickly.
 */
export async function fetchGeminiForGrapher(
  body: Record<string, unknown>
): Promise<Response> {
  const keys = [process.env.GEMINI_API_KEY_1, process.env.GEMINI_API_KEY_2].filter(
    Boolean,
  ) as string[];

  if (keys.length === 0) {
    throw new Error("No AI API key found.");
  }

  const url = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions";

  for (const model of GRAPHER_MODELS) {
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const reqBody = { ...body, model };
      try {
        console.log(`[grapher] Trying model=${model} key=${i + 1}...`);
        let resp = await fetch(url, {
          method: "POST",
          headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify(reqBody),
        });

        if (resp.status === 429 || resp.status === 503) {
          console.warn(`[grapher] model=${model} key=${i + 1} got ${resp.status}, retrying after 1s...`);
          await delay(1000);
          resp = await fetch(url, {
            method: "POST",
            headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
            body: JSON.stringify(reqBody),
          });
        }

        if (resp.ok) {
          console.log(`[grapher] Success with model=${model} key=${i + 1}`);
          return resp;
        }

        const status = resp.status;
        const text = await resp.text();
        console.warn(`[grapher] model=${model} key=${i + 1} failed: status=${status}`);

        // On 503 try next model immediately
        if (status === 503) break;
      } catch (e) {
        console.error(`[grapher] model=${model} key=${i + 1} network error:`, e);
      }
    }
  }

  return new Response(
    JSON.stringify({ error: "All grapher models/keys failed." }),
    { status: 503, headers: { "Content-Type": "application/json" } },
  );
}

export async function fetchGeminiNative(body: Record<string, unknown>): Promise<Response> {
  const keys = [process.env.GEMINI_API_KEY_1, process.env.GEMINI_API_KEY_2].filter(
    Boolean,
  ) as string[];

  if (keys.length === 0) {
    throw new Error(
      "No AI API key found. Please configure GEMINI_API_KEY_1 or GEMINI_API_KEY_2 in your .env file.",
    );
  }

  let lastError: unknown = null;
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`;

    try {
      console.log(`Attempting request with key index ${i + 1} to Gemini Native...`);

      let resp = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (resp.status === 429) {
        console.warn(`Gemini Native request with key index ${i + 1} failed with 429. Retrying in 2 seconds...`);
        await delay(2000);
        resp = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
        });
      }

      if (resp.ok) {
        return resp; // Return the successful response
      }

      const status = resp.status;
      const text = await resp.text();
      console.error(
        `Gemini request with key index ${i + 1} failed: status=${status}, body=${text}`,
      );

      lastError = { status, text };
    } catch (e) {
      console.error(`Gemini request with key index ${i + 1} threw network error:`, e);
      lastError = e;
    }
  }

  // All keys failed
  const lastErrorObj = lastError as Record<string, unknown> | null;
  const errMsg =
    lastErrorObj && typeof lastErrorObj === "object" && "text" in lastErrorObj
      ? String(lastErrorObj.text)
      : lastError instanceof Error
        ? lastError.message
        : "All Gemini API keys failed.";
  const errStatus =
    lastErrorObj && typeof lastErrorObj === "object" && "status" in lastErrorObj
      ? Number(lastErrorObj.status)
      : 500;

  // Create a mock failed response
  return new Response(
    JSON.stringify({ error: `All keys failed. Status ${errStatus}: ${errMsg}` }),
    {
      status: errStatus,
      headers: { "Content-Type": "application/json" },
    },
  );
}

