import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef, lazy, Suspense, useMemo } from "react";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  Layers,
  LineChart,
  Languages,
  PenTool,
  FileAudio,
  BookOpen,
  Sparkles,
  Zap,
  Check,
  Crown,
  MessageCircle,
  FileText,
  Brain,
  Menu,
  X,
  GraduationCap,
  Wand2,
  ScanLine,
  CalendarCheck,
  ListOrdered,
  Sigma,
  Video,
  ClipboardCheck,
  BookA,
  ShieldCheck,
  FileSearch,
  Mail,
  Instagram,
  Facebook,
  FilePlus2,
  Scissors,
  FileDown,
  FileType2,
  Presentation,
  Table2,
  RotateCw,
  RefreshCw,
  Minimize2,
  Lock,
  Stamp,
  Search,
  Loader2,
  Download,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Home,
  Microscope,
  Library,
  BookMarked,
  Quote,
  Binary,
  FileCode,
  Code2,
  Calculator,
  HelpCircle,
  QrCode,
  Scan,
  Hash,
  Globe,
  Fingerprint,
  ShieldAlert,
  Receipt,
  ShoppingCart,
  Truck,
  FileSpreadsheet,
  TrendingUp,
  Percent,
  Wallet,
  Tag,
  CreditCard,
  ArrowRightLeft,
  Target,
  BarChart3,
  Coins,
  Users,
} from "lucide-react";
import sangarAsset from "@/assets/sangar.jpg.asset.json";

// Lazy-loaded tools for optimal bundle size and instant initial load
const Uploader = lazy(() => import("@/components/Uploader").then((m) => ({ default: m.Uploader })));
const ChatBox = lazy(() => import("@/components/ChatBox").then((m) => ({ default: m.ChatBox })));
const Humanizer = lazy(() => import("@/components/Humanizer").then((m) => ({ default: m.Humanizer })));
const Handwriting = lazy(() => import("@/components/Handwriting").then((m) => ({ default: m.Handwriting })));
const AiTool = lazy(() => import("@/components/AiTool").then((m) => ({ default: m.AiTool })));
const Math2Word = lazy(() => import("@/components/Math2Word").then((m) => ({ default: m.Math2Word })));
const PdfMerge = lazy(() => import("@/components/PdfMerge").then((m) => ({ default: m.PdfMerge })));
const PdfSplit = lazy(() => import("@/components/PdfSplit").then((m) => ({ default: m.PdfSplit })));
const PdfCompress = lazy(() => import("@/components/PdfCompress").then((m) => ({ default: m.PdfCompress })));
const PdfRotate = lazy(() => import("@/components/PdfRotate").then((m) => ({ default: m.PdfRotate })));
const PdfWatermark = lazy(() => import("@/components/PdfWatermark").then((m) => ({ default: m.PdfWatermark })));
const VideoDownloader = lazy(() => import("@/components/VideoDownloader").then((m) => ({ default: m.VideoDownloader })));
const VideoConverter = lazy(() => import("@/components/VideoConverter").then((m) => ({ default: m.VideoConverter })));
const VideoCompressor = lazy(() => import("@/components/VideoCompressor").then((m) => ({ default: m.VideoCompressor })));
const VideoTools = lazy(() => import("@/components/VideoTools").then((m) => ({ default: m.VideoTools })));
const DocumentForensics = lazy(() => import("@/components/DocumentForensics").then((m) => ({ default: m.DocumentForensics })));
const PdfProtect = lazy(() => import("@/components/PdfProtect").then((m) => ({ default: m.PdfProtect })));
const PdfToWord = lazy(() => import("@/components/PdfToWord").then((m) => ({ default: m.PdfToWord })));
const PdfToPpt = lazy(() => import("@/components/PdfToPpt").then((m) => ({ default: m.PdfToPpt })));
const PdfToExcel = lazy(() => import("@/components/PdfToExcel").then((m) => ({ default: m.PdfToExcel })));
const FilesToPdf = lazy(() => import("@/components/FilesToPdf").then((m) => ({ default: m.FilesToPdf })));
const ZankoGuide = lazy(() => import("@/components/ZankoGuide").then((m) => ({ default: m.ZankoGuide })));
const CitationTool = lazy(() => import("@/components/AcademicSuite").then((m) => ({ default: m.CitationTool })));
const DoiCitationTool = lazy(() => import("@/components/AcademicSuite").then((m) => ({ default: m.DoiCitationTool })));
const BibTexTool = lazy(() => import("@/components/AcademicSuite").then((m) => ({ default: m.BibTexTool })));
const LatexEditorTool = lazy(() => import("@/components/AcademicSuite").then((m) => ({ default: m.LatexEditorTool })));
const LatexWordTool = lazy(() => import("@/components/AcademicSuite").then((m) => ({ default: m.LatexWordTool })));
const QrCodeGenerator = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.QrCodeGenerator })));
const QrCodeScanner = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.QrCodeScanner })));
const HashGenerator = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.HashGenerator })));
const Base64Tool = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.Base64Tool })));
const UrlEncoderTool = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.UrlEncoderTool })));
const UuidGenerator = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.UuidGenerator })));
const LinksChecker = lazy(() => import("@/components/SecuritySuite").then((m) => ({ default: m.LinksChecker })));
const InvoiceGenerator = lazy(() => import("@/components/InvoiceGenerator").then((m) => ({ default: m.InvoiceGenerator })));
const ProfitCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.ProfitCalculator })));
const VatCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.VatCalculator })));
const SalaryCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.SalaryCalculator })));
const DiscountCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.DiscountCalculator })));
const LoanCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.LoanCalculator })));
const CurrencyConverter = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.CurrencyConverter })));
const BreakEvenCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.BreakEvenCalculator })));
const RoiCalculator = lazy(() => import("@/components/BusinessToolkit").then((m) => ({ default: m.RoiCalculator })));
const StatisticsLab = lazy(() => import("@/components/StatisticsLab").then((m) => ({ default: m.StatisticsLab })));
const PrivacyCenter = lazy(() => import("@/components/PrivacyCenter").then((m) => ({ default: m.PrivacyCenter })));
const StudyGroupRoom = lazy(() => import("@/components/StudyGroupRoom").then((m) => ({ default: m.StudyGroupRoom })));
const AiDailyBriefing = lazy(() => import("@/components/AiDailyBriefing").then((m) => ({ default: m.AiDailyBriefing })));
const AiWelcomeAssistant = lazy(() => import("@/components/AiWelcomeAssistant").then((m) => ({ default: m.AiWelcomeAssistant })));

type ToolId =
  | "video_downloader"
  | "video_converter"
  | "video_compressor"
  | "summary"
  | "chat"
  | "humanize"
  | "ocr"
  | "planner"
  | "solver"
  | "math2word"
  | "tts"
  | "grader"
  | "glossary"
  | "testai"
  | "testplagiarism"
  | "grapher"
  | "grammar"
  | "translator"
  | "chat_doc"
  | "audio_sum"
  | "pdf_merge"
  | "pdf_split"
  | "pdf_compress"
  | "pdf_to_word"
  | "pdf_to_ppt"
  | "pdf_to_excel"
  | "word_to_pdf"
  | "excel_to_pdf"
  | "pdf_rotate"
  | "pdf_protect"
  | "pdf_watermark"
  | "files_to_pdf"
  | "video_quiz"
  | "video_chapter"
  | "video_adaptive"
  | "document_forensics"
  | "zanko_guide"
  | "research_assistant"
  | "paper_summarizer"
  | "abstract_generator"
  | "lit_review"
  | "research_question"
  | "methodology_assistant"
  | "citation_generator"
  | "bibtex_generator"
  | "doi_citation"
  | "latex_word"
  | "latex_editor"
  | "qr_generator"
  | "qr_scanner"
  | "hash_generator"
  | "base64_tool"
  | "url_encoder"
  | "uuid_generator"
  | "link_checker"
  | "invoice_tool"
  | "receipt_tool"
  | "quotation_tool"
  | "purchase_order_tool"
  | "delivery_note_tool"
  | "profit_calc"
  | "vat_calc"
  | "salary_calc"
  | "discount_calc"
  | "loan_calc"
  | "currency_calc"
  | "breakeven_calc"
  | "roi_calc"
  | "statistics_lab"
  | "privacy_center"
  | "study_group"
  | "daily_briefing";

const WHATSAPP_NUMBER = "9647501435868";
const WHATSAPP_MESSAGE = encodeURIComponent(
  "Hello, I want to activate my VIP subscription for AI Study Summary.",
);
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "کورتەیا خواندنێ ب AI — پلاتفۆرمی زیرەک بو خواندکاران" },
      {
        name: "description",
        content:
          "بەلگەنامە و وێنێن خۆ بدانە و کورتەیەکا ڕێکوپێک وەربگرە ب کوردیا بادینی و سۆرانی ب هاریکاریا زیرەکیا دەستکرد.",
      },
      { property: "og:title", content: "کورتەیا خواندنێ ب AI" },
      { property: "og:description", content: "ئامرازەکێ زیرەک بو کورتکرنا پەرتوک و مەلزەمان." },
    ],
  }),
  component: Index,
});

function ToolSkeletonLoader() {
  return (
    <div className="flex flex-col items-center justify-center p-12 min-h-[350px] rounded-3xl bg-card border border-border text-center shadow-lg animate-pulse">
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4 text-primary-foreground shadow-md"
        style={{ background: "var(--gradient-primary)" }}
      >
        <Loader2 className="w-7 h-7 animate-spin" />
      </div>
      <h3 className="text-base font-bold text-foreground">د ئامادەکرن و بارکرنا ئامرازیدا...</h3>
      <p className="text-xs text-muted-foreground mt-1.5">تکایە کەمەکێ چاوەڕێبە</p>
    </div>
  );
}

function Index() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTool, setActiveTool] = useState<null | ToolId>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategoryIndex, setSelectedCategoryIndex] = useState<number | null>(null);
  const [activeExtraSection, setActiveExtraSection] = useState<'features' | 'pricing' | 'about' | null>(null);
  const [hoveredCategoryIdx, setHoveredCategoryIdx] = useState<number | null>(null);
  const [popoverTop, setPopoverTop] = useState(0);
  const hoverTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const categoryButtonRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const sidebarAsideRef = useRef<HTMLElement | null>(null);
  const toolContainerRef = useRef<HTMLDivElement>(null);

  const handleMouseEnterCategory = (idx: number) => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    hoverTimeoutRef.current = setTimeout(() => {
      const btn = categoryButtonRefs.current[idx];
      const aside = sidebarAsideRef.current;
      if (btn && aside) {
        const btnRect = btn.getBoundingClientRect();
        const asideRect = aside.getBoundingClientRect();
        // Align popover center with button center, clamped so it doesn't go below aside
        const btnCenter = btnRect.top - asideRect.top + btnRect.height / 2;
        setPopoverTop(Math.max(0, btnCenter - 35));
      }
      setHoveredCategoryIdx(idx);
    }, 350);
  };

  const handleMouseLeaveCategory = () => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    hoverTimeoutRef.current = setTimeout(() => {
      setHoveredCategoryIdx(null);
    }, 250);
  };


  const openTool = (id: ToolId) => {
    setActiveTool(id);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const el = toolContainerRef.current;
        if (el) {
          const top = el.getBoundingClientRect().top + window.scrollY - 80;
          window.scrollTo({ top, behavior: "smooth" });
        }
      });
    });
  };

  const sangarImgUrl = import.meta.env.DEV ? "/sangar.jpg" : sangarAsset.url || "/sangar.jpg";

  const navLinks = [
    { href: "#features", label: "بوچی ئەم؟" },
    { href: "#upload", label: "ئامرازەکان" },
    { href: "#pricing", label: "بهایی" },
    { href: "#about", label: "دەربارەی مە" },
  ];

  const categories = useMemo(
    () => [
      {
        num: "١",
        icon: BookOpen,
        gradient: "from-blue-600 to-indigo-600",
        title: "هاریکارێن زیرەک یێن خواندنێ",
        shortTitle: "هاریکارێن خواندنێ",
        desc: "کورتکرن، ئاخفتن، پلانا خواندنێ، فەرهەنگ و پوختەیا دەنگی.",
        tools: [
          { id: "summary", icon: FileText, title: "کورتکرن", desc: "نڤیسینێ کورت بکە و تاقیکرنێ بکە." },
          { id: "chat", icon: MessageCircle, title: "ئاخفتن", desc: "پسیارێ ژ AI بکە ب کوردی." },
          { id: "planner", icon: CalendarCheck, title: "پلانا خواندنێ", desc: "پلانا خواندنا ڕۆژانە بو تە." },
          { id: "glossary", icon: BookA, title: "فەرهەنگا زانستی", desc: "زاراڤێن ئەکادیمی." },
          { id: "audio_sum", icon: FileAudio, title: "پوختەیا دەنگی", desc: "دەنگی بگۆڕە بۆ نڤیسینێ یان کورتەیا دەنگی." },
        ],
      },
      {
        num: "٢",
        icon: Sigma,
        gradient: "from-emerald-600 to-teal-600",
        title: "ئامرازێن بیرکاری و زانستی",
        shortTitle: "بیرکاری و زانست",
        desc: "چارەسەری پێنگاڤ ب پێنگاڤ، Math → Word، و نەخشەسازی.",
        tools: [
          { id: "solver", icon: ListOrdered, title: "چارەسەری پێنگاڤ", desc: "پسیار پێنگاڤ ب پێنگاڤ." },
          { id: "math2word", icon: Sigma, title: "Math → Word", desc: "هاوکێشە بو Microsoft Word." },
          { id: "grapher", icon: LineChart, title: "وێنەکێشێ نەخشەیان", desc: "کێشانا دینامیکی یا نەخشەیێن بیرکاری." },
        ],
      },
      {
        num: "٣",
        icon: PenTool,
        gradient: "from-purple-600 to-pink-600",
        title: "زمان و نڤیسین",
        shortTitle: "زمان و نڤیسین",
        desc: "ڕاستنڤیس، وەرگێڕان، Humanize، دەستنڤیس و پشکنینا AI.",
        tools: [
          { id: "grammar", icon: PenTool, title: "ڕاستنڤیسا زمانێ", desc: "ڕاستکرنا هەڵەیێن ڕێزمانی و پێشکەشکرنا خشتە." },
          { id: "translator", icon: Languages, title: "وەرگێڕێ ئەکادیمی", desc: "وەرگێڕانا دەقێن زانستی و ئەکادیمی ب دروستی." },
          { id: "humanize", icon: Wand2, title: "Humanize Text", desc: "نڤیسینا AI بکە مرۆڤی." },
          { id: "ocr", icon: ScanLine, title: "دەستنڤیس بو دەقی", desc: "وێنەیێ دەستنڤیسی بخوینە." },
          { id: "grader", icon: ClipboardCheck, title: "نمرەدانا ڕاپۆرتێ", desc: "ڕاپۆرتا خۆ ب پیڤە و نمرەیێ ببینە." },
          { id: "testai", icon: ShieldCheck, title: "Test AI", desc: "ڕێژا نڤیسینا AI پشکنین بکە." },
          { id: "testplagiarism", icon: FileSearch, title: "Test Plagiarism", desc: "ڕێژا پلاجیاریزمێ پشکنین بکە." },
        ],
      },
      {
        num: "٤",
        icon: FilePlus2,
        gradient: "from-amber-600 to-orange-600",
        title: "خزمەتگوزاریێن PDF",
        shortTitle: "خزمەتگوزاریێن PDF",
        desc: "یەکگرتن، دابەشکرن، بچیکرن، گۆڕینی Word/PPT/Excel و پاراستن.",
        tools: [
          { id: "pdf_merge", icon: FilePlus2, title: "یەکگرتنا PDF", desc: "چەند فایلێن PDF بکە یەک ب ئاسانی." },
          { id: "pdf_split", icon: Scissors, title: "دابەشکرنا PDF", desc: "PDF دابەش بکە ب رووپەلان یان بەشان." },
          { id: "pdf_compress", icon: FileDown, title: "بچیکرنا PDF", desc: "قەبارەیا فایلێ PDF کەم بکە ب پاراستنا کوالیتی." },
          { id: "pdf_to_word", icon: FileType2, title: "PDF بو Word", desc: "PDF بگۆڕە بو فایلێ Word ب دروستی." },
          { id: "pdf_to_ppt", icon: Presentation, title: "PDF بو PowerPoint", desc: "PDF بگۆڕە بو پێشکەشکرنا PPT." },
          { id: "pdf_to_excel", icon: Table2, title: "PDF بو Excel", desc: "خشتەیێن PDFێ بگۆڕە بو Excel." },
          { id: "files_to_pdf", icon: FileType2, title: "گهورینا فایلان بو PDF", desc: "فایلێن Office, Adobe, و AutoCAD بگۆڕە بۆ PDF ب ئاسانی." },
          { id: "pdf_rotate", icon: RotateCw, title: "زڤرنا PDFێ", desc: "رووپەلێن PDF بزڤێرە بو هەر ئاراستەیەکێ." },
          { id: "pdf_protect", icon: Lock, title: "پاراستنا PDFێ", desc: "پاسۆردی بو PDF بدانە." },
          { id: "pdf_watermark", icon: Stamp, title: "نیشانا Watermark", desc: "نڤیسین یان وێنە ب شێوازا Watermark زێدە بکە." },
        ],
      },
      {
        num: "٥",
        icon: Video,
        gradient: "from-rose-600 to-red-600",
        title: "تایبەتمەندیێن ڤیدیۆیان",
        shortTitle: "تایبەتمەندیێن ڤیدیۆیان",
        desc: "داگرتنا ڤیدیۆیان (All-in-One)، کویز، کورتکرن و Adaptive Stream.",
        tools: [
          { id: "video_converter", icon: RefreshCw, title: "گۆڕەری جۆری فایلی ڤیدیۆ و دەنگ", desc: "گۆڕینی هەموو جۆرەکان (MP4 ➔ MP3, WAV, MKV, WebM, MOV, GIF...)" },
          { id: "video_compressor", icon: Minimize2, title: "کەمکردنەوەی قەبارەی ڤیدیۆ (Compress)", desc: "بچووککردنەوەی قەبارەی فایلی ڤیدیۆی گەورە لە گێگابایت (GB) بۆ مێگابایت (MB)." },
          { id: "video_downloader", icon: FileDown, title: "داگرتنا ڤیدیۆیان (All-in-One)", desc: "داگرتن و خەزنکرنا ڤیدیۆ ژ TikTok, YouTube, Instagram, Facebook ب کوالێتیا بەرز." },
          { id: "video_quiz", icon: Brain, title: "پشکینینا ناڤا ڤیدیۆیێ", desc: "Interactive Video Quizzes (پشکنینا پسیارێن ناڤا ڤیدیۆیێ)" },
          { id: "video_chapter", icon: Video, title: "کورتکرنا ئۆتۆماتیکی یا ڤیدیۆیێ", desc: "Video AI Chaptering (کورتکرنا ڤیدیۆیان ب پشکێن بچووک)" },
          { id: "video_adaptive", icon: Zap, title: "گۆهرینا جۆری یا داینامیکی", desc: "Adaptive Bitrate Streaming (گونجاندنا داینامیکی یا کوالیتیێ)" },
        ],
      },
      {
        num: "٦",
        icon: ShieldCheck,
        gradient: "from-cyan-600 to-blue-700",
        title: "سیستەمێ پشکنینا دادوەری و دیارکرنا ساختەکاریێ",
        shortTitle: "دادوەری بەڵگەنامە",
        desc: "پشکنینا فۆنت، دەستکاریکرنا ڕەنگان، ELA و داتایێن مێتاداتا.",
        tools: [
          { id: "document_forensics", icon: ShieldCheck, title: "پشکنینا دادوەری یا بەڵگەنامەیان", desc: "پشکنینا فۆنت، دەستکاریکرنا ڕەنگان، ELA و داتایێن مێتاداتا." },
        ],
      },
      {
        num: "٧",
        icon: GraduationCap,
        gradient: "from-violet-600 to-indigo-700",
        title: "ڕێبەرێ زانکۆلاین و هەڵبژاردنی بەشەکان",
        shortTitle: "ڕێبەرێ زانکۆلاین",
        desc: "ڕیزبەندیەکا ژیربێژ و دروست بۆ زانکۆلاین دروست بکە.",
        tools: [
          { id: "zanko_guide", icon: GraduationCap, title: "ڕێبەرێ زانکۆلاین", desc: "ڕیزبەندیەکا ژیربێژ و دروست بۆ زانکۆلاین دروست بکە." },
        ],
      },
      {
        num: "٨",
        icon: Microscope,
        gradient: "from-indigo-600 via-blue-600 to-teal-600",
        title: "ئامرازێن توێژینەوە و زانستی",
        shortTitle: "توێژینەوە و زانست",
        desc: "Research Assistant, Paper Summarizer, Abstract, Lit Review, Citation, BibTeX, DOI, LaTeX.",
        tools: [
          { id: "research_assistant", icon: Brain, title: "Research Assistant", desc: "یاریدەدەری توێژینەوە و دارشتنی پلان و تێز." },
          { id: "paper_summarizer", icon: FileText, title: "Paper Summarizer", desc: "پوختەکردنی پەڕاوی زانستی بە ٦ بەشی سەرەکی." },
          { id: "abstract_generator", icon: Sparkles, title: "Abstract Generator", desc: "دروستکردنی پوختەی ئەکادیمی (Abstract) و کلیلەوشەکان." },
          { id: "lit_review", icon: Library, title: "Literature Review Assistant", desc: "پێداچوونەوەی ئەدەبیاتی زانستی و خشتەی بەراوردکاری." },
          { id: "research_question", icon: HelpCircle, title: "Research Question Generator", desc: "دروستکردنی پرسیار و گریمانەکانی توێژینەوە (PICO/FINER)." },
          { id: "methodology_assistant", icon: Layers, title: "Methodology Assistant", desc: "دیاریکردنی مێتۆدۆلۆژیا، نموونە و پلانی شیکاری." },
          { id: "citation_generator", icon: Quote, title: "Citation Generator", desc: "سایتەیشن بە ستانداردەکانی APA, MLA, Chicago, IEEE, Harvard." },
          { id: "bibtex_generator", icon: FileCode, title: "BibTeX Generator", desc: "دروستکردن و داگرتنی پەڕگەی .bib بۆ LaTeX." },
          { id: "doi_citation", icon: Binary, title: "DOI → Citation", desc: "وەرگرتنی ڕاستەوخۆی سەرچاوە لە ڕێگەی ژمارەی DOI." },
          { id: "latex_word", icon: Code2, title: "LaTeX ↔ Word", desc: "گۆڕینی هاوکێشەکان لە نێوان LaTeX و Microsoft Word." },
          { id: "latex_editor", icon: Calculator, title: "LaTeX Equation Editor", desc: "دەستکاریکەری هاوکێشەی LaTeX بە بینینی ڕاستەوخۆ (KaTeX)." },
        ],
      },
      {
        num: "٩",
        icon: ShieldAlert,
        gradient: "from-blue-600 via-indigo-600 to-purple-700",
        title: "تایبەتمەندیێن پاراستن و بارکودان (Security & QR code Tools)",
        shortTitle: "پاراستن و بارکۆد",
        desc: "QR Code Generator, Scanner, Hash, Base64, URL Encoder, UUID و Links Checker بۆ زانینی لینکی ساختە و هاک.",
        tools: [
          { id: "qr_generator", icon: QrCode, title: "QR Code Generator", desc: "دروستکەری پێشکەوتووی بارکۆد و QR Code بۆ وێب، وایفای، کارتی پەیوەندی و داگرتنی HD." },
          { id: "qr_scanner", icon: Scan, title: "QR Code Scanner", desc: "خوێندنەوە و سکانکردنی بارکۆد و QR بە کامێرای مۆبایل/کۆمپیوتەر یان بە بارکردنی وێنە." },
          { id: "hash_generator", icon: Hash, title: "Hash Generator", desc: "دروستکەری هاش (MD5, SHA-1, SHA-256, SHA-512) بۆ دەق و فایل بە پشکنینی دروستی." },
          { id: "base64_tool", icon: FileCode, title: "Base64 Encoder/Decoder", desc: "کۆدکردن و شیکردنەوەی Base64 بۆ دەقی کوردی/یونیکۆد و گۆڕینی فایل و وێنە." },
          { id: "url_encoder", icon: Globe, title: "URL Encoder/Decoder", desc: "کۆدکردن و شیکردنەوەی دروستی لینکەکانی وێب و پشکنینی پیکهاتەی URL." },
          { id: "uuid_generator", icon: Fingerprint, title: "UUID Generator", desc: "دروستکەری ناسنامەی بێهاوتا (UUID v4, NanoID, Hex, Passwords) بە ژمارەی داواکراو." },
          { id: "link_checker", icon: ShieldAlert, title: "Links Checker (پشکنینی لینکی ساختە)", desc: "پشکنەری ساختەکاری و سەلامەتی لینک بۆ زانینی لینکی ساختە، فیشینگ و هاک." },
        ],
      },
      {
        num: "١٠",
        icon: TrendingUp,
        gradient: "from-emerald-600 via-teal-600 to-cyan-700",
        title: "تایبەتمەندی و ئامرازێن بازرگانی (Business Toolkit)",
        shortTitle: "ئامرازێن بازرگانی",
        desc: "Profit, VAT, Salary, Discount, Loan, Currency Converter, Break-even, ROI و Invoice Generator بە دیزاینی پێشکەوتوو.",
        tools: [
          { id: "profit_calc", icon: TrendingUp, title: "Profit Calculator", desc: "ژمێریاری قازانج، کۆی داهات، تێچوو، Profit Margin و ڕێژەی قازانجی پوخت." },
          { id: "vat_calc", icon: Percent, title: "VAT Calculator", desc: "ژمێریاری باجی بەهای زیادکراو (Add VAT یان Remove VAT) بە ڕێژەی دڵخواز." },
          { id: "salary_calc", icon: Wallet, title: "Salary Calculator", desc: "ژمێریاری مووچەی مانگانە، کاتژمێری زیادە، پاداشت و پوختەی مووچەی وەرگیراو." },
          { id: "discount_calc", icon: Tag, title: "Discount Calculator", desc: "ژمێریاری داشکاندن بە ڕێژە (% دابەزین)، کۆپۆنی زیادە و بڕی پاشەکەوتکراو." },
          { id: "loan_calc", icon: CreditCard, title: "Loan & EMI Calculator", desc: "ژمێریاری قەرز، قیستی مانگانە، ڕێژەی سوود و کۆی گشتی پارەی دانەوە." },
          { id: "currency_calc", icon: Coins, title: "Currency Converter", desc: "گۆڕەری خێرای دراوەکان (USD, IQD, EUR, GBP, TRY, AED) بە دەستکاری نرخ." },
          { id: "breakeven_calc", icon: Target, title: "Break-even Calculator", desc: "دیاریکردنی خاڵی یەکسانبوون و ژمارەی فرۆشی پێویست بۆ داپۆشینی خەرجی." },
          { id: "roi_calc", icon: BarChart3, title: "ROI Calculator", desc: "ژمێریاری گەڕانەوەی وەبەرهێنان (Return on Investment) و ڕێژەی ساڵانە." },
          { id: "invoice_tool", icon: FileSpreadsheet, title: "Invoice & Receipt Generator", desc: "دروستکەری فاکتوورە (Invoice)، پسوولە، تەخمین، فەرمانی کڕین و گەیاندن." },
        ],
      },
      {
        num: "١١",
        icon: BarChart3,
        gradient: "from-indigo-600 via-purple-600 to-pink-600",
        title: "تاقیگەی ئامار و شیکاری داتا (Statistics Lab)",
        shortTitle: "تاقیگەی ئامار",
        desc: "بارکردنی داتاسێت (CSV/Excel) → شیکاری خۆکاری Mean, Median, Mode, Variance, SD, Quartiles, Correlation, Regression, Charts و Report.",
        tools: [
          { id: "statistics_lab", icon: BarChart3, title: "Statistics Lab & Data Science Engine", desc: "شیکاری هەمەلایەنەی داتاسێت بە ئاماری وەسفی، هاوکۆلکەی پێرسن، ڕیگرێشن، فرێکوێنسی و ڕاپۆرتی زانستی." },
        ],
      },
      {
        num: "١٢",
        icon: ShieldCheck,
        gradient: "from-teal-600 via-emerald-600 to-green-700",
        title: "سەنتەری پاراستنی تایبەتمەندی و داتا (Privacy Center)",
        shortTitle: "پاراستنی داتا",
        desc: "My Privacy, Uploaded Files, AI History, Active Devices, Delete All History, Delete Account و Zero-Trace Wipe.",
        tools: [
          { id: "privacy_center", icon: ShieldCheck, title: "Privacy Center & Trust Dashboard", desc: "کۆنتڕۆڵ و بەڕێوەبردنی تەواوی تایبەتمەندی (فایلەکان، مێژوو، ئامێرە چالاکەکان و سڕینەوە)." },
        ],
      },
      {
        num: "١٣",
        icon: Users,
        gradient: "from-blue-600 via-indigo-600 to-violet-700",
        title: "ژوورا گرووپێ خواندنێ (Study Group Room)",
        shortTitle: "ژوورا خوێندنێ",
        desc: "دروستکردنی ژووری خوێندنی گرووپی: Shared Notes, Shared Files, Group Quiz, Live Chat, Whiteboard و AI Tutor.",
        tools: [
          { id: "study_group", icon: Users, title: "Study Group Room", desc: "ژووری هاوبەشی خوێندکاران بە تێبینی، کویز، چات، تەختەی سپی و مامۆستای تایبەتی AI." },
        ],
      },
    ],
    [],
  );

  const allToolsCount = useMemo(() => {
    return categories.reduce((sum, cat) => sum + cat.tools.length, 0);
  }, [categories]);

  // Kurdish/Arabic character normalizer for robust search
  const normalizeSearch = (text: string) =>
    text
      .toLowerCase()
      .replace(/[ي]/g, "ی")
      .replace(/[ك]/g, "ک")
      .replace(/[ة]/g, "ە")
      .replace(/[أإآ]/g, "ا")
      .replace(/[\u064B-\u065F]/g, "")
      .trim();

  // Filter tools based on query and selected category
  const filteredCategories = useMemo(() => {
    const rawQ = searchQuery.trim();
    if (!rawQ) {
      if (selectedCategoryIndex !== null) {
        return categories.filter((_, idx) => idx === selectedCategoryIndex);
      }
      return categories;
    }

    const q = normalizeSearch(rawQ);

    return categories
      .map((cat) => {
        const catMatches =
          normalizeSearch(cat.title).includes(q) ||
          normalizeSearch(cat.shortTitle).includes(q);

        const matchingTools = cat.tools.filter((t) => {
          return (
            catMatches ||
            normalizeSearch(t.title).includes(q) ||
            normalizeSearch(t.desc).includes(q) ||
            normalizeSearch(t.id).includes(q)
          );
        });

        if (matchingTools.length === 0) return null;
        return { ...cat, tools: matchingTools };
      })
      .filter(Boolean) as typeof categories;
  }, [categories, searchQuery, selectedCategoryIndex]);

  const totalFilteredTools = useMemo(() => {
    return filteredCategories.reduce((acc, cat) => acc + cat.tools.length, 0);
  }, [filteredCategories]);

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      {/* Nav */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-background/85 border-b border-border transition-colors duration-300">
        <div className="max-w-[1550px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md"
              style={{ background: "var(--gradient-primary)" }}
            >
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-extrabold text-lg tracking-tight">کورتەیا AI</span>
          </div>



          <div className="flex items-center gap-3">
            <ThemeToggle />
            <button
              onClick={() => setMenuOpen(true)}
              aria-label="ڤەکرنا مینیویێ"
              className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-secondary text-secondary-foreground hover:bg-secondary/80 transition shadow-sm border border-border"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Slide-out menu */}
      <div
        className={`fixed inset-0 z-50 transition ${menuOpen ? "pointer-events-auto" : "pointer-events-none"}`}
        aria-hidden={!menuOpen}
      >
        <div
          onClick={() => setMenuOpen(false)}
          className={`absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity ${menuOpen ? "opacity-100" : "opacity-0"}`}
        />
        <aside
          className={`absolute top-0 right-0 h-full w-[85%] max-w-sm bg-card border-l border-border shadow-2xl p-6 flex flex-col transition-transform duration-300 ${menuOpen ? "translate-x-0" : "translate-x-full"}`}
        >
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-border">
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: "var(--gradient-primary)" }}
              >
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-extrabold text-base">کورتەیا AI</span>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <button
                onClick={() => setMenuOpen(false)}
                aria-label="گرتنا مینیویێ"
                className="w-9 h-9 rounded-lg flex items-center justify-center bg-secondary hover:bg-secondary/80 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <nav className="flex flex-col gap-3 text-base font-semibold">
            <button
              onClick={() => {
                setActiveExtraSection("features");
                setMenuOpen(false);
                requestAnimationFrame(() => {
                  document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
                });
              }}
              className="px-4 py-2.5 rounded-xl hover:bg-secondary transition text-right"
            >
              بوچی ئەم؟
            </button>
            <button
              onClick={() => {
                setActiveTool(null);
                setActiveExtraSection(null);
                setMenuOpen(false);
                document.getElementById("upload")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="px-4 py-2.5 rounded-xl hover:bg-secondary transition text-right"
            >
              ئامرازەکان
            </button>
            <button
              onClick={() => {
                setActiveExtraSection("pricing");
                setMenuOpen(false);
                requestAnimationFrame(() => {
                  document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" });
                });
              }}
              className="px-4 py-2.5 rounded-xl hover:bg-secondary transition text-right"
            >
              بهایی
            </button>
            <button
              onClick={() => {
                setActiveExtraSection("about");
                setMenuOpen(false);
                requestAnimationFrame(() => {
                  document.getElementById("about")?.scrollIntoView({ behavior: "smooth" });
                });
              }}
              className="px-4 py-2.5 rounded-xl hover:bg-secondary transition text-right"
            >
              دەربارەی مە
            </button>
          </nav>

          <div className="mt-8 pt-6 border-t border-border">
            <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4 text-right">
              پەیوەندی دگەل من
            </h4>
            <div className="flex items-center gap-3 justify-end">
              <a
                href="https://www.instagram.com/sangar__98?igsh=NHgxbzY2bGQ5M2I0&utm_source=qr"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-9 h-9 rounded-full bg-secondary border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://www.facebook.com/share/1DrTW5Z1ik/?mibextid=wwXIfr"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="w-9 h-9 rounded-full bg-secondary border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="mailto:sangarduhok@gmail.com"
                aria-label="Email"
                className="w-9 h-9 rounded-full bg-secondary border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
            <div className="flex justify-center mt-5">
              <div
                className="rounded-xl overflow-hidden border-2 border-border w-28 h-32 shadow-lg"
              >
                <img
                  src={sangarImgUrl}
                  alt="سەنگەر محمد حەسەن"
                  className="w-full h-full object-cover object-top"
                  loading="lazy"
                />
              </div>
            </div>
          </div>

          <div className="mt-auto pt-6 text-xs text-muted-foreground text-center">
            © {new Date().getFullYear()} کورتەیا AI — Sangar Mohammed
          </div>
        </aside>
      </div>

      {/* Main Content Area */}
      <div id="upload" className="max-w-[1550px] mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-20">
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8 items-start">
          
          {/* RIGHT SIDE: Categories Sidebar + Quick Nav (with elegant hero-green background) */}
          <aside ref={(el) => { sidebarAsideRef.current = el; }} className="hidden lg:block w-[250px] xl:w-[270px] sticky top-20 shrink-0 self-start z-30 p-2.5 rounded-3xl border border-emerald-500/30 dark:border-emerald-500/25 shadow-xl shadow-emerald-500/10 relative backdrop-blur-xl bg-gradient-to-b from-emerald-500/20 via-teal-500/15 to-emerald-600/20 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 space-y-2.5">
            {/* Soft hero gradient glow layer */}
            <div
              className="absolute inset-0 opacity-30 pointer-events-none rounded-3xl overflow-hidden"
              style={{ background: "var(--gradient-hero)" }}
            />

            {/* Hover Tooltip / Floating Quick Preview of Category Tools — PREMIUM */}
            {hoveredCategoryIdx !== null && categories[hoveredCategoryIdx] && (() => {
              const cat = categories[hoveredCategoryIdx];
              const CatIcon = cat.icon;
              return (
                <div
                  onMouseEnter={() => { if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current); }}
                  onMouseLeave={handleMouseLeaveCategory}
                  className="hidden lg:block absolute right-[106%] w-[620px] xl:w-[660px] rounded-3xl overflow-hidden shadow-2xl z-50 border border-white/10 animate-in fade-in-0 zoom-in-[0.97] slide-in-from-right-4 duration-200"
                  style={{
                    background: "var(--color-card)",
                    boxShadow: "0 24px 64px -8px rgba(0,0,0,0.22), 0 0 0 1px rgba(255,255,255,0.06)",
                    top: `${popoverTop}px`,
                  }}
                >
                  {/* Connector arrow */}
                  <div
                    className="absolute top-7 -right-[9px] w-4 h-4 rotate-45 border-r border-t border-white/10 z-10"
                    style={{ background: `var(--color-card)` }}
                  />

                  {/* Gradient Hero Header */}
                  <div
                    className={`relative flex items-center gap-3 px-5 py-2.5 overflow-hidden bg-gradient-to-br ${cat.gradient}`}
                  >
                    {/* Blurred glow orb */}
                    <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full opacity-25 blur-2xl bg-white pointer-events-none" />

                    <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center shrink-0 shadow-lg border border-white/30">
                      <CatIcon className="w-5 h-5 text-white" />
                    </div>
                    <div className="min-w-0 flex-1 text-right">
                      <h4 className="font-extrabold text-sm text-white leading-tight truncate">
                        {cat.title}
                      </h4>
                    </div>

                  </div>

                  {/* Tool Grid — compact 3-col with scroll */}
                  <div className="px-3 pt-2.5 pb-3 max-h-[290px] overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
                    <div className="grid grid-cols-3 gap-1.5">
                      {cat.tools.map((tool) => {
                        const ToolIcon = tool.icon;
                        return (
                          <button
                            key={tool.id}
                            onClick={() => {
                              setSelectedCategoryIndex(hoveredCategoryIdx);
                              setActiveTool(tool.id as ToolId);
                              setActiveExtraSection(null);
                              setHoveredCategoryIdx(null);
                              document.getElementById('upload')?.scrollIntoView({ behavior: 'smooth' });
                            }}
                            className="text-right px-2.5 py-2 rounded-lg bg-secondary/40 hover:bg-secondary/80 border border-border/40 hover:border-border/70 hover:shadow-sm transition-all duration-150 flex flex-row-reverse items-center gap-2 group cursor-pointer"
                          >
                            {/* Icon */}
                            <div
                              className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-all duration-200 bg-gradient-to-br ${cat.gradient} shadow-sm group-hover:scale-105`}
                            >
                              <ToolIcon className="w-3.5 h-3.5 text-white" />
                            </div>
                            {/* Text */}
                            <span className="font-bold text-[11px] text-foreground flex-1 text-right leading-tight group-hover:text-primary transition-colors line-clamp-2">
                              {tool.title}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>


                </div>
              );
            })()}


            <div className="relative z-10 flex flex-col gap-1.5">
              {/* Main Page / Home Button */}
              {(() => {
                const isHomeSelected = !activeExtraSection && selectedCategoryIndex === null;
                return (
                  <button
                    onClick={() => {
                      setSelectedCategoryIndex(null);
                      setActiveTool(null);
                      setActiveExtraSection(null);
                      document.getElementById('upload')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`w-full text-right px-3 py-2.5 rounded-xl border transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                      isHomeSelected
                        ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/25"
                        : "bg-card/90 dark:bg-card/85 border-border/80 hover:border-emerald-500/50 text-foreground hover:bg-card shadow-xs"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center transition shrink-0 ${
                          isHomeSelected
                            ? "bg-primary-foreground/20 text-primary-foreground"
                            : "bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-600 text-white"
                        }`}
                      >
                        <Home className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-xs truncate block text-right">
                        سەرەکی
                      </span>
                    </div>
                    <ChevronLeft
                      className={`w-3.5 h-3.5 transition-transform mr-0.5 ${
                        isHomeSelected
                          ? "text-primary-foreground -translate-x-0.5"
                          : "text-muted-foreground group-hover:-translate-x-0.5"
                      }`}
                    />
                  </button>
                );
              })()}

              {categories.map((cat, idx) => {
                const isSelected = !activeExtraSection && selectedCategoryIndex === idx;
                return (
                  <button
                    key={idx}
                    ref={(el) => { categoryButtonRefs.current[idx] = el; }}
                    onMouseEnter={() => handleMouseEnterCategory(idx)}
                    onMouseLeave={handleMouseLeaveCategory}
                    onClick={() => {
                      setSelectedCategoryIndex(idx);
                      setActiveTool(null);
                      setActiveExtraSection(null);
                      setHoveredCategoryIdx(null);
                      document.getElementById('upload')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`w-full text-right px-3 py-2.5 rounded-xl border transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                      isSelected
                        ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/25"
                        : "bg-card/90 dark:bg-card/85 border-border/80 hover:border-emerald-500/50 text-foreground hover:bg-card shadow-xs"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center transition shrink-0 ${
                          isSelected
                            ? "bg-primary-foreground/20 text-primary-foreground"
                            : `bg-gradient-to-br ${cat.gradient} text-white`
                        }`}
                      >
                        <cat.icon className="w-4 h-4" />
                      </div>
                      <span className="font-bold text-xs truncate block text-right">
                        {cat.shortTitle}
                      </span>
                    </div>
                    <ChevronLeft
                      className={`w-3.5 h-3.5 transition-transform mr-0.5 ${
                        isSelected
                          ? "text-primary-foreground -translate-x-0.5"
                          : "text-muted-foreground group-hover:-translate-x-0.5"
                      }`}
                    />
                  </button>
                );
              })}
            </div>

            {/* Quick Nav Links placed vertically under each other in the sidebar */}
            <div className="relative z-10 pt-2 border-t border-emerald-500/25 mt-1 flex flex-col gap-1.5">
              <button
                onClick={() => {
                  const next = activeExtraSection === "features" ? null : "features";
                  setActiveExtraSection(next);
                  setActiveTool(null);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className={`w-full text-right px-3 py-2 rounded-xl border transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                  activeExtraSection === "features"
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-card/80 dark:bg-card/70 border-border/70 hover:border-emerald-500/40 text-foreground hover:bg-card shadow-xs"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition shrink-0 ${
                      activeExtraSection === "features"
                        ? "bg-primary-foreground/20 text-primary-foreground"
                        : "bg-primary/10 text-primary"
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-bold text-xs truncate block text-right">
                    بوچی ئەم؟
                  </span>
                </div>
                <ChevronLeft
                  className={`w-3.5 h-3.5 transition-transform ${
                    activeExtraSection === "features"
                      ? "text-primary-foreground -translate-x-0.5"
                      : "text-muted-foreground group-hover:-translate-x-0.5"
                  }`}
                />
              </button>

              <button
                onClick={() => {
                  const next = activeExtraSection === "pricing" ? null : "pricing";
                  setActiveExtraSection(next);
                  setActiveTool(null);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className={`w-full text-right px-3 py-2 rounded-xl border transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                  activeExtraSection === "pricing"
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-card/80 dark:bg-card/70 border-border/70 hover:border-emerald-500/40 text-foreground hover:bg-card shadow-xs"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition shrink-0 ${
                      activeExtraSection === "pricing"
                        ? "bg-primary-foreground/20 text-primary-foreground"
                        : "bg-amber-500/10 text-amber-500"
                    }`}
                  >
                    <Crown className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-bold text-xs truncate block text-right">
                    پلانێن بهایی
                  </span>
                </div>
                <ChevronLeft
                  className={`w-3.5 h-3.5 transition-transform ${
                    activeExtraSection === "pricing"
                      ? "text-primary-foreground -translate-x-0.5"
                      : "text-muted-foreground group-hover:-translate-x-0.5"
                  }`}
                />
              </button>

              <button
                onClick={() => {
                  const next = activeExtraSection === "about" ? null : "about";
                  setActiveExtraSection(next);
                  setActiveTool(null);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className={`w-full text-right px-3 py-2 rounded-xl border transition-all duration-200 flex items-center justify-between group cursor-pointer ${
                  activeExtraSection === "about"
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-card/80 dark:bg-card/70 border-border/70 hover:border-emerald-500/40 text-foreground hover:bg-card shadow-xs"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition shrink-0 ${
                      activeExtraSection === "about"
                        ? "bg-primary-foreground/20 text-primary-foreground"
                        : "bg-blue-500/10 text-blue-500"
                    }`}
                  >
                    <GraduationCap className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-bold text-xs truncate block text-right">
                    دەربارەی مە
                  </span>
                </div>
                <ChevronLeft
                  className={`w-3.5 h-3.5 transition-transform ${
                    activeExtraSection === "about"
                      ? "text-primary-foreground -translate-x-0.5"
                      : "text-muted-foreground group-hover:-translate-x-0.5"
                  }`}
                />
              </button>
            </div>
          </aside>

          {/* LEFT MAIN AREA */}
          <main className="flex-1 min-w-0 w-full space-y-6">
            {/* When NO extra section is active: Show Tools Picker */}
            {!activeExtraSection && (
              <>
                {!activeTool && (
                  <>


                    {/* Mobile Horizontal Slider */}
                    <div className="lg:hidden flex gap-2.5 overflow-x-auto p-2 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-teal-500/15 to-emerald-500/20 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-500/25 backdrop-blur-md no-scrollbar snap-x mb-4">
                      <button
                        onClick={() => setSelectedCategoryIndex(null)}
                        className={`snap-start shrink-0 px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 border ${
                          selectedCategoryIndex === null
                            ? "bg-primary text-primary-foreground border-primary shadow-md"
                            : "bg-card/90 text-foreground border-border/80 hover:bg-card shadow-xs"
                        }`}
                      >
                        <Home className="w-4 h-4" />
                        <span>سەرەکی</span>
                      </button>
                      {categories.map((cat, idx) => (
                        <button
                          key={idx}
                          onClick={() => setSelectedCategoryIndex(idx)}
                          className={`snap-start shrink-0 px-4 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 border ${
                            selectedCategoryIndex === idx
                              ? "bg-primary text-primary-foreground border-primary shadow-md"
                              : "bg-card text-foreground border-border hover:bg-secondary"
                          }`}
                        >
                          <cat.icon className="w-4 h-4" />
                          <span>{cat.shortTitle}</span>
                          <span className="opacity-75 text-[10px]">({cat.tools.length})</span>
                        </button>
                      ))}
                    </div>

                    {/* When ON HOME ("سەرەکی"): Show clean Landing & Category Cards (NO massive 31-tool list) */}
                    {selectedCategoryIndex === null && !searchQuery.trim() ? (
                      <div className="space-y-6 animate-in fade-in-50 duration-300">
                        {/* AI Welcome Assistant – Dynamic & Interactive Homepage Experience */}
                        <Suspense fallback={null}>
                          <AiWelcomeAssistant
                            onSelectTool={(id) => openTool(id as ToolId)}
                            onSelectCategory={(idx) => setSelectedCategoryIndex(idx)}
                          />
                        </Suspense>

                        {/* AI Daily Briefing Morning Motivation */}
                        <Suspense fallback={null}>
                          <AiDailyBriefing onSelectTool={(id) => openTool(id as ToolId)} />
                        </Suspense>


                        {/* Quick Highlights / Features */}
                        <div className="pt-2">
                          <div className="grid sm:grid-cols-3 gap-3.5">
                            <div className="p-4 rounded-2xl bg-secondary/30 border border-border flex items-start gap-3">
                              <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                                <Zap className="w-4 h-4" />
                              </div>
                              <div>
                                <h5 className="text-xs font-bold text-foreground mb-0.5">لەزا بێ وێنە</h5>
                                <p className="text-[11px] text-muted-foreground">بەرسڤدان و شیکارکرن د چەند چرکەیەکێن کێمدا.</p>
                              </div>
                            </div>

                            <div className="p-4 rounded-2xl bg-secondary/30 border border-border flex items-start gap-3">
                              <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                                <Languages className="w-4 h-4" />
                              </div>
                              <div>
                                <h5 className="text-xs font-bold text-foreground mb-0.5">پشتەڤانیا زمانی کوردی</h5>
                                <p className="text-[11px] text-muted-foreground">کوردیا بادینی، سۆرانی و ئینگلیزی ب تەواوی.</p>
                              </div>
                            </div>

                            <div className="p-4 rounded-2xl bg-secondary/30 border border-border flex items-start gap-3">
                              <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                                <ShieldCheck className="w-4 h-4" />
                              </div>
                              <div>
                                <h5 className="text-xs font-bold text-foreground mb-0.5">ئاسایش و داتایا تە</h5>
                                <p className="text-[11px] text-muted-foreground">فایل و داتایێن تە پاراستینە و ناهێنە بەلاڤکرن.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* When a specific Category is Selected OR user is Searching */
                      <>
                        {/* Search Input Box */}
                        <div className="relative">
                          <Search className="w-5 h-5 absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                          <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="ل ناڤ ئامرازان بگەڕە..."
                            className="w-full h-13 pr-12 pl-10 rounded-2xl bg-card border border-border shadow-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm transition"
                          />
                          {searchQuery && (
                            <button
                              onClick={() => setSearchQuery("")}
                              className="absolute left-3.5 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-secondary text-muted-foreground hover:text-foreground flex items-center justify-center text-xs cursor-pointer"
                            >
                              ✕
                            </button>
                          )}
                        </div>

                        {/* Category Header Banner */}
                        {searchQuery.trim() ? (
                          <div className="p-4 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                              <Search className="w-5 h-5 text-primary" />
                              <span className="text-sm font-bold text-foreground">
                                دەرئەنجامێن گەڕانێ بۆ: <span className="text-primary font-extrabold">"{searchQuery}"</span>
                              </span>
                            </div>
                            <span className="text-xs font-bold text-primary bg-background px-3 py-1 rounded-xl border border-primary/20">
                              {totalFilteredTools} ئامراز
                            </span>
                          </div>
                        ) : selectedCategoryIndex !== null && categories[selectedCategoryIndex] ? (
                          <div className="p-3.5 rounded-2xl bg-secondary/30 border border-border flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className={`w-9 h-9 rounded-xl flex items-center justify-center text-white bg-gradient-to-br ${categories[selectedCategoryIndex].gradient} shadow-xs shrink-0`}
                              >
                                {(() => {
                                  const CatIcon = categories[selectedCategoryIndex].icon;
                                  return <CatIcon className="w-4.5 h-4.5" />;
                                })()}
                              </div>
                              <h3 className="text-sm md:text-base font-extrabold text-foreground truncate">
                                {categories[selectedCategoryIndex].title}
                              </h3>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-[11px] font-bold text-primary bg-primary/10 px-2.5 py-0.5 rounded-lg border border-primary/20">
                                {categories[selectedCategoryIndex].tools.length} ئامراز
                              </span>
                              <button
                                onClick={() => setSelectedCategoryIndex(null)}
                                className="text-[11px] font-semibold text-muted-foreground hover:text-foreground px-2 py-0.5 rounded-lg bg-secondary hover:bg-secondary/80 transition cursor-pointer"
                              >
                                سەرەکی
                              </button>
                            </div>
                          </div>
                        ) : null}

                        {/* Tools Grid */}
                        {totalFilteredTools === 0 ? (
                          <div className="text-center py-12 px-4 bg-card rounded-2xl border border-border my-4">
                            <p className="text-sm font-bold text-foreground mb-1">
                              چ ئامرازەک بۆ گەڕانەکا تە نەهاتە دیتن
                            </p>
                            <p className="text-xs text-muted-foreground mb-4">
                              وشەیەکا تر تاقی بکە یان پیتەکان بپشکنە
                            </p>
                            <button
                              onClick={() => {
                                setSearchQuery("");
                                setSelectedCategoryIndex(null);
                              }}
                              className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-xs font-bold hover:opacity-90 transition cursor-pointer"
                            >
                              پاککردنەوەی گەڕان
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-6 animate-in fade-in-50 duration-300">
                            {filteredCategories.map((cat, ci) => (
                              <div key={ci} className="space-y-3">
                                {searchQuery.trim() && (
                                  <h4 className="text-xs font-bold border-b border-border pb-1.5 text-muted-foreground">
                                    <span>{cat.title}</span>
                                  </h4>
                                )}
                                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
                                  {cat.tools.map((t) => (
                                    <button
                                      key={t.id}
                                      onClick={() => openTool(t.id as ToolId)}
                                      id={t.id === "chat" ? "chat" : undefined}
                                      className="group relative text-right rounded-xl p-3.5 bg-card border border-border hover:border-primary/60 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md flex flex-col justify-between cursor-pointer"
                                      style={{ boxShadow: "var(--shadow-elegant)" }}
                                    >
                                      <div>
                                        <div
                                          className="w-8 h-8 rounded-lg flex items-center justify-center mb-2.5 text-primary-foreground group-hover:scale-105 transition shadow-2xs"
                                          style={{ background: "var(--gradient-primary)" }}
                                        >
                                          <t.icon className="w-4 h-4" />
                                        </div>
                                        <h4 className="text-xs md:text-sm font-bold mb-1 group-hover:text-primary transition-colors text-foreground">
                                          {t.title}
                                        </h4>
                                        <p className="text-muted-foreground text-[11px] leading-snug line-clamp-2">
                                          {t.desc}
                                        </p>
                                      </div>
                                    </button>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    )}
                  </>
                )}

                {/* Active Tool View */}
                {activeTool && (
                  <div ref={toolContainerRef} className="animate-in fade-in-50 duration-300">
                    <button
                      onClick={() => setActiveTool(null)}
                      aria-label="ڤەگەڕیان بو هەمی ئامرازان"
                      title="ڤەگەڕیان بو هەمی ئامرازان"
                      className="mb-6 inline-flex items-center justify-center w-10 h-10 rounded-full bg-secondary border border-border hover:bg-secondary/80 hover:scale-105 active:scale-95 transition text-foreground cursor-pointer shadow-sm"
                    >
                      <ArrowRight className="w-5 h-5" />
                    </button>

                    <Suspense fallback={<ToolSkeletonLoader />}>
                      {activeTool === "summary" && <Uploader />}
                      {activeTool === "chat" && <ChatBox />}
                      {activeTool === "humanize" && <Humanizer />}
                      {activeTool === "ocr" && <Handwriting />}
                      {activeTool === "planner" && (
                        <AiTool
                          tool="planner"
                          title="پلانا خواندنا AI"
                          description="بابەت و دەمێ خواندنێ بنڤیسە، پلانەکا ڕۆژانە وەردگری."
                          placeholder="نموونە: ٧ ڕۆژ بو تاقیکرنا کیمیایێ، ٣ کاتژمێر د ڕۆژەکێدا"
                          buttonLabel="پلانا من بو دروست بکە"
                        />
                      )}
                      {activeTool === "solver" && (
                        <AiTool
                          tool="solver"
                          title="شیکارکەرێ پرسیاران"
                          description="پرسیارەکا بیرکاری یان زانستی بنڤیسە، شیکاریێ وەردگری."
                          placeholder="نموونە: شیکاریا هاوکێشەیا x^2 - 5x + 6 = 0 بکە"
                          buttonLabel="شیکار بکە"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "math2word" && <Math2Word />}
                      {activeTool === "grader" && (
                        <AiTool
                          tool="grader"
                          title="هەڵسەنگاندنا نڤیسینێ"
                          description="دەقێ نڤیسینێ یان وتارەکێ بدانە بۆ هەڵسەنگاندن و پێدانا نمرەیێ دگەل تێبینیان."
                          placeholder="دەقێ وتار یان نڤیسینا خۆ ل ڤێرێ بنڤیسە..."
                          buttonLabel="هەڵسەنگاندنێ بکە"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "glossary" && (
                        <AiTool
                          tool="glossary"
                          title="فەرهەنگا زانستی"
                          description="بابەتەکێ زانستی بنڤیسە بۆ وەرگرتنا زاراوە و پێناسەیێن سەرەکی."
                          placeholder="نموونە: Calculus، Quantum Physics، Linear Algebra"
                          buttonLabel="زاراڤان نیشان بدە"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "testai" && (
                        <AiTool
                          tool="testai"
                          title="پشکنینا نڤیسینا AI"
                          description="دەقی بنڤیسە یان فایلی بدانە، ڕێژا AI تێ پێشبینیکرن."
                          placeholder="دەقێ ڤەکولینا خۆ ل ڤێرێ بدانە..."
                          buttonLabel="پشکنینێ بکە"
                          withFile
                          showPercentage
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "testplagiarism" && (
                        <AiTool
                          tool="testplagiarism"
                          title="پشکنینا پلەجیاریزم (Plagiarism)"
                          description="دەقی بنڤیسە یان فایلی بدانە، دەقێ دوبارە دەستنیشان دکەت."
                          placeholder="دەقێ ڤەکولینا خۆ ل ڤێرێ بدانە..."
                          buttonLabel="پشکنینێ بکە"
                          withFile
                          showPercentage
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "grapher" && (
                        <AiTool
                          tool="grapher"
                          title="دروستکەرێ دیاگرام و گرافان"
                          description="هاوکێشە یان داتایا خۆ بنڤیسە، گرافەکێ شارستانی و ڕوون وەردگری."
                          placeholder="نموونە: y = sin(x) + cos(2x) ژ 0 هەتا 2pi"
                          buttonLabel="گرافێ دروست بکە"
                        />
                      )}
                      {activeTool === "grammar" && (
                        <AiTool
                          tool="grammar"
                          title="ڕاستڤەکەرێ ڕێزمانی"
                          description="دەقێ کوردی، ئینگلیزی یان عەرەبی بنڤیسە بۆ ڕاستڤەکرنا هەڵەیێن ڕێزمانی و ڕێنووس."
                          placeholder="دەقێ خۆ ل ڤێرێ بنڤیسە بۆ ڕاستڤەکرنێ..."
                          buttonLabel="ڕاستڤە بکە"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "translator" && (
                        <AiTool
                          tool="translator"
                          title="وەرگێڕێ ئەکادیمی"
                          description="دەقێ زانستی یان ئەکادیمی بنڤیسە یان فایلێ بنێرە بۆ وەرگێڕان."
                          placeholder="دەقێ ئەکادیمی ل ڤێرێ بنڤیسە..."
                          buttonLabel="وەرگێڕان"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "audio_sum" && (
                        <AiTool
                          tool="audio_sum"
                          title="پوختەیا دەنگ و وتارێ"
                          description="دەنگێ خۆ تۆمار بکە، فایلەکێ دەنگی یان دەقەکێ بنڤیسە بۆ کورتکرن و گوهداریکرنێ."
                          placeholder="دەقێ خۆ یێ درێژ ل ڤێرێ بنڤیسە..."
                          buttonLabel="پوختە بکە"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}

                      {/* ── PDF Services (Tools 12–21) ── */}
                      {activeTool === "pdf_merge" && <PdfMerge />}
                      {activeTool === "pdf_split" && <PdfSplit />}
                      {activeTool === "pdf_compress" && <PdfCompress />}
                      {activeTool === "pdf_to_word" && <PdfToWord />}
                      {activeTool === "pdf_to_ppt" && <PdfToPpt />}
                      {activeTool === "pdf_to_excel" && <PdfToExcel />}
                      {activeTool === "files_to_pdf" && <FilesToPdf />}
                      {activeTool === "pdf_rotate" && <PdfRotate />}
                      {activeTool === "pdf_protect" && <PdfProtect />}
                      {activeTool === "pdf_watermark" && <PdfWatermark />}

                      {/* ── Advanced Media, Forensics & Video ── */}
                      {activeTool === "video_converter" && <VideoConverter />}
                      {activeTool === "video_compressor" && <VideoCompressor />}
                      {activeTool === "video_downloader" && <VideoDownloader />}
                      {activeTool === "video_quiz" && <VideoTools defaultTab="quiz" />}
                      {activeTool === "video_chapter" && <VideoTools defaultTab="chapter" />}
                      {activeTool === "video_adaptive" && <VideoTools defaultTab="adaptive" />}
                      {activeTool === "document_forensics" && <DocumentForensics />}
                      {activeTool === "zanko_guide" && <ZankoGuide />}

                      {/* ── Research & Academic Suite (11 Tools) ── */}
                      {activeTool === "research_assistant" && (
                        <AiTool
                          tool="research_assistant"
                          title="Research Assistant (یاریدەدەری توێژینەوە)"
                          description="پلان، تێز و بیرۆکەی توێژینەوەی ئەکادیمی بنووسە بۆ ڕێنمایی و پێشنیاری زانستی."
                          placeholder="تەوەری توێژینەوە، پرسیار یان بیرۆکەی تێزەکەت لێرە بنووسە..."
                          buttonLabel="داڕشتنی ڕاوێژی توێژینەوە"
                          withFile
                          fileAccept="image/*,application/pdf,.docx,.pptx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        />
                      )}
                      {activeTool === "paper_summarizer" && (
                        <AiTool
                          tool="paper_summarizer"
                          title="Paper Summarizer (پوختەکردنی پەڕاوی زانستی)"
                          description="فایلی PDF یان دەقی وتار و تێزەکان باربکە بۆ وەرگرتنی پوختەیەکی ئەکادیمی ٦ بەشی."
                          placeholder="دەقی پەڕاو یان وتاری زانستی لێرە بنووسە یان فایلی PDF باربکە..."
                          buttonLabel="پوختەکردنی پەڕاو"
                          withFile
                          fileAccept="application/pdf,.docx,.pptx,image/*"
                        />
                      )}
                      {activeTool === "abstract_generator" && (
                        <AiTool
                          tool="abstract_generator"
                          title="Abstract Generator (دروستکەری پوختەی توێژینەوە)"
                          description="تەوەری توێژینەوە یان ڕەشنووس بنووسە بۆ دروستکردنی ئەبستراکتی ستانداردی نێودەوڵەتی."
                          placeholder="ناوەڕۆکی توێژینەوە یان کورتەی بابەتەکەت بنووسە..."
                          buttonLabel="دروستکردنی Abstract"
                          withFile
                          fileAccept="application/pdf,.docx,.pptx,image/*"
                        />
                      )}
                      {activeTool === "lit_review" && (
                        <AiTool
                          tool="lit_review"
                          title="Literature Review Assistant (پێداچوونەوەی ئەدەبیات)"
                          description="سەرچاوە، پوختەی توێژینەوەکان یان بابەت بنووسە بۆ بەراوردکردن، پۆلێنکردن و دۆزینەوەی Research Gap."
                          placeholder="ناونیشان، سەرچاوە یان پوختەی چەند توێژینەوەیەک لێرە دابنێ..."
                          buttonLabel="شیکاری پێداچوونەوەی ئەدەبیات"
                          withFile
                          fileAccept="application/pdf,.docx,.pptx,image/*"
                        />
                      )}
                      {activeTool === "research_question" && (
                        <AiTool
                          tool="research_question"
                          title="Research Question Generator (پرسیار و گریمانەکانی توێژینەوە)"
                          description="تەوەر و ئامانجی توێژینەوەکەت بنووسە بۆ داڕشتنی پرسیاری سەرەکی، لاوەکی و گریمانەی (H0/H1)."
                          placeholder="نموونە: کاریگەری زیرەکی دەستکرد لەسەر فێربوونی خوێندکارانی زانکۆ..."
                          buttonLabel="داڕشتنی پرسیار و گریمانەکان"
                        />
                      )}
                      {activeTool === "methodology_assistant" && (
                        <AiTool
                          tool="methodology_assistant"
                          title="Methodology Assistant (مێتۆدۆلۆژیای توێژینەوە)"
                          description="ئامانجی توێژینەوەکەت بنووسە بۆ وەرگرتنی پلانی تەواوی مێتۆدۆلۆژیا، قەبارەی نموونە و ئامرازەکانی شیکاری."
                          placeholder="تەوەر و مەبەستی توێژینەوەکەت لێرە بنووسە..."
                          buttonLabel="داڕشتنی مێتۆدۆلۆژیا"
                        />
                      )}
                      {activeTool === "citation_generator" && <CitationTool />}
                      {activeTool === "bibtex_generator" && <BibTexTool />}
                      {activeTool === "doi_citation" && <DoiCitationTool />}
                      {activeTool === "latex_word" && <LatexWordTool />}
                      {activeTool === "latex_editor" && <LatexEditorTool />}

                      {/* ── Security & QR Code Tools (7 Tools) ── */}
                      {activeTool === "qr_generator" && <QrCodeGenerator />}
                      {activeTool === "qr_scanner" && <QrCodeScanner />}
                      {activeTool === "hash_generator" && <HashGenerator />}
                      {activeTool === "base64_tool" && <Base64Tool />}
                      {activeTool === "url_encoder" && <UrlEncoderTool />}
                      {activeTool === "uuid_generator" && <UuidGenerator />}
                      {activeTool === "link_checker" && <LinksChecker />}

                      {/* ── Business Toolkit (9 Tools) ── */}
                      {activeTool === "profit_calc" && <ProfitCalculator />}
                      {activeTool === "vat_calc" && <VatCalculator />}
                      {activeTool === "salary_calc" && <SalaryCalculator />}
                      {activeTool === "discount_calc" && <DiscountCalculator />}
                      {activeTool === "loan_calc" && <LoanCalculator />}
                      {activeTool === "currency_calc" && <CurrencyConverter />}
                      {activeTool === "breakeven_calc" && <BreakEvenCalculator />}
                      {activeTool === "roi_calc" && <RoiCalculator />}
                      {activeTool === "invoice_tool" && <InvoiceGenerator initialDocType="invoice" />}
                      {activeTool === "receipt_tool" && <InvoiceGenerator initialDocType="receipt" />}
                      {activeTool === "quotation_tool" && <InvoiceGenerator initialDocType="quotation" />}
                      {activeTool === "purchase_order_tool" && <InvoiceGenerator initialDocType="purchase_order" />}
                      {activeTool === "delivery_note_tool" && <InvoiceGenerator initialDocType="delivery_note" />}

                      {/* ── Statistics Lab & Data Science ── */}
                      {activeTool === "statistics_lab" && <StatisticsLab />}

                      {/* ── Privacy Center & Trust Dashboard ── */}
                      {activeTool === "privacy_center" && <PrivacyCenter />}

                      {/* ── Study Group Room ── */}
                      {activeTool === "study_group" && <StudyGroupRoom />}

                      {/* ── AI Daily Briefing ── */}
                      {activeTool === "daily_briefing" && (
                        <AiDailyBriefing onSelectTool={(id) => openTool(id as ToolId)} />
                      )}
                    </Suspense>
                  </div>
                )}
              </>
            )}

            {/* Features - Conditional */}
            {activeExtraSection === "features" && (
              <section id="features" className="p-6 md:p-8 rounded-3xl bg-secondary/40 border border-border animate-in fade-in-50 duration-300">
                <div className="max-w-4xl">
                  <div className="mb-6">
                    <h2 className="text-2xl md:text-3xl font-extrabold">بوچی ئەم؟</h2>
                  </div>
                  <p className="text-muted-foreground mb-8 max-w-xl text-sm leading-relaxed">
                    تەکنەلۆژیا پێشکەفتی بو هاریکاریا قوتابیێن کورد.
                  </p>
                  <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5">
                    {[
                      { icon: Zap, title: "لەزا بلند", desc: "د چەند چرکەیەکێن کێمدا بەرسڤ دهێتە دان." },
                      {
                        icon: FileText,
                        title: "OCR یێ زیرەک",
                        desc: "دەقی ژ وێنە و PDFێن سکانکری دەردێخیت ب کوردی و ئینگلیزی.",
                      },
                      {
                        icon: BookOpen,
                        title: "ڕێکخستنەکا ڕێکوپێک",
                        desc: "خالێن سەرەکی، پێناسە، دەم و فۆرمول هاتینە جوداکرن.",
                      },
                    ].map((f, i) => (
                      <div
                        key={i}
                        className="rounded-2xl p-6 bg-card border border-border hover:border-primary/40 transition"
                        style={{ boxShadow: "var(--shadow-elegant)" }}
                      >
                        <div
                          className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 text-primary-foreground"
                          style={{ background: "var(--gradient-primary)" }}
                        >
                          <f.icon className="w-6 h-6" />
                        </div>
                        <h3 className="font-bold text-base mb-2">{f.title}</h3>
                        <p className="text-muted-foreground text-xs leading-relaxed">{f.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Pricing - Conditional */}
            {activeExtraSection === "pricing" && (
              <section id="pricing" className="p-6 md:p-8 rounded-3xl bg-secondary/20 border border-border animate-in fade-in-50 duration-300">
                <div className="max-w-4xl">
                  <div className="mb-6">
                    <h2 className="text-2xl md:text-3xl font-extrabold">پلانێن بهایی</h2>
                  </div>
                  <p className="text-muted-foreground mb-8 text-sm">پلانەکێ هەلبژێرە.</p>

                  <div className="grid md:grid-cols-2 gap-6 max-w-3xl">
                    {/* Free */}
                    <div className="rounded-3xl p-7 bg-card border border-border flex flex-col shadow-sm">
                      <div className="mb-6">
                        <h3 className="text-xl font-bold mb-1">پلانا بێ بەرامبەر</h3>
                        <p className="text-muted-foreground text-sm">بو تاقیکرن و بکارئینانا کێم</p>
                      </div>
                      <div className="mb-6">
                        <span className="text-5xl font-extrabold">٠</span>
                        <span className="text-muted-foreground"> دینار</span>
                      </div>
                      <ul className="space-y-3 mb-8 flex-1">
                        {[
                          "١٠ کورتە د ڕۆژەکێدا",
                          "پترین ٥٠ پەڕە بو هەر فایلەکێ",
                          "پشتەڤانیا PDF و وێنە",
                          "خالێن سەرەکی و پێناسە",
                        ].map((t) => (
                          <li key={t} className="flex items-center gap-2 text-sm">
                            <Check className="w-4 h-4 text-success shrink-0" />
                            <span>{t}</span>
                          </li>
                        ))}
                      </ul>
                      <button
                        onClick={() => setActiveExtraSection(null)}
                        className="block text-center rounded-xl border-2 border-border bg-background px-5 py-3 font-semibold hover:bg-secondary transition cursor-pointer"
                      >
                        دەستپێبکە
                      </button>
                    </div>

                    {/* VIP */}
                    <div
                      className="relative rounded-3xl p-7 text-primary-foreground flex flex-col"
                      style={{ background: "var(--gradient-hero)", boxShadow: "var(--shadow-glow)" }}
                    >
                      <div className="absolute top-4 left-4 inline-flex items-center gap-1 rounded-full bg-primary-foreground/95 text-primary px-3 py-1 text-xs font-bold">
                        <Crown className="w-3.5 h-3.5" /> یا باشترین
                      </div>
                      <div className="mb-6">
                        <h3 className="text-xl font-bold mb-1">پلانا VIP</h3>
                        <p className="text-primary-foreground/80 text-sm">بو خواندکارێن جددی</p>
                      </div>
                      <div className="mb-6">
                        <span className="text-5xl font-extrabold">٥,٠٠٠</span>
                        <span className="text-primary-foreground/80"> دینار / هەیڤ</span>
                      </div>
                      <ul className="space-y-3 mb-8 flex-1">
                        {[
                          "کورتەیا بێ سنور",
                          "پشتەڤانیا ١٥٠ پەڕی بو هەر فایلەکێ",
                          "لەزا بلندتر",
                          "پشتەڤانیا هەمی فایلان",
                          "هەمی تایبەتمەندیێن داهاتی",
                        ].map((t) => (
                          <li key={t} className="flex items-center gap-2 text-sm">
                            <Check className="w-4 h-4 shrink-0" />
                            <span>{t}</span>
                          </li>
                        ))}
                      </ul>
                      <a
                        href={WHATSAPP_URL}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 rounded-xl bg-primary-foreground text-primary px-5 py-3 font-bold hover:opacity-95 transition"
                      >
                        <MessageCircle className="w-5 h-5" />
                        چالاککرن ل واتساپێ
                      </a>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* About - Conditional */}
            {activeExtraSection === "about" && (
              <section id="about" className="p-6 md:p-8 rounded-3xl bg-secondary/40 border border-border animate-in fade-in-50 duration-300">
                <div className="max-w-4xl">
                  <div className="grid md:grid-cols-2 gap-10 items-center">
                    <div className="relative flex justify-center md:justify-end">
                      <div
                        className="absolute -inset-4 rounded-3xl opacity-40 blur-2xl"
                        style={{ background: "var(--gradient-primary)" }}
                      />
                      <div
                        className="relative rounded-3xl overflow-hidden border-4 border-card w-44 h-56 md:w-52 md:h-64"
                        style={{ boxShadow: "var(--shadow-glow)" }}
                      >
                        <img
                          src={sangarImgUrl}
                          alt="سەنگەر محمد حەسەن"
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="inline-flex items-center gap-2 rounded-full bg-accent/60 px-3 py-1 text-xs font-semibold text-accent-foreground mb-4">
                        <GraduationCap className="w-3.5 h-3.5" />
                        <span>دامەزرینەر</span>
                      </div>
                      <h3 className="text-2xl md:text-3xl font-extrabold mb-2">سەنگەر محمد حەسەن</h3>
                      <p className="text-muted-foreground font-semibold mb-5 text-sm">
                        باوەرنامەیا ماستەر ب زانستێن بیرکاری
                      </p>
                      <p className="text-sm md:text-base leading-relaxed text-foreground/90 mb-5">
                        ئارمانجا من پێشخستنا خواندنێیە ب هاریکاریا زیرەکیا دەستکرد، داکو قوتابیێن هێژا بشێن
                        ب ساناهی و بلەز فێربن و دەرفەتێن باشتر بدەست ڤە بینن.
                      </p>
                      <a
                        href="mailto:sangarduhok@gmail.com"
                        className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline mb-4"
                        dir="ltr"
                      >
                        <Mail className="w-4 h-4" />
                        sangarduhok@gmail.com
                      </a>
                      <div className="flex items-center gap-3 justify-end">
                        <a
                          href="https://www.instagram.com/sangar__98?igsh=NHgxbzY2bGQ5M2I0&utm_source=qr"
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label="Instagram"
                          className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition"
                        >
                          <Instagram className="w-5 h-5" />
                        </a>
                        <a
                          href="https://www.facebook.com/share/1DrTW5Z1ik/?mibextid=wwXIfr"
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label="Facebook"
                          className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition"
                        >
                          <Facebook className="w-5 h-5" />
                        </a>
                        <a
                          href="mailto:sangarduhok@gmail.com"
                          aria-label="Email"
                          className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition"
                        >
                          <Mail className="w-5 h-5" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            )}
          </main>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-6 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs md:text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-lg flex items-center justify-center shadow-sm"
              style={{ background: "var(--gradient-primary)" }}
            >
              <Brain className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-bold text-foreground">کورتەیا AI</span>
          </div>

          <div className="inline-flex items-center gap-1.5 rounded-full bg-accent/60 border border-accent/40 px-3.5 py-1 text-xs font-semibold text-accent-foreground shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span>پشتەڤانیکری ژ لایێ زیرەکیا دەستکرد</span>
          </div>

          <p>© {new Date().getFullYear()} — هەمی ماف پاراستینە بۆ Sangar Mohammed</p>
        </div>
      </footer>
    </div>
  );
}
