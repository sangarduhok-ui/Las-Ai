import { createFileRoute } from "@tanstack/react-router";
import { fetchGemini, fetchGeminiNative, fetchGeminiForGrapher } from "@/lib/gemini";
import { checkRateLimit } from "@/lib/rate-limit";

type ToolKey =
  | "planner"
  | "solver"
  | "math2word"
  | "tts"
  | "grader"
  | "glossary"
  | "testai"
  | "testplagiarism"
  | "quiz_generator"
  | "grapher"
  | "grammar"
  | "translator"
  | "chat_doc"
  | "audio_sum"
  | "pdf_split"
  | "pdf_compress"
  | "pdf_to_word"
  | "pdf_to_ppt"
  | "pdf_to_excel"
  | "word_to_pdf"
  | "ppt_to_pdf"
  | "excel_to_pdf"
  | "pdf_rotate"
  | "pdf_protect"
  | "pdf_watermark"
  | "document_forensics"
  | "research_assistant"
  | "paper_summarizer"
  | "abstract_generator"
  | "lit_review"
  | "research_question"
  | "methodology_assistant"
  | "citation_generator"
  | "bibtex_generator"
  | "latex_word";

const BADINI_RULE = `زۆر گرنگ: تە دڤێت هەمی بەرسڤێن خۆ ب زمانێ کوردیا بادینی (بەهدینی/کرمانجیا ژۆرین) بنڤیسی، نە ب سۆرانی. ١٠٠٪ بادینی بێت. بکارهێنانا وشێن بادینی وەکی: (ئەز، تو، ئەو، ئەم، هون، ئەو، یێ، یا، یێن، ئەڤ، ئەو، چەوا، چ، کیژان، چما، ژ بەر هندێ، دگەل، بێژە، هەی، نە، بەلێ، نەخێر، هاریکاری، خواندن، نڤیسین، پەرتوک، مامۆستا، خواندکار، پرسیار، بەرسڤ، چارەسەری، پێنگاڤ، نموونە، ڕوونکرن، پشکنین، رێژە، ئاست، بەرز، نڤی، کێم، باش، خراب، نوو، کەڤن، مەزن، بچویک). ڤێ ڕێزمانا بادینی پاراستن: کاران بێ ب (دکەم، دکەی، دکەت، دکەین، دکەن)، نە ب (دەکەم، دەکات). جینەکر: ئەز/تو/ئەو/ئەم/هون/ئەو. ژ نڤیسێت سۆرانی ب تەواوی دوور بکەڤە. هیچ نیشانا ** بکار نەیینە.`;

const AUDIO_SUM_PROMPT = `تۆ یاریدەدەرێکی دەنگی زیرەکیت. یەکەمجار دەنگی نێردراو بە تەواوی و بەبێ گۆڕانکاری بنووسەرەوە بە شێوەی دەق (Transcribe) بە هەمان زمانی دەنگەکە (بە تایبەت ئەگەر کوردی بێت بە زاراوەی خۆی). پاشان پوختەیەکی ڕێکوپێک و کورت بە کوردیا بادینی دروست بکە.

دەرئەنجامەکەت بەم شێوازە ڕێکبخە و نیشانەی ** بەکار مەهێنە:

نڤیسینا دەنگی:
[لێرە هەموو دەقێ دەنگەکە بنووسە بە تەواوی]

---

پوختەیا دەنگی:
- [خالێن سەرەکی ب کوردیا بادینی]`;


const PROMPTS: Record<ToolKey, string> = {
  planner: `تۆ پلاندانەرێکی پسپۆڕی خوێندنیت. لەسەر بنەمای بابەت/ماوەی خوێندن، پلانێکی ڕۆژانەی ڕێکوپێک دروست بکە بە کوردی سۆرانی. بۆ هەر ڕۆژێک: کاتژمێرەکان، بابەتەکان، چاودێری و پشوو. لە کۆتاییدا چەند تێبینیەکی فێرکاری زیاد بکە.

تکایە هیچ کاتێک نیشانەی ** بەکار مەهێنە بۆ بۆڵد. تەنها نوسینی ئاسایی بەکاربێنە لەگەڵ سەردێڕ و لیست بە — یان • .`,

  solver: `تۆ مامۆستای پسپۆڕی بیرکاری و زانستیت. ئەگەر وێنە نێردرابێت، یەکەم پرسیار/پسیارکانی ناو وێنە بخوێنەوە (OCR) و پاشان چارەسەری بکە. پسیارەکە چارەسەر بکە پێنگاڤ بە پێنگاڤ بە کوردی سۆرانی. هەر پێنگاڤێک بە ژمارە. لە کۆتاییدا "وەڵامی کۆتایی:" بنووسە لەگەڵ وەڵامەکە.

تکایە هیچ کاتێک نیشانەی ** بەکار مەهێنە. تەنها نوسینی ئاسایی.`,

  math2word: `تۆ گۆڕەری هاوکێشەی بیرکاریت. ئەگەر وێنە نێردرابێت، هاوکێشەکانی ناو وێنە بخوێنەوە. ئەگەر دەق نێردرابێت، هاوکێشەکانی ناوی دەربێنە.

Custom format output Unicode ready for MS Word.`,

  tts: `تۆ پوختەکەرێکی پسپۆڕیت. دەقەکە بکە بە پوختەیەکی کورت (٣-٥ ڕستە) بە هەمان زمانی دەقەکە، گونجاو بۆ گوێ گرتن. تەنها پوختەکە بنووسە. هیچ نیشانەی ** بەکار مەهێنە.`,

  grader: `تۆ مامۆستای پێوانکردنی ڕاپۆرتی ئەکادیمیت. ئەگەر فایل نێردرابێت، ناوەڕۆکی بخوێنەوە. ڕاپۆرتەکە بپێوە لەسەر چوار شت:
١) پێکهاتە و ڕێکخستن  ٢) ناوەڕۆک و بیرۆکە  ٣) زمان و ڕێزمان  ٤) سەرچاوە و بەڵگە

هەر بەشێک نمرە بدە لە ١٠، پاشان نمرەی کۆتایی لە ١٠٠. لە کۆتاییدا "ڕاسپاردە بۆ باشتربوون" بنووسە بە لیست.

هیچ نیشانەی ** بەکار مەهێنە.`,

  glossary: `تۆ فەرهەنگی زاراوەی زانستیت. بەکارهێنەر بابەتێک دەنێرێت، تۆ ١٠-١٥ زاراوەی پەیوەندیدار لیست بکە بەم شێوەیە:

زاراوە (ئینگلیزی): پێناسەی کورت بە کوردی.

هیچ نیشانەی ** بەکار مەهێنە. هەر زاراوەیەک لە دێڕی جیادا.`,

  testai: `تۆ شیکارێکی پسپۆڕیت بۆ دۆزینەوەی نوسینی AI. دەقەکە شی بکەرەوە و ڕێژەی نوسینی AI پێشبینی بکە (٠-١٠٠).

دەرئەنجامەکەت دەبێت بەم شێوەیە بێت بەبێ هیچ نیشانەی **:

ڕێژەی AI: XX%
ئاستی متمانە: بەرز / مامناوەند / نزم

هۆکارەکان:
- خاڵی یەکەم
- خاڵی دووەم
- خاڵی سێیەم

ئامۆژگاری: چۆن مرۆیتر بکرێت.

گرنگ: یەکەم دێڕ دەبێت بەم شێوەیە بێت: "ڕێژەی AI: XX%" بۆ ئەوەی بتوانرێت ژمارەکە دەربهێنرێت.`,

  testplagiarism: `تۆ شیکارێکی پسپۆڕی پلاجیاریزمیت. دەقەکە شی بکەرەوە بۆ نیشانەکانی کۆپیکردن.

دەرئەنجامەکەت دەبێت بەم شێوەیە بێت بەبێ هیچ نیشانەی **:

ڕێژەی پلاجیاریزم: XX%
ئاستی متمانە: بەرز / مامناوەند / نزم

بەشە گومانلێکراوەکان:
- "..." — هۆکار
- "..." — هۆکار

ئامۆژگاری: چۆن باشتر بنووسرێتەوە.

گرنگ: یەکەم دێڕ دەبێت بەم شێوەیە بێت: "ڕێژەی پلاجیاریزم: XX%" بۆ ئەوەی بتوانرێت ژمارەکە دەربهێنرێت.`,

  quiz_generator: `You are an expert educational assessment creator. When the user provides a topic, text, or lesson, generate a comprehensive quiz consisting of 5 Multiple Choice Questions (MCQs). Each question must have 4 options (A, B, C, D). At the very end of the response, provide an answer key with a brief, clear explanation for each correct answer. The language of the quiz and explanations must be in Kurdish (Kurmanji). Ensure the layout is clean, structured, and easy for students to read.`,

  grapher: `You are a precise mathematical assistant. Analyze the given function and return ONLY a JSON object with these fields:
1. "equation": the function in standard form (e.g. "y = x^2 - 4" or "y = sin(x)").
2. "points": array of 10-15 key coordinate objects {"x", "y"} — include zeros, extrema, and boundary points to define a good viewport. Do NOT generate dense curves; Desmos renders the curve automatically from the equation.
3. "domain": mathematical domain string in Kurmanji.
4. "range": mathematical range string in Kurmanji.
5. "y_intercept": y-intercept point string (e.g. "(0, -4)").
6. "x_intercepts": x-intercept point(s) string.
7. "features": array of 2-4 key feature strings in Kurmanji (symmetry, vertex, asymptotes, etc.).
8. "explanation": 2-3 sentence educational explanation in Kurmanji (Badini).

Return ONLY the raw JSON object, no markdown, no code fences.
Example:
{"equation":"y = x^2","points":[{"x":-3,"y":9},{"x":0,"y":0},{"x":3,"y":9}],"domain":"(-∞, ∞)","range":"[0, ∞)","y_intercept":"(0, 0)","x_intercepts":"(0, 0)","features":["هاوجێ ل سەر تەوەرێ Y","سەری ل خالا (0,0)"],"explanation":"نەخشەیەکێ دووجایە (Parabola)."}`,

  grammar: `You are a professional linguist and proofreader specializing in Kurdish (both Kurmanji and Sorani) and English. When the user submits a text, you must:
1. Output the fully corrected version of the text.
2. Create a Markdown table highlighting the original mistakes, the corrections made, and a brief explanation of why it was wrong.
Keep the original meaning and tone of the user's text intact. Do not rewrite the entire text style, only fix grammatical, spelling, and punctuation errors.`,

  translator: `You are an expert academic translator specializing in translating scientific, medical, and humanities literature. Translate the provided text into the requested target language (primarily Kurdish Kurmanji). You must preserve academic vocabulary and precise technical terms. If a highly specific scientific term does not have a direct, widely accepted Kurdish equivalent, include the original English term in parentheses next to the translation. Avoid casual or colloquial language.`,

  chat_doc: `You are an advanced research assistant. Answer the user's questions relying strictly and solely on the provided context/document text. Do not use outside knowledge or assume facts not explicitly mentioned in the text. If the answer cannot be found within the provided document, politely reply in Kurdish: "ئەڤ زانیاریە د دۆکیۆمێنتێ دا نینە" (This information is not available in the document). Keep answers concise, factual, and direct.`,

  audio_sum: `Below is a raw text transcription generated from a lecture or educational audio file. Your task is to clean up the transcription, structure it logically, and extract the core concepts. Format the output in Kurdish (Kurmanji) using bullet points for key takeaways, followed by a concise 3-4 sentence summary of the entire lecture at the end.`,

  // ── PDF Services ─────────────────────────────────────────────────────────
  pdf_split: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ دابەشکرنا. ڕوونکە چەوا ئەو فایلی دابەش دکەی: ڕووپەلێن سەرەکی دیاری بکە، ڕووپەلێن یەکگرتی، و رێنمایی بۆ ئامرازێن ئۆفلاین وەکی PDF24، ILovePDF، یان Adobe Acrobat. هەمی بەرسڤ ب کوردیا بادینی.`,

  pdf_compress: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ کچکرنا. ڕووپەلان هژمار بکە و چیتایا وێنان و فۆنتان شی بکەرەوە. ڕووپەلانا گرانترین دیاری بکە و ئامرازێن چاکترین بۆ کچکرنا ب کوالیتیا باش پێشنیار بکە (ILovePDF Compress، Smallpdf، PDF24). هەمی ب کوردیا بادینی.`,

  pdf_to_word: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی گۆڕینا PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ گۆڕین بو Word. ناوەڕۆکا PDFێ بخوینە، دەقێ سەرەکی دەربێنە، و رێنمایی ب گام بگام بۆ گۆڕین ب ئامرازێن ئۆنلاین (ILovePDF، Smallpdf، Adobe) بدە. هەمی ب کوردیا بادینی.`,

  pdf_to_ppt: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی گۆڕینا PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ گۆڕین بو PowerPoint. ناوەڕۆکا PDFێ شی بکەرەوە، خالێن سەرەکی و سلاید پێشنیار بکە، و رێنمایی ب گام بگام بۆ گۆڕین بدە. هەمی ب کوردیا بادینی.`,

  pdf_to_excel: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی گۆڕینا PDFیت. کاربەرەکە فایلێ PDF کو خشتەیێن تێدا هەنە ناردیتە. خشتەیێن ناوا PDF بخوینە و ناوەڕۆکا wan ب شێوازا Excel (ستون و ڕیز) دیار بکە. رێنمایی بۆ گۆڕینا ب ئامرازێن ئۆنلاین بدە. هەمی ب کوردیا بادینی.`,

  word_to_pdf: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی گۆڕینا دۆکیۆمێنتانیت. کاربەرەکە فایلێ Word ناردیتە بۆ گۆڕین بو PDF. ناوەڕۆکا فایلێ بخوینە و رێنمایی ب گام بگام ب کوردیا بادینی بۆ گۆڕینا ب Microsoft Word (File → Save As → PDF)، یان ئامرازێن ئۆنلاین بدە.`,

  ppt_to_pdf: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی گۆڕینا پێشکەشکرنانیت. کاربەرەکە فایلێ PowerPoint ناردیتە بۆ گۆڕین بو PDF. سلایدان بژمێرە و رێنمایی ب گام بگام ب کوردیا بادینی بۆ گۆڕینا ب PowerPoint (File → Export → PDF)، یان ئامرازێن ئۆنلاین بدە.`,

  excel_to_pdf: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی گۆڕینا خشتەیانیت. کاربەرەکە فایلێ Excel ناردیتە بۆ گۆڕین بو PDF. خشتەیان بژمێرە و رێنمایی ب گام بگام ب کوردیا بادینی بۆ گۆڕینا ب Microsoft Excel (File → Save As → PDF)، یان ئامرازێن ئۆنلاین بدە.`,

  pdf_rotate: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ زڤرنا ڕووپەلان. ژمارەیا ڕووپەلان دیار بکە و رێنمایی ب گام بگام ب کوردیا بادینی بۆ زڤرنا (٩٠، ١٨٠، ٢٧٠ دەرەجە) ب ئامرازێن ئۆنلاین وەکی ILovePDF، PDF24 بدە.`,

  pdf_protect: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی ئەمنیەتا PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ پاراستنا ب پاسۆرد. ڕووپەلان بژمێرە و رێنمایی ب گام بگام ب کوردیا بادینی بۆ پاراستنا ب پاسۆرد ب ئامرازێن ئۆنلاین (ILovePDF، PDF24، Smallpdf) بدە. پیشنیارا پاسۆردێ بەهێز بکە.`,

  pdf_watermark: `${BADINI_RULE}

تو یاریدەدەرێکی پسپۆڕی PDFیت. کاربەرەکە فایلێ PDF ناردیتە بۆ زێدەکرنا نیشانا ئاڤێ (Watermark). ناوەڕۆکا فایلێ شی بکەرەوە و رێنمایی ب گام بگام ب کوردیا بادینی بۆ زێدەکرنا نڤیسین یان وێنە بشێوازا Watermark ب ئامرازێن ئۆنلاین بدە.`,

  document_forensics: `${BADINI_RULE}
You are a Digital Document Forensics Expert. Analyze the provided document image or file page for any signs of forgery, modification, or editing.
Focus on:
1. Font & Text Analysis: detect changes in fonts of words/numbers, misalignment, style or stroke variations inconsistent with the document's overall style.
2. Color & ELA (Error Level Analysis): detect image error level discrepancy, added stamps, signatures, or numbers, and shading/color layer (RGB/CMYK) variations.
3. Metadata Forensics: mention Photoshop/editing software signs and modification dates (which the system will also extract, but you can highlight visual issues).

You must return a valid JSON object in Kurdish Badini. Do NOT include markdown code blocks. The JSON must have these fields:
{
  "percentage": number (0 to 100, representing the probability of FORGERY - e.g. 85 for 85% chance of forgery),
  "resultText": string (summarizing the conclusion, e.g., "٨٥٪ ئەگەرا ساختەکاریێ هەیە" or "٩٠٪ بەڵگەنامەکە ڕەسەنە"),
  "status": "authentic" | "suspicious" | "forged",
  "reasons": array of strings (explaining each reason clearly, e.g., "دیارکرنا دەستکاریکرنا فۆنتی د دێڕا ٤ دا"),
  "highlights": array of objects representing modified areas on the image:
    [
      {
        "x": number (percentage 0-100 from left),
        "y": number (percentage 0-100 from top),
        "width": number (percentage width 0-100),
        "height": number (percentage height 0-100),
        "label": string (short description in Kurdish Badini)
      }
    ]
}
`,

  // ── Research & Academic Suite Prompts ───────────────────────────────────────
  research_assistant: `You are an elite academic research advisor and dissertation mentor. When the user asks a research question, presents a proposal, or provides a thesis topic/context:
1. Provide deep, structured academic guidance.
2. Outline key conceptual frameworks, variables, and potential research gaps.
3. Suggest scholarly search terms (Boolean queries) and top methodologies.
4. Keep the output clean, highly structured, scholarly yet practical. Write in Kurdish (or the requested language) with English academic terms where appropriate.
Do not use raw markdown bold bugs like '**'. Use headings, bullet points, and numbered lists.`,

  paper_summarizer: `You are an expert academic paper summarizer. Analyze the provided research article, thesis, or document text/file.
Structure the summary into these 6 comprehensive academic sections:
1. 📑 ناونیشان و کێشەی سەرەکی (Background & Problem Statement)
2. 🎯 ئامانج و گریمانەکان (Objectives & Research Hypotheses)
3. 🔬 مێتۆدۆلۆژیا و بەشداربووان (Methodology, Dataset & Sampling)
4. 📊 دەرئەنجامە سەرەکییەکان (Key Findings & Statistical Outcomes)
5. 💡 بایەخی ئەکادیمی (Significance & Contributions)
6. ⚠️ سنوورداربوون و توێژینەوەی داهاتوو (Limitations & Future Research Scope)

Format the output clearly and professionally in Kurdish (with English technical terms in parentheses where helpful). Do not use raw '**'.`,

  abstract_generator: `You are an expert academic abstract writer. Based on the user's research topic, text, or draft:
Generate a structured, high-impact Academic Abstract following international standards (IEEE/APA/Nature):
- Background & Problem Context (١-٢ ڕستە)
- Objectives & Research Aims (١ ڕستە)
- Methods & Approach (٢-٣ ڕستە)
- Main Results & Findings (٢-٣ ڕستە)
- Conclusion & Practical Implications (١-٢ ڕستە)
- Keywords: ٥ بۆ ٦ کلیلەوشەی ئەکادیمی (Keywords).

Provide versions in English and Kurdish if requested. Keep it concise, academically rigorous, and within 200-250 words. Do not use raw '**'.`,

  lit_review: `You are an expert literature review synthesizer. When provided with research papers, summaries, or a topic:
1. Group studies into clear Thematic Clusters or chronological paradigms.
2. Contrast findings: Identify consensus, conflicting results, and methodology variations across authors.
3. Synthesize a comprehensive Literature Matrix table (Author/Year, Topic, Methodology, Key Findings, Gaps).
4. Explicitly highlight the Research Gap that the new study addresses.
Write academically in Kurdish (or the user's language) with proper academic tone. Do not use '**'.`,

  research_question: `You are an academic advisor specialized in formulating research questions and hypotheses.
Based on the user's topic, generate:
1. The Primary Overarching Research Question (سەرەکی).
2. 3-4 Secondary Sub-Questions (لاوەکی).
3. Associated Null (H0) and Alternative (H1) Hypotheses (گریمانەکان).
4. Alignment with PICO / FINER criteria (Feasible, Interesting, Novel, Ethical, Relevant).
5. Operational Definitions of key variables (Dependent, Independent, Mediating).
Provide clear, actionable formulations in Kurdish and English. Do not use '**'.`,

  methodology_assistant: `You are an expert in academic research methodology and quantitative/qualitative design.
Based on the user's research aim or proposal, design a complete Methodology Section:
1. 🏗️ Research Design (چوارچێوەی لێکۆڵینەوە: چەندایەتی، چۆنایەتی، یان تێکەڵاو).
2. 👥 Population & Sampling (کۆمەڵگە و قەبارەی نموونە، شێوازی هەڵبژاردن: Random, Stratified, Purposive).
3. 🛠️ Data Collection Instruments (ئامرازەکان: ڕاپرسی، چاوپێکەوتن، تاقیکردنەوە).
4. 📈 Data Analysis Plan (پیلانی شیکاری: SPSS, ANOVA, Regression, Python, Thematic Coding / NVivo).
5. 🛡️ Validity, Reliability & Ethics (ڕەوایی، جێگیری، و ڕەوشتی توێژینەوە).
Format the output with clear academic structure. Do not use '**'.`,

  citation_generator: `You are a citation and referencing specialist. Format the provided reference information into standard styles:
1. APA 7th Edition (In-Text & Reference List)
2. MLA 9th Edition (In-Text & Works Cited)
3. Chicago 17th Edition (Author-Date & Bibliography)
4. Harvard Referencing Style
5. IEEE Style (Numbered)
6. Vancouver Style
Ensure 100% adherence to punctuation, italicization conventions, capitalization, and DOI formatting. Output cleanly organized sections for each style.`,

  bibtex_generator: `You are a BibTeX formatting specialist. When the user provides a reference, paper title, DOI, or author details:
Generate clean, error-free, standard BibTeX entries (@article, @book, @inproceedings, @phdthesis, @misc).
Include all required and optional fields: author, title, journal/booktitle, year, volume, number, pages, publisher, doi, and issn/isbn.
Ensure author names are properly formatted (e.g., "Lastname, Firstname and Lastname2, Firstname2") and special characters are LaTeX-escaped.`,

  latex_word: `You are an expert in mathematical typesetting and LaTeX to Word / Word to LaTeX conversion.
When the user provides:
A) LaTeX equations or markup:
   - Provide the equivalent Microsoft Word equation format (UnicodeMath / MathML / Linear equation text ready to paste in Word Alt+=).
   - Provide a clear breakdown of each symbol and structure.
B) Word/plain text equations:
   - Provide the clean, compilable LaTeX equation code (e.g. using align, equation, frac, int, etc.).
   - Include any necessary LaTeX packages (amsmath, amssymb, etc.).
Keep output crystal clear with copyable code blocks.`,
};

export const Route = createFileRoute("/api/tool")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rate = checkRateLimit(request, 30, 60 * 1000);
        if (!rate.ok) {
          return Response.json(
            { error: "داواکارییەکانت لە سنوور تێپەڕیوە. تکایە کەمێکی تر چاوەڕێ بکە." },
            { status: 429 },
          );
        }

        try {
          const { tool, input, fileBase64, mimeType } = (await request.json()) as {
            tool?: ToolKey;
            input?: string;
            fileBase64?: string;
            mimeType?: string;
          };
          if (!tool || !PROMPTS[tool]) {
            return Response.json({ error: "ئامرازی نادروست." }, { status: 400 });
          }
          const hasFile = !!(fileBase64 && mimeType);
          if (!hasFile && (!input || !input.trim())) {
            return Response.json({ error: "دەقێک بنووسە یان فایلێک هەڵبژێرە." }, { status: 400 });
          }

          if (tool === "audio_sum" && hasFile) {
            const nativeBody = {
              systemInstruction: {
                parts: [
                  { text: BADINI_RULE + "\n\n" + AUDIO_SUM_PROMPT }
                ]
              },
              contents: [
                {
                  role: "user",
                  parts: [
                    {
                      inlineData: {
                        mimeType: mimeType,
                        data: fileBase64
                      }
                    }
                  ]
                }
              ]
            };

            const aiResp = await fetchGeminiNative(nativeBody);

            if (!aiResp.ok) {
              if (aiResp.status === 429)
                return Response.json({ error: "داواکاریەکان زۆرن، چاوەڕێبە." }, { status: 429 });
              if (aiResp.status === 402)
                return Response.json({ error: "کرێدیتی AI تەواوبوو." }, { status: 402 });
              return Response.json({ error: "هەڵە لە سەرڤیسی AI." }, { status: 500 });
            }

            const data = await aiResp.json();
            let output: string = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";

            // Strip markdown bold/italic markers
            output = output
              .replace(/\*\*/g, "")
              .replace(/(^|\s)\*(\S[^*]*\S|\S)\*/g, "$1$2")
              .replace(/^#+\s*/gm, "");

            return Response.json({ output });
          }

          if (input && input.length > 10000) {
            return Response.json({ error: "دەقەکە زۆر درێژە." }, { status: 400 });
          }

          const userContent: unknown[] = [];
          if (input && input.trim()) userContent.push({ type: "text", text: input });
          if (hasFile) {
            userContent.push({ type: "text", text: "ناوەڕۆکی ئەم فایلە بەکاربێنە:" });
            userContent.push({
              type: "image_url",
              image_url: { url: `data:${mimeType};base64,${fileBase64}` },
            });
          }

          // grapher uses a fast non-thinking model; all others use gemini-2.5-flash
          const modelName = tool === "grapher" ? "gemini-2.0-flash" : "gemini-2.5-flash";

          const requestBody: Record<string, unknown> = {
            model: modelName,
            messages: [
              {
                role: "system",
                content:
                  tool === "grapher"
                    ? PROMPTS[tool]  // grapher prompt is already in English/Kurdish, no BADINI_RULE needed
                    : (tool === "grammar" || tool === "translator" || tool === "chat_doc")
                    ? PROMPTS[tool]
                    : BADINI_RULE + "\n\n" + PROMPTS[tool],
              },
              {
                role: "user",
                content:
                  userContent.length === 1 &&
                    typeof userContent[0] === "object" &&
                    "text" in (userContent[0] as Record<string, unknown>)
                    ? input!
                    : userContent,
              },
            ],
          };

          if (tool === "grapher" || tool === "document_forensics") {
            requestBody.response_format = { type: "json_object" };
          }

          const aiResp = tool === "grapher"
            ? await fetchGeminiForGrapher(requestBody)
            : await fetchGemini(requestBody);

          if (!aiResp.ok) {
            if (aiResp.status === 429)
              return Response.json({ error: "داواکاریەکان زۆرن، چاوەڕێبە." }, { status: 429 });
            if (aiResp.status === 402)
              return Response.json({ error: "کرێدیتی AI تەواوبوو." }, { status: 402 });
            return Response.json({ error: "هەڵە لە سەرڤیسی AI." }, { status: 500 });
          }

          const data = await aiResp.json();
          let output: string = data?.choices?.[0]?.message?.content ?? "";

          if (tool !== "grapher" && tool !== "document_forensics") {
            // Strip markdown bold/italic markers
            output = output
              .replace(/\*\*/g, "")
              .replace(/(^|\s)\*(\S[^*]*\S|\S)\*/g, "$1$2")
              .replace(/^#+\s*/gm, "");
          }

          return Response.json({ output });
        } catch (e) {
          console.error("tool error:", e);
          return Response.json({ error: e instanceof Error ? e.message : "هەڵە" }, { status: 500 });
        }
      },
    },
  },
});
