import { createFileRoute } from "@tanstack/react-router";
import { fetchGemini } from "@/lib/gemini";
import { parseOffice, SupportedFileType } from "officeparser";
import { checkRateLimit } from "@/lib/rate-limit";

const SYSTEM_PROMPT = `تۆ یاریدەدەرێکی پەروەردەیی زیرەکیت. لە بەڵگەنامەی پێشکەشکراو (PDF، وێنە، یان فایلی ئۆفیس) دەقەکە دەردەهێنیت بە OCR ئەگەر پێویست بێت، پاشان پوختەیەکی ڕێکوپێک دروست دەکەیت بە زمانی کوردی سۆرانی.
هەمیشە بە شێوەی JSON تەنیا وەڵام بدەرەوە بەم پێکهاتەیە (بێ هیچ markdown):
{
  "title": "ناونیشانی کورت",
  "language_detected": "ku" | "en" | "mixed",
  "main_points": ["خاڵی سەرەکی ١", "..."],
  "definitions": [{"term": "زاراوە", "definition": "پێناسە"}],
  "dates_formulas": ["ڕێکەوت یان فۆرمول ١", "..."]
}
هەرگیز هیچ شتێک لە دەرەوەی JSON مەنوسە.`;

export const Route = createFileRoute("/api/summarize")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rate = checkRateLimit(request, 25, 60 * 1000);
        if (!rate.ok) {
          return Response.json(
            { error: "داواکارییەکانت لە سنوور تێپەڕیوە. تکایە کەمێکی تر چاوەڕێ بکە." },
            { status: 429 },
          );
        }

        try {
          const body = (await request.json()) as {
            fileBase64?: string;
            mimeType?: string;
            fileName?: string;
          };

          if (!body.fileBase64 || !body.mimeType) {
            return Response.json({ error: "فایل نەنێردراوە." }, { status: 400 });
          }

          const isImage = body.mimeType.startsWith("image/");
          const isPdf = body.mimeType === "application/pdf";
          const isOffice = [
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-powerpoint",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation"
          ].includes(body.mimeType) || 
          /\.(docx?|xlsx?|pptx?)$/i.test(body.fileName || "");

          if (!isImage && !isPdf && !isOffice) {
            return Response.json({ error: "تەنیا PDF، وێنە یان فایلی ئۆفیس قبوڵە." }, { status: 400 });
          }

          let userContent: any;

          if (isOffice) {
            let extractedText = "";
            try {
              const buffer = Buffer.from(body.fileBase64, "base64");
              let fileType: SupportedFileType = "docx";
              const ext = body.fileName?.split(".").pop()?.toLowerCase();
              if (ext && ["docx", "doc", "xlsx", "xls", "pptx", "ppt"].includes(ext)) {
                fileType = ext as SupportedFileType;
              }
              const ast = await parseOffice(buffer, { fileType });
              extractedText = (await ast.to("text")).value;
            } catch (parseError) {
              console.error("Office parsing error:", parseError);
              return Response.json({ error: "نەتوانرا دەقی فایلەکە شیبکرێتەوە." }, { status: 500 });
            }

            userContent = `دەقی ئەم فایلە بخوێنەوە و پوختەیەکی ڕێکوپێک بۆ خوێندکار دروست بکە بە JSON:
---
${extractedText}
---`;
          } else {
            userContent = [
              {
                type: "text",
                text: "ئەم بەڵگەنامەیە بخوێنەوە و پوختەیەکی ڕێکوپێک بۆ خوێندکار دروست بکە بە JSON.",
              },
              {
                type: "image_url",
                image_url: { url: `data:${body.mimeType};base64,${body.fileBase64}` },
              },
            ];
          }

          const aiResp = await fetchGemini({
            model: "gemini-2.5-flash",
            messages: [
              { role: "system", content: SYSTEM_PROMPT },
              { role: "user", content: userContent },
            ],
            response_format: { type: "json_object" },
          });

          if (!aiResp.ok) {
            if (aiResp.status === 429) {
              return Response.json(
                { error: "داواکاریەکان زۆرن، تکایە چەند چرکەیەک چاوەڕێبە." },
                { status: 429 },
              );
            }
            if (aiResp.status === 402) {
              return Response.json(
                { error: "کرێدیتی AI تەواوبوو. تکایە پلانێکی VIP چالاک بکە." },
                { status: 402 },
              );
            }
            const t = await aiResp.text();
            console.error("AI error:", aiResp.status, t);
            return Response.json({ error: "هەڵە لە سەرڤیسی AI." }, { status: 500 });
          }

          const data = await aiResp.json();
          const raw = data?.choices?.[0]?.message?.content ?? "";
          let parsed: unknown;
          try {
            parsed = JSON.parse(raw);
          } catch {
            const m = raw.match(/\{[\s\S]*\}/);
            parsed = m ? JSON.parse(m[0]) : null;
          }

          if (!parsed) {
            return Response.json({ error: "نەتوانرا پوختە دروست بکرێت." }, { status: 500 });
          }

          return Response.json({ summary: parsed });
        } catch (e) {
          console.error("summarize error:", e);
          return Response.json(
            { error: e instanceof Error ? e.message : "هەڵەیەکی نەزانراو" },
            { status: 500 },
          );
        }
      },
    },
  },
});
