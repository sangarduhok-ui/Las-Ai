import { createFileRoute } from "@tanstack/react-router";
import { fetchGemini } from "@/lib/gemini";
import { parseOffice, SupportedFileType } from "officeparser";
import { checkRateLimit } from "@/lib/rate-limit";

const SYSTEM_PROMPT = `تو هاریکارەکێ زیرەکی بو خواندکاران ب ناڤێ "پوختەیا AI". هەمی دەمێ ب زمانێ کوردیا بادینی (بەهدینی/کرمانجیا ژۆرین) بەرسڤا پرسیاران بدە، ب شێوەیەکێ ڕوون, کورت و بسود. هەرگیز ب سۆرانی نەنڤیسە. تنێ ئەگەر پرسیار ب ئینگلیزی یان عەرەبی هاتبیت، ب هەمان زمانی بەرسڤێ بدە. بکارهێنانا وشێن بادینی وەکی (هەی، نە، ئەڤە، ئەو، چەوا، چ، کیژان، چما، ژ بەر هندێ، دگەل، بێژە، ب کێ, نڤیسین، خواندن، هاریکاری، فێرکاری) پێشخستن بکە. نموونان ب بادینی بدە.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rate = checkRateLimit(request, 30, 60 * 1000);
        if (!rate.ok) {
          return Response.json(
            { error: "داواکارییەکانت لە سنوور تێپەڕیوە. تکایە کەمێکی تر چاوەڕێ بکە." },
            { status: 429 },
          );
        }

        try {
          const { messages, fileBase64, mimeType, fileName, systemPrompt } = (await request.json()) as {
            messages?: Array<{ role: "user" | "assistant"; content: string }>;
            fileBase64?: string;
            mimeType?: string;
            fileName?: string;
            systemPrompt?: string;
          };

          if (!messages || !Array.isArray(messages) || messages.length === 0) {
            return Response.json({ error: "پەیامێک نەنێردراوە." }, { status: 400 });
          }

          let geminiMessages: any[] = [];
          if (fileBase64 && mimeType) {
            const DOC_SYSTEM_PROMPT = `You are an advanced research assistant. Answer the user's questions relying strictly and solely on the provided context/document text. Do not use outside knowledge or assume facts not explicitly mentioned in the text. If the answer cannot be found within the provided document, politely reply in Kurdish: "ئەڤ زانیاریە د دۆکیۆمێنتێ دا نینە" (This information is not available in the document). Keep answers concise, factual, and direct.`;

            const isOffice = [
              "application/msword",
              "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              "application/vnd.ms-excel",
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              "application/vnd.ms-powerpoint",
              "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            ].includes(mimeType) || 
            /\.(docx?|xlsx?|pptx?)$/i.test(fileName || "");

            if (isOffice) {
              let extractedText = "";
              try {
                const buffer = Buffer.from(fileBase64, "base64");
                let fileType: SupportedFileType = "docx";
                const ext = fileName?.split(".").pop()?.toLowerCase();
                if (ext && ["docx", "doc", "xlsx", "xls", "pptx", "ppt"].includes(ext)) {
                  fileType = ext as SupportedFileType;
                }
                const ast = await parseOffice(buffer, { fileType });
                extractedText = (await ast.to("text")).value;
              } catch (parseError) {
                console.error("Office parsing error in chat:", parseError);
                return Response.json({ error: "نەتوانرا دەقی فایلەکە شیبکرێتەوە." }, { status: 500 });
              }

              const documentContext = `Here is the content of the document "${fileName || "uploaded file"}":
---
${extractedText}
---`;
              geminiMessages.push({ role: "system", content: (systemPrompt || DOC_SYSTEM_PROMPT) + "\n\n" + documentContext });
              geminiMessages.push(...messages.slice(-20));
            } else {
              geminiMessages.push({ role: "system", content: systemPrompt || DOC_SYSTEM_PROMPT });

              let attachedFile = false;
              for (const msg of messages.slice(-20)) {
                if (msg.role === "user" && !attachedFile) {
                  geminiMessages.push({
                    role: "user",
                    content: [
                      { type: "text", text: msg.content },
                      {
                        type: "image_url",
                        image_url: { url: `data:${mimeType};base64,${fileBase64}` },
                      },
                    ],
                  });
                  attachedFile = true;
                } else {
                  geminiMessages.push(msg);
                }
              }
            }
          } else {
            geminiMessages.push({ role: "system", content: systemPrompt || SYSTEM_PROMPT });
            geminiMessages.push(...messages.slice(-20));
          }

          const aiResp = await fetchGemini({
            model: "gemini-2.5-flash",
            messages: geminiMessages,
            stream: true,
          });


          if (!aiResp.ok) {
            if (aiResp.status === 429) {
              return Response.json(
                { error: "داواکاریەکان زۆرن، تکایە چەند چرکەیەک چاوەڕێبە." },
                { status: 429 },
              );
            }
            if (aiResp.status === 402) {
              return Response.json(
                { error: "کرێدیتی AI تەواوبوو. تکایە پلانێکی VIP چالاک بکە." },
                { status: 402 },
              );
            }
            const t = await aiResp.text();
            console.error("AI chat error:", aiResp.status, t);
            return Response.json({ error: "هەڵە لە سەرڤیسی AI." }, { status: 500 });
          }

          return new Response(aiResp.body, {
            headers: { "Content-Type": "text/event-stream" },
          });
        } catch (e) {
          console.error("chat error:", e);
          return Response.json(
            { error: e instanceof Error ? e.message : "هەڵەیەکی نەزانراو" },
            { status: 500 },
          );
        }
      },
    },
  },
});
