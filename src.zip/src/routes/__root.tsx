import React, { type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">پەڕە نەدۆزرایەوە</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          ئەو پەڕەیەی بەدوایدا دەگەڕێیت بوونی نییە یان گواستراوەتەوە.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            گەڕانەوە بۆ ماڵپەڕ
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error("Root Route Caught Error:", error);
  const router = useRouter();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">هەڵەیەک ڕوویدا</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {error?.message || "هەوڵبدە دیسان یان بگەڕێوە بۆ سەرەتا."}
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition"
          >
            هەوڵبدەرەوە
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary transition"
          >
            سەرەتا
          </a>
        </div>
      </div>
    </div>
  );
}

// لێرەدا shellComponent سڕایەوە چونکە بوونی نییە لە ڕێبەری سەرەکیدا
export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "کورتەیا AI — پلاتفۆرمی زیرەکی دەستکرد بۆ فێرخوازان" },
      {
        name: "description",
        content: "ئامرازێکی پێشکەوتووی زیرەکی دەستکرد بۆ پوختەکردن، شییکردنەوەی بەڵگەنامە و PDF، و ڕێبەری زانکۆ بۆ فێرخوازان.",
      },
      { name: "author", content: "AI Pukhtana" },
      { property: "og:title", content: "کورتەیا AI — پلاتفۆرمی زیرەکی دەستکرد بۆ فێرخوازان" },
      {
        property: "og:description",
        content: "ئامرازێکی پێشکەوتووی زیرەکی دەستکرد بۆ پوختەکردن، شییکردنەوەی بەڵگەنامە و PDF، و ڕێبەری زانکۆ بۆ فێرخوازان.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "کورتەیا AI — پلاتفۆرمی زیرەکی دەستکرد بۆ فێرخوازان" },
      {
        name: "twitter:description",
        content: "ئامرازێکی پێشکەوتووی زیرەکی دەستکرد بۆ پوختەکردن، شییکردنەوەی بەڵگەنامە و PDF، و ڕێبەری زانکۆ بۆ فێرخوازان.",
      },
      {
        property: "og:image",
        content: "/sangar.jpg",
      },
      {
        name: "twitter:image",
        content: "/sangar.jpg",
      },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;500;600;700;800&display=swap",
      },
    ],
  }),
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="ckb" dir="rtl" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  React.useEffect(() => {
    try {
      const storedTheme = localStorage.getItem("ai_pukhtana_theme");
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      if (storedTheme === "dark" || (!storedTheme && prefersDark)) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    } catch (e) {}
  }, []);

  return (
    <RootShell>
      <QueryClientProvider client={queryClient}>
        <Outlet />
      </QueryClientProvider>
    </RootShell>
  );
}
