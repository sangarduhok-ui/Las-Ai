import { useState, useRef, useEffect } from "react";
import {
  Receipt,
  FileText,
  FileSpreadsheet,
  Truck,
  ShoppingCart,
  Plus,
  Trash2,
  Printer,
  Download,
  Upload,
  Copy,
  Check,
  Building2,
  User,
  Calendar,
  DollarSign,
  Palette,
  Eye,
  Edit3,
  Sparkles,
  RefreshCw,
  Stamp,
  Globe,
  Percent,
} from "lucide-react";

export type DocType = "invoice" | "receipt" | "quotation" | "purchase_order" | "delivery_note";
export type TemplateStyle = "modern" | "classic" | "corporate" | "minimal" | "emerald";

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discount: number; // in percent
  tax: number; // in percent
}

export interface InvoiceData {
  docType: DocType;
  docNumber: string;
  date: string;
  dueDate: string;
  status: "PAID" | "UNPAID" | "PENDING" | "OVERDUE";
  currency: string;
  
  // Seller
  companyName: string;
  companyLogo: string | null;
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  companyTaxId: string;

  // Buyer
  clientName: string;
  clientAddress: string;
  clientPhone: string;
  clientEmail: string;
  clientTaxId: string;

  // Items
  items: InvoiceItem[];

  // Extras
  notes: string;
  terms: string;
  taxRate: number; // general tax if applicable
  shippingFee: number;
  discountAmount: number;
  paymentMethod: string;
  bankDetails: string;
  signatureName: string;
}

const DEFAULT_INVOICE_DATA: InvoiceData = {
  docType: "invoice",
  docNumber: "INV-2026-001",
  date: new Date().toISOString().split("T")[0],
  dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
  status: "UNPAID",
  currency: "$",

  companyName: "کۆمپانیای تەکنەلۆژیای پێشکەوتوو",
  companyLogo: null,
  companyAddress: "شەقامی سەرەکی، هەولێر / دهۆک / سلێمانی",
  companyPhone: "+964 750 123 4567",
  companyEmail: "info@company.com",
  companyTaxId: "TRN-998877",

  clientName: "بەڕێز محەمەد ئەحمەد",
  clientAddress: "گەڕەکی ئازادی، کۆڵانی ١٢",
  clientPhone: "+964 750 765 4321",
  clientEmail: "client@example.com",
  clientTaxId: "",

  items: [
    {
      id: "1",
      description: "دیزاین و پەرەپێدانی سیستەمی وێب و ئەپڵیکەیشن (Web Development)",
      quantity: 1,
      unitPrice: 450,
      discount: 0,
      tax: 0,
    },
    {
      id: "2",
      description: "ڕاوێژکاری و ڕاهێنانی ستاف لەسەر پلاتفۆرمی زیرەکی دەستکرد",
      quantity: 3,
      unitPrice: 75,
      discount: 10,
      tax: 0,
    },
    {
      id: "3",
      description: "خزمەتگوزاری هۆستینگ و دۆمەینی خێرا (ساڵانە)",
      quantity: 1,
      unitPrice: 120,
      discount: 0,
      tax: 0,
    },
  ],

  notes: "سوپاس بۆ متمانە و مامەڵەکردنتان لەگەڵ کۆمپانیاکەمان.",
  terms: "تکایە بڕی پارەکە لە ماوەی دیاریکراودا بە یەکێک لە شێوازەکانی پارەدان یەکلایی بکەنەوە.",
  taxRate: 0,
  shippingFee: 0,
  discountAmount: 0,
  paymentMethod: "کاش / حەواڵە / FIB / FastPay",
  bankDetails: "FIB Account: 0750 123 4567 / Bank Name: RT Bank",
  signatureName: "بەڕێوەبەری دارایی و فرۆشتن",
};

const DOC_TITLES: Record<DocType, { ku: string; en: string; prefix: string; icon: any; color: string }> = {
  invoice: { ku: "فاکتوورەی فرۆشتن", en: "INVOICE", prefix: "INV", icon: FileText, color: "blue" },
  receipt: { ku: "پسوولەی پارەدان و وەرگرتن", en: "PAYMENT RECEIPT", prefix: "REC", icon: Receipt, color: "emerald" },
  quotation: { ku: "پێشنیاری نرخ (تەخمین)", en: "PRICE QUOTATION", prefix: "QTN", icon: FileSpreadsheet, color: "purple" },
  purchase_order: { ku: "داواکاری و فەرمانی کڕین", en: "PURCHASE ORDER", prefix: "PO", icon: ShoppingCart, color: "amber" },
  delivery_note: { ku: "پسوولەی گەیاندنی کاڵا", en: "DELIVERY NOTE", prefix: "DLV", icon: Truck, color: "rose" },
};

export function InvoiceGenerator({ initialDocType = "invoice" }: { initialDocType?: DocType }) {
  const [data, setData] = useState<InvoiceData>({
    ...DEFAULT_INVOICE_DATA,
    docType: initialDocType,
    docNumber: `${DOC_TITLES[initialDocType].prefix}-${new Date().getFullYear()}-001`,
  });

  const [activeTab, setActiveTab] = useState<"edit" | "preview">("edit");
  const [template, setTemplate] = useState<TemplateStyle>("modern");
  const [copied, setCopied] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // Sync docType change with appropriate prefix
  const handleTypeChange = (type: DocType) => {
    setData((prev) => ({
      ...prev,
      docType: type,
      docNumber: `${DOC_TITLES[type].prefix}-${new Date().getFullYear()}-001`,
    }));
  };

  // Calculations
  const calculateSubtotal = () => {
    return data.items.reduce((sum, item) => {
      const lineTotal = item.quantity * item.unitPrice;
      const discounted = lineTotal - (lineTotal * (item.discount || 0)) / 100;
      return sum + discounted;
    }, 0);
  };

  const calculateTotalDiscount = () => {
    const itemsDiscount = data.items.reduce((sum, item) => {
      const lineTotal = item.quantity * item.unitPrice;
      return sum + (lineTotal * (item.discount || 0)) / 100;
    }, 0);
    return itemsDiscount + (data.discountAmount || 0);
  };

  const calculateTaxAmount = () => {
    const subtotal = calculateSubtotal();
    return (subtotal * (data.taxRate || 0)) / 100;
  };

  const calculateGrandTotal = () => {
    const subtotal = calculateSubtotal();
    const tax = calculateTaxAmount();
    const shipping = data.shippingFee || 0;
    return subtotal + tax + shipping - (data.discountAmount || 0);
  };

  // Item Handlers
  const addItem = () => {
    setData((prev) => ({
      ...prev,
      items: [
        ...prev.items,
        {
          id: Math.random().toString(36).substring(2, 9),
          description: "",
          quantity: 1,
          unitPrice: 0,
          discount: 0,
          tax: 0,
        },
      ],
    }));
  };

  const removeItem = (id: string) => {
    if (data.items.length <= 1) return;
    setData((prev) => ({
      ...prev,
      items: prev.items.filter((item) => item.id !== id),
    }));
  };

  const updateItem = (id: string, field: keyof InvoiceItem, val: any) => {
    setData((prev) => ({
      ...prev,
      items: prev.items.map((item) => (item.id === id ? { ...item, [field]: val } : item)),
    }));
  };

  // Logo Handler
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setData((prev) => ({ ...prev, companyLogo: event.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Print Handler
  const handlePrint = () => {
    window.print();
  };

  // Copy JSON Backup
  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currentMeta = DOC_TITLES[data.docType];

  return (
    <div className="space-y-6">
      {/* Top Controls Bar (Hidden during print) */}
      <div className="print:hidden p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-bold mb-2">
              <FileSpreadsheet className="w-3.5 h-3.5" /> سیستەمی دروستکردنی فاکتوورە و پسوولەی فەرمی
            </div>
            <h2 className="text-xl md:text-2xl font-extrabold text-foreground">
              Professional Invoice & Receipt Generator
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* View / Edit Mode Switch */}
            <div className="flex items-center p-1 rounded-2xl bg-secondary border border-border">
              <button
                onClick={() => setActiveTab("edit")}
                className={`py-1.5 px-3.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === "edit" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                دەستکاریکردن (Edit)
              </button>
              <button
                onClick={() => setActiveTab("preview")}
                className={`py-1.5 px-3.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === "preview" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                پێشبینینی چاپ (Preview)
              </button>
            </div>

            {/* Print Button */}
            <button
              onClick={handlePrint}
              className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold flex items-center gap-2 shadow-md transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              چاپکردن / PDF
            </button>
          </div>
        </div>

        {/* 5 Main Document Types Selection */}
        <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-secondary/80 border border-border mb-6">
          {(Object.keys(DOC_TITLES) as DocType[]).map((type) => {
            const item = DOC_TITLES[type];
            const Icon = item.icon;
            const isSelected = data.docType === type;
            return (
              <button
                key={type}
                onClick={() => handleTypeChange(type)}
                className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                  isSelected
                    ? "bg-primary text-primary-foreground shadow-md font-extrabold"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.en} ({item.ku.split(" ")[0]})</span>
              </button>
            );
          })}
        </div>

        {/* Template Design Preset Selector */}
        <div className="flex items-center justify-between flex-wrap gap-3 pt-3 border-t border-border/70 text-xs">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-primary" />
            <span className="font-bold text-foreground">دیزاینی تێمپلەیت (Style):</span>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: "modern", label: "Modern Blue (مۆدێرن)" },
              { id: "emerald", label: "Emerald Clean (سەوز)" },
              { id: "corporate", label: "Corporate Dark (ڕەش و شین)" },
              { id: "minimal", label: "Minimalist (سادە)" },
              { id: "classic", label: "Classic Studio (کلاسیک)" },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTemplate(t.id as TemplateStyle)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer border ${
                  template === t.id
                    ? "bg-primary/10 border-primary text-primary font-black ring-2 ring-primary/20"
                    : "bg-background border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {activeTab === "edit" ? (
        /* ========================================================================= */
        /* EDITING MODE FORM                                                         */
        /* ========================================================================= */
        <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm space-y-8 animate-in fade-in-0 duration-200">
          {/* Section 1: Header Meta (Doc No, Date, Currency, Status) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-2xl bg-secondary/30 border border-border">
            <div>
              <label className="text-xs font-bold text-foreground block mb-1">ژمارەی بەڵگەنامە (Doc #):</label>
              <input
                type="text"
                dir="ltr"
                value={data.docNumber}
                onChange={(e) => setData({ ...data, docNumber: e.target.value })}
                className="w-full h-10 px-3 rounded-xl bg-background border border-border text-xs font-mono font-bold focus:ring-2 focus:ring-primary focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-foreground block mb-1">بەرواری دەرچوون (Date):</label>
              <input
                type="date"
                value={data.date}
                onChange={(e) => setData({ ...data, date: e.target.value })}
                className="w-full h-10 px-3 rounded-xl bg-background border border-border text-xs font-mono focus:ring-2 focus:ring-primary focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-foreground block mb-1">کۆتا وادە (Due Date):</label>
              <input
                type="date"
                value={data.dueDate}
                onChange={(e) => setData({ ...data, dueDate: e.target.value })}
                className="w-full h-10 px-3 rounded-xl bg-background border border-border text-xs font-mono focus:ring-2 focus:ring-primary focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-foreground block mb-1">دراو (Currency):</label>
              <select
                value={data.currency}
                onChange={(e) => setData({ ...data, currency: e.target.value })}
                className="w-full h-10 px-3 rounded-xl bg-background border border-border text-xs font-bold focus:ring-2 focus:ring-primary focus:outline-none"
              >
                <option value="$">$ USD (دۆلار)</option>
                <option value="د.ع">د.ع IQD (دیناری عێراقی)</option>
                <option value="€">€ EUR (یۆرۆ)</option>
                <option value="£">£ GBP (پاوەند)</option>
                <option value="TL">TL TRY (لیرەی تورکی)</option>
                <option value="AED">AED (دیرهەمی ئیماراتی)</option>
              </select>
            </div>
          </div>

          {/* Section 2: Seller & Client Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Seller Information */}
            <div className="p-5 rounded-2xl bg-secondary/20 border border-border space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-border">
                <span className="text-xs font-extrabold text-foreground flex items-center gap-1.5">
                  <Building2 className="w-4 h-4 text-primary" /> زانیاری فرۆشیار / کۆمپانیا (From)
                </span>
                <input
                  type="file"
                  ref={logoInputRef}
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="text-[11px] font-bold text-primary hover:underline cursor-pointer flex items-center gap-1"
                >
                  <Upload className="w-3 h-3" /> بارکردنی لۆگۆ
                </button>
              </div>

              <div>
                <label className="text-[11px] font-bold text-muted-foreground block mb-1">ناوی کۆمپانیا یان دوکان:</label>
                <input
                  type="text"
                  value={data.companyName}
                  onChange={(e) => setData({ ...data, companyName: e.target.value })}
                  placeholder="ناوی کۆمپانیا"
                  className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs font-bold focus:ring-2 focus:ring-primary focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-muted-foreground block mb-1">ژمارەی پەیوەندی:</label>
                  <input
                    type="text"
                    dir="ltr"
                    value={data.companyPhone}
                    onChange={(e) => setData({ ...data, companyPhone: e.target.value })}
                    className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-muted-foreground block mb-1">ئیمەیل:</label>
                  <input
                    type="email"
                    dir="ltr"
                    value={data.companyEmail}
                    onChange={(e) => setData({ ...data, companyEmail: e.target.value })}
                    className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-muted-foreground block mb-1">ناونیشان:</label>
                <input
                  type="text"
                  value={data.companyAddress}
                  onChange={(e) => setData({ ...data, companyAddress: e.target.value })}
                  className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                />
              </div>
            </div>

            {/* Client Information */}
            <div className="p-5 rounded-2xl bg-secondary/20 border border-border space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-border">
                <span className="text-xs font-extrabold text-foreground flex items-center gap-1.5">
                  <User className="w-4 h-4 text-emerald-500" /> زانیاری کڕیار / موشتەری (Bill To)
                </span>
                <select
                  value={data.status}
                  onChange={(e) => setData({ ...data, status: e.target.value as any })}
                  className="h-7 px-2 rounded-lg bg-background border border-border text-[11px] font-bold text-foreground"
                >
                  <option value="UNPAID">نەدراوە (UNPAID)</option>
                  <option value="PAID">دراوە (PAID)</option>
                  <option value="PENDING">لە چاوەڕوانیدا (PENDING)</option>
                  <option value="OVERDUE">بەسەرچوو (OVERDUE)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-muted-foreground block mb-1">ناوی کڕیار / کۆمپانیا:</label>
                <input
                  type="text"
                  value={data.clientName}
                  onChange={(e) => setData({ ...data, clientName: e.target.value })}
                  placeholder="ناوی کڕیار"
                  className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs font-bold focus:ring-2 focus:ring-primary focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-muted-foreground block mb-1">تەلەفۆنی کڕیار:</label>
                  <input
                    type="text"
                    dir="ltr"
                    value={data.clientPhone}
                    onChange={(e) => setData({ ...data, clientPhone: e.target.value })}
                    className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-muted-foreground block mb-1">ئیمەیلی کڕیار:</label>
                  <input
                    type="email"
                    dir="ltr"
                    value={data.clientEmail}
                    onChange={(e) => setData({ ...data, clientEmail: e.target.value })}
                    className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-muted-foreground block mb-1">ناونیشانی کڕیار:</label>
                <input
                  type="text"
                  value={data.clientAddress}
                  onChange={(e) => setData({ ...data, clientAddress: e.target.value })}
                  className="w-full h-9 px-3 rounded-xl bg-background border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Items Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold text-foreground flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-primary" /> خشتەی کاڵا و خزمەتگوزارییەکان (Items List)
              </h3>
              <button
                type="button"
                onClick={addItem}
                className="py-1.5 px-3 rounded-xl bg-primary text-primary-foreground text-xs font-bold flex items-center gap-1 shadow-xs hover:opacity-95 transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> زیادکردنی ڕیز
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-border bg-secondary/10">
              <table className="w-full text-right text-xs">
                <thead className="bg-secondary/40 border-b border-border font-bold text-foreground">
                  <tr>
                    <th className="p-3 w-8 text-center">#</th>
                    <th className="p-3 min-w-[200px]">وەسف / ناوی کاڵا یان خزمەتگوزاری</th>
                    <th className="p-3 w-24 text-center">ژمارە (Qty)</th>
                    <th className="p-3 w-32 text-center">نرخی تاک ({data.currency})</th>
                    <th className="p-3 w-24 text-center">داشکاندن (%)</th>
                    <th className="p-3 w-32 text-center">کۆی گشتی ({data.currency})</th>
                    <th className="p-3 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/60">
                  {data.items.map((item, idx) => {
                    const lineTotal = item.quantity * item.unitPrice;
                    const finalLine = lineTotal - (lineTotal * (item.discount || 0)) / 100;
                    return (
                      <tr key={item.id} className="hover:bg-secondary/20 transition">
                        <td className="p-2.5 text-center font-mono text-muted-foreground">{idx + 1}</td>
                        <td className="p-2.5">
                          <input
                            type="text"
                            value={item.description}
                            onChange={(e) => updateItem(item.id, "description", e.target.value)}
                            placeholder="ناوی کاڵا یان خزمەتگوزاری..."
                            className="w-full h-8 px-2.5 rounded-lg bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateItem(item.id, "quantity", Math.max(1, Number(e.target.value)))}
                            className="w-full h-8 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            step="any"
                            value={item.unitPrice}
                            onChange={(e) => updateItem(item.id, "unitPrice", Number(e.target.value))}
                            className="w-full h-8 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={item.discount}
                            onChange={(e) => updateItem(item.id, "discount", Math.min(100, Math.max(0, Number(e.target.value))))}
                            className="w-full h-8 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs focus:ring-1 focus:ring-primary focus:outline-none"
                          />
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-foreground">
                          {finalLine.toLocaleString()} {data.currency}
                        </td>
                        <td className="p-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => removeItem(item.id)}
                            disabled={data.items.length <= 1}
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition disabled:opacity-30 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 4: Extra Terms, Bank & Totals */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-7 space-y-4">
              <div>
                <label className="text-xs font-bold text-foreground block mb-1">تێبینی و ڕێنماییەکان (Notes):</label>
                <textarea
                  rows={2}
                  value={data.notes}
                  onChange={(e) => setData({ ...data, notes: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-secondary/30 border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-foreground block mb-1">مەرجەکانی مامەڵە (Terms & Conditions):</label>
                <textarea
                  rows={2}
                  value={data.terms}
                  onChange={(e) => setData({ ...data, terms: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-secondary/30 border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-foreground block mb-1">زانیاری حیسابی بانک / هەژمار:</label>
                  <input
                    type="text"
                    value={data.bankDetails}
                    onChange={(e) => setData({ ...data, bankDetails: e.target.value })}
                    className="w-full h-8 px-2.5 rounded-xl bg-secondary/30 border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-foreground block mb-1">ناونیشانی واژوو / مۆرکەر:</label>
                  <input
                    type="text"
                    value={data.signatureName}
                    onChange={(e) => setData({ ...data, signatureName: e.target.value })}
                    className="w-full h-8 px-2.5 rounded-xl bg-secondary/30 border border-border text-xs focus:ring-2 focus:ring-primary focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Calculations Box */}
            <div className="lg:col-span-5 p-5 rounded-2xl bg-secondary/30 border border-border space-y-3">
              <h4 className="text-xs font-extrabold text-foreground pb-2 border-b border-border">
                کۆکردنەوەی کۆتایی (Summary & Totals)
              </h4>

              <div className="flex justify-between text-xs text-muted-foreground">
                <span>کۆی سەرەتایی (Subtotal):</span>
                <span className="font-mono font-bold text-foreground">
                  {calculateSubtotal().toLocaleString()} {data.currency}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">داشکاندنی زیادە ({data.currency}):</span>
                <input
                  type="number"
                  min="0"
                  value={data.discountAmount}
                  onChange={(e) => setData({ ...data, discountAmount: Number(e.target.value) })}
                  className="w-24 h-7 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs"
                />
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">باج / VAT (%):</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={data.taxRate}
                  onChange={(e) => setData({ ...data, taxRate: Number(e.target.value) })}
                  className="w-24 h-7 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs"
                />
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">تێچووی گەیاندن ({data.currency}):</span>
                <input
                  type="number"
                  min="0"
                  value={data.shippingFee}
                  onChange={(e) => setData({ ...data, shippingFee: Number(e.target.value) })}
                  className="w-24 h-7 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs"
                />
              </div>

              <div className="pt-3 border-t border-border flex justify-between items-center">
                <span className="text-sm font-black text-foreground">کۆی گشتی (Grand Total):</span>
                <span className="text-base font-black font-mono text-primary">
                  {calculateGrandTotal().toLocaleString()} {data.currency}
                </span>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* ========================================================================= */}
      {/* PRINT & PREVIEW A4 CANVAS (Visible in Preview Mode AND during Print)       */}
      {/* ========================================================================= */}
      <div className={`${activeTab === "preview" ? "block" : "hidden print:block"} animate-in fade-in-0 duration-200`}>
        <div
          id="printable-invoice"
          className={`max-w-[850px] mx-auto p-8 sm:p-12 rounded-3xl border shadow-2xl transition-all duration-300 font-sans ${
            template === "modern"
              ? "bg-white text-slate-900 border-slate-200"
              : template === "emerald"
              ? "bg-white text-emerald-950 border-emerald-200"
              : template === "corporate"
              ? "bg-white text-slate-900 border-slate-900/20"
              : template === "minimal"
              ? "bg-white text-neutral-900 border-neutral-200"
              : "bg-white text-slate-950 border-slate-300"
          }`}
          style={{ minHeight: "1050px" }}
        >
          {/* Top Decorative Bar based on template */}
          {template === "modern" && (
            <div className="h-3.5 -mx-8 sm:-mx-12 -mt-8 sm:-mt-12 mb-8 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-t-3xl" />
          )}
          {template === "emerald" && (
            <div className="h-3.5 -mx-8 sm:-mx-12 -mt-8 sm:-mt-12 mb-8 bg-gradient-to-r from-emerald-500 via-teal-600 to-emerald-700 rounded-t-3xl" />
          )}
          {template === "corporate" && (
            <div className="h-3.5 -mx-8 sm:-mx-12 -mt-8 sm:-mt-12 mb-8 bg-slate-900 rounded-t-3xl" />
          )}

          {/* Header & Logo */}
          <div className="flex flex-col sm:flex-row items-start justify-between gap-6 pb-6 border-b border-slate-200">
            <div className="flex items-center gap-4">
              {data.companyLogo ? (
                <img
                  src={data.companyLogo}
                  alt="Company Logo"
                  className="w-16 h-16 object-contain rounded-xl border border-slate-200 shadow-xs"
                />
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-950 text-white flex items-center justify-center font-black text-2xl shadow-sm">
                  {data.companyName.charAt(0) || "C"}
                </div>
              )}
              <div>
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
                  {data.companyName}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">{data.companyAddress}</p>
                <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                  <span>{data.companyPhone}</span>
                  <span>•</span>
                  <span>{data.companyEmail}</span>
                </div>
              </div>
            </div>

            <div className="text-left sm:text-right self-stretch sm:self-auto flex flex-col justify-between">
              <div>
                <span
                  className={`text-2xl sm:text-3xl font-black uppercase tracking-wider block ${
                    template === "emerald" ? "text-emerald-700" : "text-blue-700"
                  }`}
                >
                  {currentMeta.en}
                </span>
                <span className="text-xs font-bold text-slate-500 block mt-0.5">
                  {currentMeta.ku}
                </span>
              </div>

              <div className="mt-3 inline-block">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                    data.status === "PAID"
                      ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                      : data.status === "UNPAID"
                      ? "bg-rose-100 text-rose-800 border border-rose-300"
                      : "bg-amber-100 text-amber-800 border border-amber-300"
                  }`}
                >
                  {data.status}
                </span>
              </div>
            </div>
          </div>

          {/* Meta Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-b border-slate-200 text-xs">
            <div>
              <span className="text-slate-400 font-bold block mb-1">ژمارەی فاکتوورە (Invoice No):</span>
              <span className="font-mono font-black text-sm text-slate-900">{data.docNumber}</span>
            </div>
            <div>
              <span className="text-slate-400 font-bold block mb-1">بەروار (Date):</span>
              <span className="font-mono font-bold text-slate-800">{data.date}</span>
            </div>
            <div>
              <span className="text-slate-400 font-bold block mb-1">کۆتا وادە (Due Date):</span>
              <span className="font-mono font-bold text-slate-800">{data.dueDate}</span>
            </div>
            <div>
              <span className="text-slate-400 font-bold block mb-1">دراوی مامەڵە (Currency):</span>
              <span className="font-bold text-slate-800">{data.currency}</span>
            </div>
          </div>

          {/* Bill To / Client Details */}
          <div className="py-6 border-b border-slate-200">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
              بۆ بەڕێز (Billed To):
            </span>
            <div className="text-sm">
              <h3 className="font-black text-base text-slate-900">{data.clientName}</h3>
              <p className="text-xs text-slate-600 mt-1">{data.clientAddress}</p>
              <div className="flex items-center gap-4 text-xs text-slate-600 mt-1">
                <span>{data.clientPhone}</span>
                {data.clientEmail && (
                  <>
                    <span>•</span>
                    <span>{data.clientEmail}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="py-6">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b-2 border-slate-800 text-slate-800 font-black">
                  <th className="pb-3 w-8 text-center">#</th>
                  <th className="pb-3">وەسف / کاڵا (Item Description)</th>
                  <th className="pb-3 w-20 text-center">ژمارە</th>
                  <th className="pb-3 w-28 text-center">نرخی تاک</th>
                  <th className="pb-3 w-20 text-center">داشکاندن</th>
                  <th className="pb-3 w-32 text-left">کۆی گشتی</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {data.items.map((item, idx) => {
                  const lineTotal = item.quantity * item.unitPrice;
                  const finalLine = lineTotal - (lineTotal * (item.discount || 0)) / 100;
                  return (
                    <tr key={item.id}>
                      <td className="py-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                      <td className="py-3 font-bold text-slate-900">{item.description || "—"}</td>
                      <td className="py-3 text-center font-mono">{item.quantity}</td>
                      <td className="py-3 text-center font-mono">
                        {item.unitPrice.toLocaleString()} {data.currency}
                      </td>
                      <td className="py-3 text-center font-mono">
                        {item.discount > 0 ? `${item.discount}%` : "—"}
                      </td>
                      <td className="py-3 text-left font-mono font-bold text-slate-900">
                        {finalLine.toLocaleString()} {data.currency}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Summary & Signatures */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4 border-t-2 border-slate-800 items-start">
            {/* Payment Info & Terms */}
            <div className="space-y-3 text-xs text-slate-600">
              {data.paymentMethod && (
                <div>
                  <span className="font-bold text-slate-800 block">شێوازی پارەدان:</span>
                  <span>{data.paymentMethod}</span>
                </div>
              )}
              {data.bankDetails && (
                <div>
                  <span className="font-bold text-slate-800 block">حیسابی بانک:</span>
                  <span className="font-mono">{data.bankDetails}</span>
                </div>
              )}
              {data.terms && (
                <div>
                  <span className="font-bold text-slate-800 block">مەرجەکان:</span>
                  <span className="text-[11px] leading-relaxed">{data.terms}</span>
                </div>
              )}
              {data.notes && (
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px]">
                  <strong>تێبینی:</strong> {data.notes}
                </div>
              )}
            </div>

            {/* Totals Breakdown */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>کۆی سەرەتایی (Subtotal):</span>
                <span className="font-mono font-bold text-slate-900">
                  {calculateSubtotal().toLocaleString()} {data.currency}
                </span>
              </div>

              {calculateTotalDiscount() > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>کۆی داشکاندن (Discount):</span>
                  <span className="font-mono font-bold">
                    -{calculateTotalDiscount().toLocaleString()} {data.currency}
                  </span>
                </div>
              )}

              {data.taxRate > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>باج (Tax {data.taxRate}%):</span>
                  <span className="font-mono font-bold">
                    +{calculateTaxAmount().toLocaleString()} {data.currency}
                  </span>
                </div>
              )}

              {data.shippingFee > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>گەیاندن (Shipping):</span>
                  <span className="font-mono font-bold">
                    +{data.shippingFee.toLocaleString()} {data.currency}
                  </span>
                </div>
              )}

              <div className="pt-3 border-t-2 border-slate-900 flex justify-between items-center text-sm font-black text-slate-950">
                <span>کۆی گشتی (Grand Total):</span>
                <span className="text-lg font-mono text-blue-700">
                  {calculateGrandTotal().toLocaleString()} {data.currency}
                </span>
              </div>

              {/* Signature / Stamp line */}
              <div className="pt-8 text-center sm:text-left">
                <div className="inline-block border-t border-slate-400 pt-1.5 min-w-[160px]">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    {data.signatureName || "واژوو و مۆر"}
                  </span>
                  <span className="text-[9px] text-slate-400 uppercase tracking-widest block">
                    Authorized Signature
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
