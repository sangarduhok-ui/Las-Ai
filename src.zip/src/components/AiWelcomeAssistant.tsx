import { useState, useEffect, useRef } from "react";
import { Sparkles, ArrowRight, Send } from "lucide-react";



export type AssistantLanguage = "ku" | "en" | "ar" | "tr";

interface ToolRecommendation {
  label: string;
  toolId: string;
  categoryIndex?: number;
}

interface AssistantMessage {
  id: string;
  sender: "ai" | "user";
  text: string;
  recommendations?: ToolRecommendation[];
  time: string;
}

const LOCALIZED_GREETINGS = {
  ku: {
    welcome: "بەخێرهاتی 👋",
    intro: "ئەز هاریکارێ تەیێ زیرەکیا دەستکردم چەوا بشێم هاریکاریا تە بکەم ؟",
    prompt: "چەوا بشێم هاریکاریا تە بکەم؟",
    returning: "بخێرهاتیەڤە هەڤالێ هێژا! 👋",
    returningPrompt: "ئامادەی بەردەوام بین؟",
    askAiBtn: "پرسیارێ ژ AI بکە",
    pdfBtn: "ئامرازێن PDF",
    mathBtn: "شیکاریا بیرکاریێ",
    studyBtn: "ئامرازێن خواندنێ",
    researchBtn: "ڤەکۆلینا ئەکادیمی",
    allToolsBtn: "هەمی پشک",
    inputPlaceholder: "پرسیارەکێ بنڤیسە یان داخازا ئامرازەکی بکە...",
    sendBtn: "هنارتن",
    closeChat: "گرتن",
    status: "ئامادەیێ هاریکاریێ یە",
    greeting: "سڵاڤ! 👋",
    thinking: "هاریکارێ AI یێ هزردکەت...",
  },
  en: {
    welcome: "Welcome 👋",
    intro: "I am your AI Study & Productivity Assistant. How can I help you today?",
    prompt: "What do you need help with today? (Math, PDF, AI Tools, Research)",
    returning: "Welcome back! 👋",
    returningPrompt: "Ready to continue where you left off?",
    askAiBtn: "Ask AI Guide",
    pdfBtn: "PDF Suite",
    mathBtn: "Math Solver",
    studyBtn: "Study Tools",
    researchBtn: "Academic Research",
    allToolsBtn: "All Categories",
    inputPlaceholder: "Ask anything or search for a tool...",
    sendBtn: "Send",
    closeChat: "Close Guide",
    status: "Ready to assist",
    greeting: "Hello! 👋",
    thinking: "AI Assistant is thinking...",
  },
  ar: {
    welcome: "أهلاً بك 👋",
    intro: "أنا مساعدك الذكي لمنصة الدراسة والإنتاجية، كيف يمكنني مساعدتك؟",
    prompt: "ما الذي تبحث عنه اليوم؟ (رياضيات، ملفات PDF، أبحاث، دراسة)",
    returning: "أهلاً بعودتك مجدداً! 👋",
    returningPrompt: "هل أنت مستعد لمواصلة الدراسة والتحليل؟",
    askAiBtn: "اسأل الذكاء الاصطناعي",
    pdfBtn: "أدوات PDF",
    mathBtn: "حل المعادلات",
    studyBtn: "أدوات الدراسة",
    researchBtn: "البحث الأكاديمي",
    allToolsBtn: "جميع الأدوات",
    inputPlaceholder: "اكتب سؤالك أو ابحث عن أداة...",
    sendBtn: "إرسال",
    closeChat: "إغلاق",
    status: "جاهز للمساعدة",
    greeting: "مرحباً! 👋",
    thinking: "المساعد الذكي يفكر...",
  },
  tr: {
    welcome: "Hoş geldiniz 👋",
    intro: "Ben sizin yapay zeka asistanınızım, size nasıl yardımcı olabilirim?",
    prompt: "Bugün neye ihtiyacınız var? (Matematik, PDF, Araştırma, Dersler)",
    returning: "Tekrar hoş geldiniz! 👋",
    returningPrompt: "Kaldığınız yerden devam etmeye hazır mısınız?",
    askAiBtn: "Yapay Zekaya Sor",
    pdfBtn: "PDF Araçları",
    mathBtn: "Matematik Çözücü",
    studyBtn: "Ders Araçları",
    researchBtn: "Akademik Araştırma",
    allToolsBtn: "Tüm Kategoriler",
    inputPlaceholder: "Bir soru sorun veya bir araç arayın...",
    sendBtn: "Gönder",
    closeChat: "Kapat",
    status: "Yardıma hazır",
    greeting: "Merhaba! 👋",
    thinking: "Yapay zeka düşünüyor...",
  },
};

function detectUserLanguage(text: string): "ku" | "en" | "ar" | "tr" {
  const trimmed = text.trim();
  const latinCount = (trimmed.match(/[a-zA-Z]/g) || []).length;
  const arabicCharCount = (trimmed.match(/[\u0600-\u06FF]/g) || []).length;

  if (latinCount > arabicCharCount) {
    if (/[çğıöşüÇĞİÖŞÜ]/.test(trimmed)) {
      return "tr";
    }
    return "en";
  }

  if (/[ۆێڵەڕڤژچپگ]/.test(trimmed) || trimmed.includes("ئەز") || trimmed.includes("تە") || trimmed.includes("دشێم") || trimmed.includes("چەوا") || trimmed.includes("دڤێت") || trimmed.includes("سڵاڤ") || trimmed.includes("سلاڤ") || trimmed.includes("هەی") || trimmed.includes("نە") || trimmed.includes("هەڤال") || trimmed.includes("بکەم") || trimmed.includes("خواندن") || trimmed.includes("نڤیسین")) {
    return "ku";
  }

  if (trimmed.includes("كيف") || trimmed.includes("ماذا") || trimmed.includes("هل") || trimmed.includes("اريد") || trimmed.includes("أريد") || trimmed.includes("شكرا") || trimmed.includes("مرحبا") || trimmed.includes("معادلة") || trimmed.includes("تلخيص") || trimmed.includes("تحميل")) {
    return "ar";
  }

  return "ku";
}

const WELCOME_NAVIGATOR_SYSTEM_PROMPT = `تو ڕێبەر و ناسێنەرێ زیرەک و فەرمیێ پلاتفۆرمی "پوختەیا AI" یە.
ئەرکێ سەرەکیێ تە ئەوە کو بەرسڤا پرسیارێن بەکارهێنەری بدەی و هەمی دەمێ بەکارهێنەری ب ئامرازێن پێشکەفتیێن مە ئاشنا بکەی و پێشنیار بکەی.

یاسایێن گرنگ:
1. زمان: هەمی دەمێ ب زمانێ پرسیارکەری بەرسڤێ بدە. ئەگەر ب کوردی/بادینی بیت، ب زمانێ کوردیا بادینی یا شرین و فەرمی بنڤیسە. ئەگەر ب ئینگلیزی، عەرەبی یان تورکی بیت، ب هەمان زمانی بەرسڤێ بدە.
2. پێشنیارکرنا ئامرازێن مە: کاتێ بەکارهێنەر داوای هەر کار یان خزمەتگوزارییەک دکەت، بێژێ: "ئەز دشێم هاریکاریا تە بکەم ب ئامرازەکێ مە یێ زۆر پێشکەفتی ب ناڤێ (ناوی ئامراز ب بادینی و ئینگلیزی)..." و کورتە پێناسەیەکا ب سوود بدە کا چەوا کار دکەت و دشێت مفای ژێ ببینیت.

لیستا ئامرازێن مە یێن سەرەکی کو دڤێت بزانی و پێشنیار بکەی:
- پشکنینا دۆکیۆمێنتێن ساختە، دەستکاریکری یان مێتاداتا: ئامرازێ "دادوەرییا بەڵگەناما (Document Forensics)" تایبەتە بۆ پشکنینا پێکهاتە، ساختەبوون، شیکاریا قەبارە و دەستکاریا دۆکیۆمێنتان.
- شیکاریا بیرکاریێ و هاوکێشا: ئامرازێ "شیکارکەرێ بیرکاریێ (Math Solver)" و "دەستکاریکەرێ LaTeX" بۆ شیکارکرنا هەنگاو ب هەنگاو یا هاوکێشەیان.
- کورتکرنا مەلزەما و نامێ زانستی: "کورتکرنا مەلزەما (Study Summarizer)" و "پوختەکرنا پەڕاوێن زانستی (Paper Summarizer)".
- گوهۆڕین و سەرەدەری دگەل PDF: "گوهۆڕینا PDF بۆ Word/Excel/PowerPoint"، "پێکڤە گرێدان (PDF Merge)"، "پاراستن و ژێگرتن (PDF Protect/Split/Compress)".
- نڤیسینا دەستی و مرۆڤایەتیکرن: "گوهۆڕین بو نڤیسینا دەستی (Handwriting)" و "Humanizer AI".
- وەرگێڕان و پشکنینا ڕێزمانی: "وەرگێڕێ فرەزمان (Translator)" و "ڕاستڤەکەرێ ڕێزمانی (Grammar Checker)".
- ڤەکۆلینێن ئەکادیمی: "دروستکەرێ سایتەیشنا (Citation Generator / APA / DOI)"، "ڕێبەرێ زانکۆلاین (Zanko Guide)".
- داگرتن و گوهۆڕینا ڤیدیۆیا: "داگرتنا ڤیدیۆیا ژ یوتوب و تیکتۆک (Video Downloader)"، "گوهۆڕەرێ فۆرماتێ ڤیدیۆیێ (Video Converter)".
- تاقیگەها ئامارێ: "Statistics Lab" بۆ شیکاریا ژمارەیی و ئاماری و هێڵکاری (Mean, Median, Regression, Correlation).
- دروستکرنا فاکتورا و حسێبات: "دروستکەرێ فاکتورا (Invoice Generator)"، "ژمێریارێ مووچە، قازانج، قەرز و باج (VAT/Profit/Salary/Loan)".
- ئاسایش و QR Code: "دروستکەر و سکانەرێ QR Code" و "پشکنەرێ بەستەرێن ساختە (Links Checker)".
- ژوورا خواندنا ب کۆم: "Study Group Room" بۆ دروستکرنا ژوورێن خواندنا هاوبەش.

بەرسڤێن خۆ کورت، گەرم، ڕێزدار و هاندەرانە بدە، و بەکارهێنەری ئاراستەی ئامرازێ دروست بکە!`;

function extractToolRecommendations(q: string, lang: "ku" | "en" | "ar" | "tr"): ToolRecommendation[] {
  const query = q.toLowerCase();

  // Document Forensics / Tampering Check
  if (
    query.includes("ساختە") ||
    query.includes("ساختەیە") ||
    query.includes("دەستکاری") ||
    query.includes("بەڵگەنامە") ||
    query.includes("بەلگەنامە") ||
    query.includes("دوکیومێنت") ||
    query.includes("دۆکیۆمێنت") ||
    query.includes("پشکنین") ||
    query.includes("پسکنی") ||
    query.includes("forensic") ||
    query.includes("tamper") ||
    query.includes("fake") ||
    query.includes("verify") ||
    query.includes("مستند") ||
    query.includes("تزوير") ||
    query.includes("مزور") ||
    query.includes("sahte")
  ) {
    return [
      {
        label:
          lang === "en"
            ? "Document Forensics"
            : lang === "ar"
            ? "التحقيق الجنائي للمستندات"
            : lang === "tr"
            ? "Belge Adli Tıp Analizi"
            : "دادوەرییا بەڵگەناما (Document Forensics)",
        toolId: "document_forensics",
      },
    ];
  }

  if (
    query.includes("pdf") &&
    (query.includes("word") || query.includes("وۆرد") || query.includes("وورد") || query.includes("convert") || query.includes("گۆڕین") || query.includes("گوهۆڕین") || query.includes("تحويل"))
  ) {
    return [
      {
        label: lang === "en" ? "PDF ➔ Word" : lang === "ar" ? "تحويل PDF إلى Word" : lang === "tr" ? "PDF ➔ Word Dönüştür" : "ڤەکرنا PDF ➔ Word",
        toolId: "pdf_to_word",
      },
    ];
  }

  if (
    query.includes("pdf") &&
    (query.includes("merge") || query.includes("پێکەوە") || query.includes("کۆکردنەوە") || query.includes("کۆمکرن") || query.includes("دمج"))
  ) {
    return [
      {
        label: lang === "en" ? "Merge PDF" : lang === "ar" ? "دمج ملفات PDF" : lang === "tr" ? "PDF Birleştir" : "پێکڤە گرێدانا PDF",
        toolId: "pdf_merge",
      },
    ];
  }

  if (
    query.includes("بیرکاری") ||
    query.includes("math") ||
    query.includes("هاوکێشە") ||
    query.includes("integral") ||
    query.includes("derivative") ||
    query.includes("معادلة") ||
    query.includes("حساب") ||
    query.includes("matematik")
  ) {
    return [
      {
        label: lang === "en" ? "Math Solver" : lang === "ar" ? "حل المعادلات الرياضية" : lang === "tr" ? "Matematik Çözücü" : "شیکارکەرێ بیرکاریێ (Math Solver)",
        toolId: "solver",
      },
      {
        label: lang === "en" ? "LaTeX Editor" : lang === "ar" ? "محرر LaTeX" : lang === "tr" ? "LaTeX Editörü" : "دەستکاریکەرێ LaTeX",
        toolId: "latex_editor",
      },
    ];
  }

  if (
    query.includes("کورت") ||
    query.includes("summary") ||
    query.includes("summar") ||
    query.includes("مەلزەمە") ||
    query.includes("پوختە") ||
    query.includes("تلخيص") ||
    query.includes("ملخص") ||
    query.includes("تێز") ||
    query.includes("özet")
  ) {
    return [
      {
        label: lang === "en" ? "Study Summarizer" : lang === "ar" ? "تلخيص المحاضرات" : lang === "tr" ? "Ders Özeti Çıkarıcı" : "کورتکرنا مەلزەما (Summary)",
        toolId: "summary",
      },
      {
        label: lang === "en" ? "Research Paper Summarizer" : lang === "ar" ? "تلخيص الأوراق العلمية" : lang === "tr" ? "Makale Özeti" : "پوختەکرنا ڤەکۆلینێن زانستی",
        toolId: "paper_summarizer",
      },
    ];
  }

  if (
    query.includes("دەستی") ||
    query.includes("خەت") ||
    query.includes("دەست") ||
    query.includes("handwriting") ||
    query.includes("خط يد")
  ) {
    return [
      {
        label: lang === "en" ? "Handwriting Generator" : lang === "ar" ? "تحويل إلى خط يد" : lang === "tr" ? "El Yazısı Dönüştürücü" : "نڤیسینا دەستی (Handwriting)",
        toolId: "handwriting",
      },
    ];
  }

  if (
    query.includes("مرۆڤ") ||
    query.includes("humanize") ||
    query.includes("detector") ||
    query.includes("هۆمانایز") ||
    query.includes("humanizer")
  ) {
    return [
      {
        label: lang === "en" ? "AI Humanizer" : lang === "ar" ? "أنسنة نصوص الذكاء الاصطناعي" : lang === "tr" ? "Yapay Zeka İnsancıllaştırıcı" : "مرۆڤایەتیکرن (Humanizer AI)",
        toolId: "humanize",
      },
    ];
  }

  if (
    query.includes("ocr") ||
    query.includes("وێنە بۆ دەق") ||
    query.includes("دەرهێنان") ||
    query.includes("دەرئینان") ||
    query.includes("سکان")
  ) {
    return [
      {
        label: lang === "en" ? "OCR Text Extractor" : lang === "ar" ? "استخراج النصوص من الصور" : lang === "tr" ? "OCR Metin Çıkarıcı" : "دەرئینانا دەقی (OCR)",
        toolId: "ocr",
      },
    ];
  }

  if (
    query.includes("توێژینەوە") ||
    query.includes("ڤەکۆلین") ||
    query.includes("research") ||
    query.includes("سایتەیشن") ||
    query.includes("citation") ||
    query.includes("apa") ||
    query.includes("doi") ||
    query.includes("بحث")
  ) {
    return [
      {
        label: lang === "en" ? "Citation Generator" : lang === "ar" ? "توليد المراجع (Citation)" : lang === "tr" ? "Kaynak Gösterici" : "سایتەیشنا ڤەکۆلینێ (Citation)",
        toolId: "citation_generator",
      },
      {
        label: lang === "en" ? "DOI ➔ Citation" : lang === "ar" ? "DOI إلى مراجع" : lang === "tr" ? "DOI ➔ Kaynak" : "DOI ➔ Citation",
        toolId: "doi_citation",
      },
    ];
  }

  if (
    query.includes("ئامار") ||
    query.includes("stat") ||
    query.includes("excel") ||
    query.includes("regression") ||
    query.includes("إحصاء") ||
    query.includes("istatistik")
  ) {
    return [
      {
        label: lang === "en" ? "Statistics Lab" : lang === "ar" ? "مختبر الإحصاء" : lang === "tr" ? "İstatistik Laboratuvarı" : "تاقیگەها ئامارێ (Statistics Lab)",
        toolId: "statistics_lab",
      },
    ];
  }

  if (
    query.includes("ڤیدیۆ") ||
    query.includes("video") ||
    query.includes("داگرتن") ||
    query.includes("داگرتنا") ||
    query.includes("download") ||
    query.includes("تحميل") ||
    query.includes("indir")
  ) {
    return [
      {
        label: lang === "en" ? "Video Downloader" : lang === "ar" ? "تحميل الفيديو" : lang === "tr" ? "Video İndirici" : "داگرتنا ڤیدیۆیا (Video Downloader)",
        toolId: "video_downloader",
      },
      {
        label: lang === "en" ? "Video Converter" : lang === "ar" ? "محول صيغ الفيديو" : lang === "tr" ? "Video Dönüştürücü" : "گۆڕینا فۆرماتێ ڤیدیۆیێ",
        toolId: "video_converter",
      },
    ];
  }

  if (query.includes("فاکتوورە") || query.includes("فاکتورا") || query.includes("invoice") || query.includes("فاتورة") || query.includes("fatura")) {
    return [
      {
        label: lang === "en" ? "Invoice Generator" : lang === "ar" ? "إنشاء الفواتير" : lang === "tr" ? "Fatura Oluşturucu" : "دروستکەرێ فاکتورا (Invoice)",
        toolId: "invoice_tool",
      },
    ];
  }

  if (query.includes("قازانج") || query.includes("مووچە") || query.includes("salary") || query.includes("loan") || query.includes("قەرز") || query.includes("دراو") || query.includes("dra") || query.includes("عملة") || query.includes("راتب")) {
    return [
      {
        label: lang === "en" ? "Salary & Profit Calculator" : lang === "ar" ? "حاسبة الرواتب والأرباح" : lang === "tr" ? "Maaş ve Kâr Hesaplayıcı" : "ژمێریارێ مووچە و قازانجی",
        toolId: "profit_calc",
      },
      {
        label: lang === "en" ? "Currency Converter" : lang === "ar" ? "محول العملات" : lang === "tr" ? "Döviz Çevirici" : "گۆڕەرێ دراڤی (Currency)",
        toolId: "currency_calc",
      },
    ];
  }

  if (query.includes("زانکۆ") || query.includes("زانکو") || query.includes("نمرە") || query.includes("zanko") || query.includes("جامعة")) {
    return [
      {
        label: lang === "en" ? "Zanko Guide" : lang === "ar" ? "دليل القبول الجامعي" : lang === "tr" ? "Üniversite Rehberi" : "ڕێبەرێ زانکۆلاین (Zanko Guide)",
        toolId: "zanko_guide",
      },
    ];
  }

  if (query.includes("گرووپ") || query.includes("ژوور") || query.includes("هاوبەش") || query.includes("study group") || query.includes("room")) {
    return [
      {
        label: lang === "en" ? "Study Group Room" : lang === "ar" ? "غرفة الدراسة الجماعية" : lang === "tr" ? "Çalışma Odası" : "ژوورا خواندنا ب کۆم (Study Room)",
        toolId: "study_group",
      },
    ];
  }

  return [];
}

export function AiWelcomeAssistant({
  onSelectTool,
  onSelectCategory,
}: {
  onSelectTool: (toolId: string) => void;
  onSelectCategory: (categoryIndex: number) => void;
}) {
  const [lang, setLang] = useState<AssistantLanguage>("ku");
  const [typedStage, setTypedStage] = useState<number>(0);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [userInput, setUserInput] = useState<string>("");
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [lastUsedTool, setLastUsedTool] = useState<string | null>(null);

  const [chatMessages, setChatMessages] = useState<AssistantMessage[]>([]);


  const [robotAction, setRobotAction] = useState<"intro" | "idle" | "wave">("intro");

  // Handle Initial Entrance Wave -> Idle Float Transition
  useEffect(() => {
    const waveTimer = setTimeout(() => {
      setRobotAction("idle");
    }, 2400);

    return () => clearTimeout(waveTimer);
  }, []);

  const triggerRobotWave = () => {
    if (robotAction === "idle") {
      setRobotAction("wave");
      setTimeout(() => {
        setRobotAction("idle");
      }, 1500);
    }
  };

  const t = LOCALIZED_GREETINGS[lang] || LOCALIZED_GREETINGS.ku;

  // Check returning user state & staged typing entrance
  useEffect(() => {
    try {
      const storedLast = localStorage.getItem("ai_study_last_tool");
      if (storedLast) setLastUsedTool(storedLast);
    } catch (_) {}

    // Staged entrance animation sequence
    const timer1 = setTimeout(() => setTypedStage(1), 350);
    const timer2 = setTimeout(() => setTypedStage(2), 1200);
    const timer3 = setTimeout(() => setTypedStage(3), 2200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);

  useEffect(() => {
    if (isChatOpen && chatMessages.length === 0) {
      setChatMessages([
        {
          id: "init_1",
          sender: "ai",
          text:
            lang === "ku"
              ? "سڵاڤ! ئەز دشێم هاریکاریا تە بکەم باشترین ئامراز ببینی ل دویڤ پێدڤیا تە. تە دڤێت چ بکەی یان چ پرسیار هەیە؟"
              : lang === "ar"
              ? "مرحباً! يمكنني مساعدتك في العثور على الأداة المناسبة أو الإجابة على أي سؤال فوراً. ما الذي تريد القيام به؟"
              : lang === "tr"
              ? "Merhaba! İhtiyacınıza en uygun aracı bulmanıza ve tüm sorularınızı yanıtlamaya hazırım. Ne yapmak istiyorsunuz?"
              : "Hello! I can answer your questions and recommend the exact tools you need. What would you like to accomplish today?",
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          recommendations: [
            { label: "شیکارکەرێ بیرکاریێ (Math Solver)", toolId: "solver" },
            { label: "کورتکرنا مەلزەما (Summarizer)", toolId: "summary" },
            { label: "گوهۆڕینا PDF بۆ Word", toolId: "pdf_to_word" },
            { label: "تاقیگەها ئامارێ (Statistics Lab)", toolId: "statistics_lab" },
          ],
        },
      ]);
    }
  }, [isChatOpen, lang]);

  // Multilingual Dynamic AI Response Handler
  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isThinking) return;

    const query = userInput.trim();
    const detectedLang = detectUserLanguage(query);
    const recs = extractToolRecommendations(query, detectedLang);

    const userMsg: AssistantMessage = {
      id: `u_${Date.now()}`,
      sender: "user",
      text: query,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setUserInput("");
    setIsThinking(true);
    setIsChatOpen(true);

    try {
      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemPrompt: WELCOME_NAVIGATOR_SYSTEM_PROMPT,
          messages: [
            ...chatMessages.slice(-6).map((m) => ({
              role: m.sender === "user" ? ("user" as const) : ("assistant" as const),
              content: m.text,
            })),
            { role: "user", content: query },
          ],
        }),
      });

      if (resp.ok && resp.body) {
        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let acc = "";
        const aiMsgId = `ai_${Date.now()}`;

        setChatMessages((prev) => [
          ...prev,
          {
            id: aiMsgId,
            sender: "ai",
            text: "",
            recommendations: recs,
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          },
        ]);

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          let nl: number;
          while ((nl = buffer.indexOf("\n")) !== -1) {
            let line = buffer.slice(0, nl);
            buffer = buffer.slice(nl + 1);
            if (line.endsWith("\r")) line = line.slice(0, -1);
            if (!line.startsWith("data: ")) continue;
            const jsonStr = line.slice(6).trim();
            if (jsonStr === "[DONE]") break;
            try {
              const parsed = JSON.parse(jsonStr);
              const delta = parsed?.choices?.[0]?.delta?.content;
              if (delta) {
                acc += delta;
                setChatMessages((prev) =>
                  prev.map((msg) => (msg.id === aiMsgId ? { ...msg, text: acc } : msg))
                );
              }
            } catch {
              buffer = line + "\n" + buffer;
              break;
            }
          }
        }
      } else {
        throw new Error("Chat response status not OK");
      }
    } catch (_) {
      // Intelligent Multilingual Instant Fallback Response
      let fallbackReply = "";
      if (detectedLang === "en") {
        fallbackReply =
          recs.length > 0
            ? "I can help you with our advanced tools! Here is the best tool suited for your request:"
            : "I am your AI study and productivity guide, ready to introduce you to all our platform tools!";
      } else if (detectedLang === "ar") {
        fallbackReply =
          recs.length > 0
            ? "أنا هنا لمساعدتك من خلال أدواتنا المتطورة! إليك الأداة المناسبة لطلبك مباشرة:"
            : "أنا دليلك الذكي للتعرف على كافة أدوات منصة بوختەیا AI واستخدامها بكل سهولة.";
      } else if (detectedLang === "tr") {
        fallbackReply =
          recs.length > 0
            ? "Gelişmiş araçlarımızla size yardımcı olabilirim! İhtiyacınıza en uygun araç aşağıdadır:"
            : "Platformumuzun tüm yapay zeka araçlarını keşfetmeniz ve kullanmanız için buradayım.";
      } else {
        fallbackReply =
          recs.length > 0
            ? "ئەز دشێم هاریکاریا تە بکەم ب ئامرازێن مە یێن زۆر پێشکەفتی! ئەڤە باشترین ئامرازە بۆ داخوازییا تە:"
            : "ئەز ڕێبەرێ تەیێ زیرەکم بۆ ناساندن و بکارئینانا هەمی ئامرازێن پێشکەفتی یێن پلاتفۆرمێ مە!";
      }

      setChatMessages((prev) => [
        ...prev,
        {
          id: `ai_${Date.now()}`,
          sender: "ai",
          text: fallbackReply,
          recommendations: recs,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="w-full relative rounded-3xl overflow-hidden border border-emerald-500/30 dark:border-emerald-500/20 bg-linear-to-br from-emerald-500/10 via-teal-500/5 to-cyan-500/10 backdrop-blur-xl shadow-xl shadow-emerald-500/5 p-5 md:p-7 transition-all duration-300">
      {/* Ambient background glow & soft animated orb */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -z-10 animate-pulse-slow" />
      <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Main Layout: Character Avatar + Speech Bubble */}
      <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
        {/* 1. 3D Animated AI Character Avatar */}
        <div
          onMouseEnter={() => {
            setIsHovered(true);
            triggerRobotWave();
          }}
          onMouseLeave={() => setIsHovered(false)}
          className="relative shrink-0 flex flex-col items-center group cursor-pointer select-none"
          onClick={() => {
            triggerRobotWave();
            setIsChatOpen(!isChatOpen);
          }}
          title="کرتە بکە بۆ گفتوگۆ و پرسیار لە یاریدەدەری زیرەک"
        >
          {/* Ambient Glow Aura */}
          <div
            className={`absolute -inset-2 rounded-full bg-linear-to-r from-emerald-500 via-teal-400 to-cyan-500 blur-xl transition-all duration-700 pointer-events-none ${
              isHovered ? "opacity-70 scale-110" : "opacity-30"
            }`}
          />

          {/* Interactive Speech / Greeting Mini Bubble (Pops during wave) */}
          <div
            className={`absolute -top-3 sm:-top-4 z-20 transition-all duration-300 transform pointer-events-none ${
              robotAction !== "idle" || isHovered
                ? "opacity-100 scale-100 translate-y-0"
                : "opacity-0 scale-75 translate-y-2"
            }`}
          >
            <div className="px-2.5 py-1 rounded-full bg-card/95 dark:bg-card/90 border border-emerald-500/40 text-emerald-600 dark:text-emerald-300 text-[11px] font-black shadow-lg backdrop-blur-md flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400 animate-spin" />
              <span>{t.greeting}</span>
            </div>
          </div>

          {/* 3D Robot Image Container with Animations */}
          <div
            className={`relative w-28 h-28 sm:w-32 sm:h-32 md:w-36 md:h-36 z-10 flex items-center justify-center ${
              robotAction === "intro"
                ? "animate-robot-wave"
                : robotAction === "wave"
                ? "animate-robot-interactive-wave"
                : "animate-robot-idle"
            }`}
          >
            <img
              src="/ai-assistant-3d.png"
              alt="AI 3D Assistant Character"
              className="w-full h-full object-contain filter drop-shadow-[0_12px_24px_rgba(16,185,129,0.28)] transition-transform duration-300 group-hover:scale-105"
              loading="eager"
            />
          </div>

          {/* Dynamic 3D Ground Shadow that pulses in sync with floating */}
          <div className="w-20 sm:w-24 h-2.5 rounded-full bg-emerald-950/20 dark:bg-emerald-400/10 blur-xs -mt-1 pointer-events-none animate-robot-shadow" />

          {/* Assistant Online Status Badge */}
          <div className="mt-2 px-3 py-0.5 rounded-full bg-card/90 border border-emerald-500/30 shadow-xs flex items-center gap-1.5 text-[11px] font-bold text-foreground transition-colors group-hover:border-emerald-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>{t.status}</span>
          </div>
        </div>

        {/* 2. Unified Clean Glassmorphic Speech Bubble & Conversational Box */}
        <div className="flex-1 min-w-0 space-y-4 text-right md:text-right w-full">
          <div className="p-4 sm:p-5 rounded-3xl bg-card/90 dark:bg-card/80 border border-emerald-500/25 shadow-lg space-y-3 relative backdrop-blur-md">
            {/* Bubble Tail */}
            <div className="hidden md:block absolute top-6 -right-2.5 w-4 h-4 bg-card/90 border-t border-r border-emerald-500/25 rotate-45" />

            {/* Stage 1: Welcome Greeting (Right Aligned) */}
            <div className="transition-opacity duration-300">
              <h3 className="text-lg sm:text-xl font-black text-foreground flex items-center gap-2 justify-start text-right">
                <span>{lastUsedTool ? t.returning : t.welcome}</span>
              </h3>
            </div>

            {/* Stage 2: Kurdish Intro */}
            {typedStage >= 1 && (
              <p className="text-xs sm:text-sm text-foreground/90 font-medium leading-relaxed animate-in fade-in-0 slide-in-from-bottom-2 duration-300 text-right">
                {t.intro}
              </p>
            )}

            {/* Stage 3: Unified Conversation Stream (Naturally Expands Downwards) */}
            {chatMessages.length > 0 && (
              <div className="space-y-3 pt-3 pb-1 border-t border-emerald-500/15 animate-in fade-in-0 duration-300">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${msg.sender === "user" ? "items-start" : "items-end"} space-y-1`}
                  >
                    {/* Message Bubble Body */}
                    <div
                      className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed max-w-[95%] sm:max-w-[92%] ${
                        msg.sender === "user"
                          ? "bg-primary text-primary-foreground font-medium rounded-tl-xs"
                          : "bg-secondary/90 border border-emerald-500/20 text-foreground font-normal rounded-tr-xs shadow-xs"
                      }`}
                    >
                      {msg.text.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
                        part.startsWith("**") && part.endsWith("**") ? (
                          <strong key={i} className="font-extrabold text-emerald-700 dark:text-emerald-300">
                            {part.slice(2, -2)}
                          </strong>
                        ) : (
                          part
                        )
                      )}
                    </div>

                    {/* Direct Action Recommendations Buttons (Centered, Larger, Radiant Gradient) */}
                    {msg.recommendations && msg.recommendations.length > 0 && (
                      <div className="w-full flex flex-wrap justify-center items-center gap-2 pt-2 pb-1 animate-in zoom-in-95 duration-300">
                        {msg.recommendations.map((rec, idx) => (
                          <button
                            key={idx}
                            onClick={() => onSelectTool(rec.toolId)}
                            className="group py-2.5 px-5 sm:px-6 rounded-2xl bg-linear-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:via-teal-500 hover:to-cyan-500 text-white text-xs sm:text-sm font-black shadow-lg shadow-emerald-600/30 border border-white/25 transition-all duration-300 transform hover:scale-[1.04] active:scale-[0.96] flex items-center justify-center gap-2.5 cursor-pointer ring-2 ring-emerald-400/20 hover:ring-emerald-400/50"
                          >
                            <Sparkles className="w-4 h-4 text-amber-300 shrink-0 animate-pulse" />
                            <span className="tracking-normal font-extrabold">{rec.label}</span>
                            <ArrowRight className="w-4 h-4 shrink-0 rtl:rotate-180 transition-transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1" />
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                {isThinking && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground p-1 font-mono">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-500 animate-spin" />
                    <span>{t.thinking}</span>
                  </div>
                )}
              </div>
            )}

            {/* Stage 4: Single Interactive Input Form */}
            <form onSubmit={handleUserSubmit} className="pt-1 flex items-center gap-2">
              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder={t.inputPlaceholder}
                className="flex-1 h-11 px-4 rounded-2xl bg-secondary/50 dark:bg-secondary/30 border border-emerald-500/30 focus:border-emerald-500 text-xs sm:text-sm font-medium text-foreground placeholder:text-muted-foreground/60 shadow-xs focus:ring-2 focus:ring-emerald-500/20 focus:outline-none transition-all text-right"
              />
              <button
                type="submit"
                disabled={isThinking || !userInput.trim()}
                className="w-11 h-11 shrink-0 rounded-2xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/20 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed hover:scale-[1.05] active:scale-[0.95]"
                title={t.sendBtn}
                aria-label={t.sendBtn}
              >
                <Send className="w-4 h-4 rtl:rotate-180" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
