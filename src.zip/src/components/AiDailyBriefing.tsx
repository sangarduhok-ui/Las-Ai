﻿import { useState, useEffect } from "react";
import {
  Sun,
  Target,
  Wrench,
  BookOpen,
  Calculator,
  Lightbulb,
  CheckCircle2,
  Flame,
  ArrowRight,
  Eye,
  ChevronDown,
  Zap,
} from "lucide-react";

interface DailyContent {
  greeting: string;
  dateStr: string;
  studyGoal: string;
  usefulTool: { name: string; id: string; desc: string; tag: string };
  newWord: { word: string; phonetic: string; kurdish: string; definition: string; example: string };
  mathChallenge: { question: string; answer: string; hint: string };
  researchTip: { title: string; tip: string };
}

const DAILY_CURATED_DATA: DailyContent[] = [
  {
    greeting: "ڕۆژباش و بەیانیت باش! ئەڤرۆ ڕۆژەکا نوویە بۆ سەرکەفتنێ.",
    dateStr: "دووشەمب - Monday",
    studyGoal: "خواندنا 45 خۆلەکان ل سەر بابەتی بیرکاری و دروستکرنا کورتەیەکێ ب ئامرازێن AI.",
    usefulTool: { name: "Document Forensics & AI Detection", id: "document_forensics", desc: "پشکنینا دەستکاری، مێتاداتا و ساختەبوونا دۆکیۆمێنتان ب زیرەکیا دەستکرد.", tag: "Academic Security" },
    newWord: { word: "Empirical", phonetic: "/empierikel/", kurdish: "ئەزموونی / پشتبەستوو ب بەلگان", definition: "Based on observation or experience rather than theory.", example: "Our conclusions are backed by empirical evidence from 500 participants." },
    mathChallenge: { question: "ئەگەر 2^(x+1)=32 بیت، بهایێ x چەند بیت؟", answer: "x=4 (چونکی 32=2^5، x+1=5 داتە x=4)", hint: "ژمارە 32 وەکی بنکەیێ 2 بنڤیسە." },
    researchTip: { title: "داڕشتنا پوختەیا ئەکادیمی (Abstract)", tip: "پوختەیا توێژینەوەیێ با ژ 250 وشەیان دەرباز نەبیت: کێشە، مێتۆد، گرنگترین دۆزینەوە و ئەنجامێ." },
  },
  {
    greeting: "ڕۆژباش! ئەڤرۆ دەرفەتەکا نوویە بۆ فێربوونا تشتێن مەزن.",
    dateStr: "سێشەمب - Tuesday",
    studyGoal: "پێداچوونەڤەیا سەرچاوەیێن ڤەکۆلینێ ب فۆرماتێ ستانداردێ APA د Citation Generator دا.",
    usefulTool: { name: "Statistics Lab & Data Science", id: "statistics_lab", desc: "شیکاریا بلەز یا Mean, Median, Correlation, Regression ل سەر فایلا Excel.", tag: "Data Analysis" },
    newWord: { word: "Pragmatic", phonetic: "/praegmaetik/", kurdish: "واقیعی / کرداری", definition: "Dealing with things sensibly and realistically based on practical considerations.", example: "We need a pragmatic approach to solve the computational complexity problem." },
    mathChallenge: { question: "ڕەگێ دووجایێ ژمارە 196 یەکسانە ب چەند؟", answer: "14 (چونکی 14x14=196)", hint: "ژمارەیەکە د ناڤبەرا 10 و 20 دا کو دوماهیکا لێکدانا وێ 4 بیت." },
    researchTip: { title: "هەڵبژارتنا سەرچاوەیێ باوەرپێکری", tip: "هەردەم پەڕاوێن 5 ساڵێن بووری و گۆڤارێن خاوەن ئیمپاکت فاکتەرا بلند (Scopus/Clarivate) بکاربینە." },
  },
  {
    greeting: "دەمباش! وزەیەکا نوو بۆ خواندنێ و سەرکەفتنێ.",
    dateStr: "چوارشەمب - Wednesday",
    studyGoal: "پشکداریکرن د ژوورا خواندنا ب کۆم دا (Study Group Room) و شیکارکرنا هاوکێشەیان.",
    usefulTool: { name: "LaTeX Equation Editor & KaTeX", id: "latex_editor", desc: "نڤیسین و دیتنا ڕاستەوخۆ یا هاوکێشەیێن بیرکاری و زانستی ب کۆدێ LaTeX.", tag: "Mathematics" },
    newWord: { word: "Paradigm", phonetic: "/paeradam/", kurdish: "مۆدێل / چەمکێ بنەڕەتی", definition: "A typical example or pattern; a distinct set of concepts or thought patterns.", example: "Quantum computing represents a paradigm shift in data processing capabilities." },
    mathChallenge: { question: "تەواوکاری 6x dx یەکسانە ب چی؟", answer: "3x2 + C (چونکی 6*(x2/2)=3x2+C)", hint: "یاسایا هێزا تەواوکاریێ: توانێ زێدە بکە و دابەشی توانا نوو بکە." },
    researchTip: { title: "پاراستنا بەستەرێ DOI", tip: "هەر وتارەکا زانستی وەردگری، ژمارەیا DOI دگەل ناڤێ نڤیسەری پاشەکەوت بکە بۆ دروستکرنا سایتەیشنی." },
  },
];

const THEMES = {
  goal:  { glow: "rgba(16,185,129,0.4)",  icon1: "#34d399", icon2: "#14b8a6", accent: "#10b981",  shimmer: "rgba(16,185,129,0.08)"  },
  tool:  { glow: "rgba(99,102,241,0.4)",  icon1: "#818cf8", icon2: "#a855f7", accent: "#6366f1",  shimmer: "rgba(99,102,241,0.08)"  },
  word:  { glow: "rgba(245,158,11,0.4)",  icon1: "#fbbf24", icon2: "#f97316", accent: "#f59e0b",  shimmer: "rgba(245,158,11,0.08)"  },
  math:  { glow: "rgba(6,182,212,0.4)",   icon1: "#22d3ee", icon2: "#0ea5e9", accent: "#06b6d4",  shimmer: "rgba(6,182,212,0.08)"   },
  tip:   { glow: "rgba(168,85,247,0.4)",  icon1: "#c084fc", icon2: "#ec4899", accent: "#a855f7",  shimmer: "rgba(168,85,247,0.08)"  },
};

interface CardProps {
  id: string;
  expanded: boolean;
  theme: typeof THEMES.goal;
  icon: React.ReactNode;
  title: string;
  teaser: string;
  onToggle: () => void;
  children: React.ReactNode;
}

function Card({ id, expanded, theme, icon, title, teaser, onToggle, children }: CardProps) {
  const [hov, setHov] = useState(false);
  return (
    <div style={{ perspective: "900px" }} className="h-full">
      <div
        onClick={onToggle}
        onMouseEnter={() => setHov(true)}
        onMouseLeave={() => setHov(false)}
        className="relative rounded-2xl cursor-pointer h-full overflow-hidden"
        style={{
          transition: "transform 0.35s cubic-bezier(.23,1,.32,1), box-shadow 0.35s cubic-bezier(.23,1,.32,1)",
          transform: expanded
            ? "translateY(-4px) scale(1.006)"
            : hov
            ? "translateY(-8px) rotateX(2deg) rotateY(-1.5deg) scale(1.018)"
            : "translateY(0) rotateX(0) rotateY(0) scale(1)",
          background: expanded || hov
            ? `linear-gradient(145deg, ${theme.shimmer.replace("0.08", "0.14")}, rgba(255,255,255,0.03))`
            : "linear-gradient(145deg, rgba(255,255,255,0.04), rgba(0,0,0,0.04))",
          border: `1px solid ${expanded ? theme.glow.replace("0.4", "0.55") : hov ? theme.glow.replace("0.4", "0.35") : "rgba(255,255,255,0.09)"}`,
          boxShadow: expanded
            ? `0 20px 60px ${theme.glow}, 0 4px 20px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.14)`
            : hov
            ? `0 14px 40px ${theme.glow}, 0 4px 12px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.1)`
            : "0 4px 16px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.07)",
          backdropFilter: "blur(18px)",
        }}
      >
        {/* Prismatic top edge */}
        <div className="absolute top-0 left-0 right-0 h-px" style={{
          background: expanded || hov
            ? `linear-gradient(90deg, transparent, ${theme.glow.replace("0.4", "0.8")}, transparent)`
            : "rgba(255,255,255,0.07)",
          transition: "background 0.3s ease",
        }} />

        {/* Shimmer sweep */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
          <div style={{
            position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
            background: "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.06) 50%, transparent 60%)",
            animation: "shimmer3d 3.5s ease-in-out infinite",
          }} />
        </div>

        {/* Bottom glow reflection */}
        {(expanded || hov) && (
          <div className="absolute bottom-0 left-1/4 right-1/4 h-16 pointer-events-none" style={{
            background: `radial-gradient(ellipse, ${theme.glow.replace("0.4", "0.12")}, transparent)`,
            filter: "blur(10px)",
          }} />
        )}

        <div className="relative z-10 p-4">
          {/* Header */}
          <div className="flex items-center justify-between gap-2 mb-2.5">
            <div className="flex items-center gap-2.5">
              {/* 3D Icon ball */}
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0" style={{
                background: `linear-gradient(135deg, ${theme.icon1}, ${theme.icon2})`,
                boxShadow: expanded || hov
                  ? `0 6px 22px ${theme.glow}, 0 2px 8px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.3)`
                  : `0 3px 12px ${theme.glow.replace("0.4", "0.25")}, inset 0 1px 0 rgba(255,255,255,0.2)`,
                transform: hov ? "scale(1.18) rotate(-5deg)" : "scale(1) rotate(0deg)",
                transition: "transform 0.3s cubic-bezier(.23,1,.32,1), box-shadow 0.3s ease",
              }}>
                {icon}
              </div>
              <h3 className="text-xs sm:text-sm font-extrabold text-foreground" style={{ opacity: expanded || hov ? 1 : 0.88 }}>
                {title}
              </h3>
            </div>
            {/* Chevron toggle */}
            <div className="flex items-center gap-1 text-[11px] font-bold shrink-0" style={{ color: theme.accent }}>
              <span>{expanded ? "داخستن" : "کرتێ بکە"}</span>
              <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{
                background: expanded ? `${theme.glow.replace("0.4", "0.18")}` : "rgba(255,255,255,0.06)",
                border: `1px solid ${expanded ? theme.glow.replace("0.4", "0.45") : "rgba(255,255,255,0.09)"}`,
                transform: expanded ? "rotate(180deg)" : "rotate(0deg)",
                transition: "transform 0.3s ease, background 0.3s ease",
              }}>
                <ChevronDown className="w-3 h-3" />
              </div>
            </div>
          </div>

          {/* Teaser */}
          <p className="text-[11px] font-medium truncate text-muted-foreground" style={{ opacity: expanded ? 0.65 : 1 }}>
            {teaser}
          </p>

          {/* Expanded body */}
          {expanded && (
            <div className="mt-3.5 pt-3.5" style={{
              borderTop: `1px solid ${theme.glow.replace("0.4", "0.2")}`,
              animation: "cardReveal 0.28s cubic-bezier(.23,1,.32,1) both",
            }}>
              {children}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function AiDailyBriefing({ onSelectTool }: { onSelectTool?: (toolId: string) => void }) {
  const [dayIndex, setDayIndex] = useState(0);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [goalCompleted, setGoalCompleted] = useState(false);
  const [showMathAnswer, setShowMathAnswer] = useState(false);
  const [streakCount, setStreakCount] = useState(3);
  const [progress, setProgress] = useState(65);

  useEffect(() => { setDayIndex(new Date().getDay() % DAILY_CURATED_DATA.length); }, []);

  const today = DAILY_CURATED_DATA[dayIndex] || DAILY_CURATED_DATA[0];
  const toggle = (id: string) => setExpandedCard(p => p === id ? null : id);
  const toggleGoal = (e: React.MouseEvent) => {
    e.stopPropagation();
    setGoalCompleted(g => {
      setProgress(p => g ? Math.max(0, p - 20) : Math.min(100, p + 20));
      if (!g) setStreakCount(s => s + 1);
      return !g;
    });
  };

  return (
    <div className="w-full relative">
      <style>{`
        @keyframes shimmer3d {
          0%   { transform: translateX(-120%) skewX(-12deg); }
          100% { transform: translateX(260%)  skewX(-12deg); }
        }
        @keyframes floatFlame {
          0%,100% { transform: translateY(0)   scale(1);    }
          50%      { transform: translateY(-5px) scale(1.08); }
        }
        @keyframes spinSun { to { transform: rotate(360deg); } }
        @keyframes cardReveal {
          from { opacity:0; transform:translateY(14px) scale(0.97); }
          to   { opacity:1; transform:translateY(0)    scale(1);    }
        }
        @keyframes orb1 {
          0%,100% { transform: translate(0,0)     scale(1);    opacity:.5; }
          50%      { transform: translate(12px,8px) scale(1.06); opacity:.8; }
        }
        @keyframes orb2 {
          0%,100% { transform: translate(0,0)       scale(1);    opacity:.4; }
          50%      { transform: translate(-10px,6px) scale(1.04); opacity:.7; }
        }
      `}</style>

      {/* Outer 3D glass shell */}
      <div className="relative rounded-3xl overflow-hidden" style={{
        background: "linear-gradient(135deg, rgba(99,102,241,0.09) 0%, rgba(168,85,247,0.055) 50%, rgba(6,182,212,0.09) 100%)",
        border: "1px solid rgba(255,255,255,0.1)",
        boxShadow: "0 30px 90px rgba(99,102,241,0.18), 0 8px 32px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.12)",
        backdropFilter: "blur(28px)",
      }}>
        {/* Prismatic header line */}
        <div className="absolute top-0 left-0 right-0 h-px" style={{
          background: "linear-gradient(90deg, transparent, rgba(168,85,247,0.7), rgba(99,102,241,0.9), rgba(6,182,212,0.7), transparent)",
        }} />

        {/* Ambient orbs */}
        <div className="absolute top-[-80px] right-[-80px] w-72 h-72 rounded-full pointer-events-none" style={{
          background: "radial-gradient(circle, rgba(99,102,241,0.22) 0%, transparent 70%)",
          animation: "orb1 8s ease-in-out infinite",
        }} />
        <div className="absolute bottom-[-60px] left-[-60px] w-64 h-64 rounded-full pointer-events-none" style={{
          background: "radial-gradient(circle, rgba(6,182,212,0.18) 0%, transparent 70%)",
          animation: "orb2 10s ease-in-out infinite",
        }} />
        <div className="absolute inset-0 pointer-events-none" style={{
          background: "radial-gradient(ellipse 60% 40% at 50% 60%, rgba(168,85,247,0.07), transparent)",
        }} />

        <div className="relative z-10 p-5 md:p-6 space-y-5">

          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-black" style={{
                  background: "linear-gradient(135deg, rgba(245,158,11,0.22), rgba(251,191,36,0.1))",
                  border: "1px solid rgba(245,158,11,0.4)",
                  color: "#f59e0b",
                  boxShadow: "0 0 18px rgba(245,158,11,0.22), inset 0 1px 0 rgba(255,255,255,0.12)",
                }}>
                  <Sun className="w-3.5 h-3.5" style={{ animation: "spinSun 9s linear infinite" }} />
                  AI Daily Briefing
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full" style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.09)",
                  color: "var(--muted-foreground)",
                }}>
                  {today.dateStr}
                </span>
              </div>
              <h2 className="text-base md:text-lg font-black text-foreground leading-snug">{today.greeting}</h2>
            </div>

            {/* Streak badge */}
            <div className="flex items-center gap-3 shrink-0 px-4 py-2.5 rounded-2xl" style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.07), rgba(255,255,255,0.02))",
              border: "1px solid rgba(255,255,255,0.11)",
              boxShadow: "0 4px 24px rgba(0,0,0,0.22), inset 0 1px 0 rgba(255,255,255,0.1)",
              backdropFilter: "blur(12px)",
            }}>
              <div className="flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-500 fill-amber-500" style={{ animation: "floatFlame 3s ease-in-out infinite" }} />
                <span className="font-mono font-black text-amber-400 text-sm">{streakCount}</span>
                <span className="text-[11px] text-muted-foreground">ڕۆژ</span>
              </div>
              <div className="w-px h-5" style={{ background: "rgba(255,255,255,0.12)" }} />
              <div>
                <div className="text-[9px] text-muted-foreground font-bold">پێشکەفتن</div>
                <div className="text-xs font-black font-mono" style={{ color: "#818cf8" }}>{progress}%</div>
              </div>
              {/* Mini glowing progress bar */}
              <div className="w-14 h-2 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.08)" }}>
                <div className="h-full rounded-full transition-all duration-500" style={{
                  width: `${progress}%`,
                  background: "linear-gradient(90deg, #818cf8, #c084fc)",
                  boxShadow: "0 0 8px rgba(129,140,248,0.9)",
                }} />
              </div>
            </div>
          </div>

          {/* Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">

            {/* 1. Study Goal */}
            <Card id="goal" expanded={expandedCard === "goal"} theme={THEMES.goal}
              icon={<Target className="w-4 h-4" />} title="ئامانجێ خواندنێ"
              teaser={today.studyGoal} onToggle={() => toggle("goal")}>
              <div className="space-y-3">
                <p className="text-xs text-foreground/90 font-medium leading-relaxed">{today.studyGoal}</p>
                <button onClick={toggleGoal} className="w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 cursor-pointer" style={{
                  background: goalCompleted ? "linear-gradient(135deg,#10b981,#059669)" : "linear-gradient(135deg,rgba(16,185,129,0.14),rgba(16,185,129,0.07))",
                  border: `1px solid ${goalCompleted ? "rgba(16,185,129,0.9)" : "rgba(16,185,129,0.32)"}`,
                  color: goalCompleted ? "#fff" : "#10b981",
                  boxShadow: goalCompleted ? "0 4px 18px rgba(16,185,129,0.45)" : "none",
                  transition: "all 0.2s ease",
                }}>
                  <CheckCircle2 className="w-4 h-4" />
                  {goalCompleted ? "ئامانج هاتە تەمامکرن! ✨" : "نیشانکرن وەکی تەمامکری"}
                </button>
              </div>
            </Card>

            {/* 2. Useful Tool */}
            <Card id="tool" expanded={expandedCard === "tool"} theme={THEMES.tool}
              icon={<Wrench className="w-4 h-4" />} title="ئامرازێ پێشنیارکری"
              teaser={today.usefulTool.name} onToggle={() => toggle("tool")}>
              <div className="space-y-3">
                <div>
                  <h4 className="text-xs font-black text-foreground mb-1">{today.usefulTool.name}</h4>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">{today.usefulTool.desc}</p>
                </div>
                <button onClick={e => { e.stopPropagation(); onSelectTool?.(today.usefulTool.id); }}
                  className="w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 cursor-pointer" style={{
                  background: "linear-gradient(135deg,#6366f1,#8b5cf6)",
                  border: "1px solid rgba(99,102,241,0.6)",
                  color: "#fff",
                  boxShadow: "0 4px 20px rgba(99,102,241,0.45)",
                  transition: "all 0.2s ease",
                }}>
                  <Zap className="w-3.5 h-3.5" /><span>تاقیکرنا ئامرازی</span><ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </Card>

            {/* 3. Vocabulary */}
            <Card id="word" expanded={expandedCard === "word"} theme={THEMES.word}
              icon={<BookOpen className="w-4 h-4" />} title="پەیڤا نوو"
              teaser={`${today.newWord.word} - ${today.newWord.kurdish}`} onToggle={() => toggle("word")}>
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-black text-foreground">{today.newWord.word}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md" style={{ background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.28)", color: "#f59e0b" }}>
                    {today.newWord.phonetic}
                  </span>
                </div>
                <div className="text-xs font-extrabold" style={{ color: "#f59e0b" }}>{today.newWord.kurdish}</div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{today.newWord.definition}</p>
                <div className="p-2.5 rounded-xl text-[10px] italic" style={{ background: "linear-gradient(135deg,rgba(245,158,11,0.1),rgba(249,115,22,0.05))", border: "1px solid rgba(245,158,11,0.22)", color: "var(--foreground)" }}>
                  "{today.newWord.example}"
                </div>
              </div>
            </Card>

            {/* 4. Math Challenge */}
            <Card id="math" expanded={expandedCard === "math"} theme={THEMES.math}
              icon={<Calculator className="w-4 h-4" />} title="ئالنگاریا بیرکاریێ"
              teaser={today.mathChallenge.question} onToggle={() => toggle("math")}>
              <div className="space-y-2.5">
                <p className="text-xs font-bold text-foreground">{today.mathChallenge.question}</p>
                {showMathAnswer ? (
                  <div className="p-3 rounded-xl text-xs font-mono font-black" style={{ background: "linear-gradient(135deg,rgba(6,182,212,0.15),rgba(56,189,248,0.07))", border: "1px solid rgba(6,182,212,0.38)", color: "#06b6d4", boxShadow: "0 0 20px rgba(6,182,212,0.14)", animation: "cardReveal 0.2s both" }}>
                    v {today.mathChallenge.answer}
                  </div>
                ) : (
                  <button onClick={e => { e.stopPropagation(); setShowMathAnswer(true); }}
                    className="w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 cursor-pointer" style={{ background: "linear-gradient(135deg,rgba(6,182,212,0.12),rgba(6,182,212,0.06))", border: "1px solid rgba(6,182,212,0.32)", color: "#06b6d4", transition: "all 0.2s ease" }}>
                    <Eye className="w-3.5 h-3.5" /><span>دیتنا بەرسڤا شیکارکری</span>
                  </button>
                )}
              </div>
            </Card>

            {/* 5. Research Tip */}
            <div className="sm:col-span-2">
              <Card id="tip" expanded={expandedCard === "tip"} theme={THEMES.tip}
                icon={<Lightbulb className="w-4 h-4" />} title="ئامۆژگاریا ڤەکۆلینێ"
                teaser={today.researchTip.title} onToggle={() => toggle("tip")}>
                <div className="space-y-2">
                  <h4 className="text-xs font-black text-foreground">{today.researchTip.title}</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">{today.researchTip.tip}</p>
                </div>
              </Card>
            </div>
          </div>

          {/* Dot row */}
          <div className="flex items-center justify-center gap-2 pt-1">
            {Object.values(THEMES).map((t, i) => (
              <div key={i} className="w-1.5 h-1.5 rounded-full opacity-50" style={{ background: t.icon1, boxShadow: `0 0 4px ${t.glow}` }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
