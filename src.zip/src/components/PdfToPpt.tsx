import { useState, useRef, DragEvent } from "react";
import { Upload, X, Loader2, FileText, Download, Presentation } from "lucide-react";

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function PdfToPpt() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [dropActive, setDropActive] = useState(false);
  const [result, setResult] = useState<{ url: string; name: string; slides: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const pickFile = (f: File | null) => {
    if (!f) return;
    if (f.type !== "application/pdf" && !f.name.endsWith(".pdf")) { setError("تنێ فایلێن PDF قبول دکرن."); return; }
    setFile(f); setError(null); setResult(null);
  };

  const onDragOver = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDropActive(true); };
  const onDragLeave = () => setDropActive(false);
  const onDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDropActive(false); pickFile(e.dataTransfer.files?.[0] || null); };

  const convert = async () => {
    if (!file) return;
    setLoading(true); setError(null); setResult(null); setProgress("د ئامادەکرنێدا...");
    try {
      // 1. Extract text per page with PDF.js
      // @ts-expect-error transitive
      const pdfjsLib = await import("pdfjs-dist/build/pdf.mjs").catch(() => import("pdfjs-dist"));
      pdfjsLib.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
      const ab = await file.arrayBuffer();
      const pdfDoc = await pdfjsLib.getDocument({ data: ab }).promise;
      const totalPages = pdfDoc.numPages;

      const pageTexts: { title: string; body: string }[] = [];
      for (let i = 1; i <= totalPages; i++) {
        setProgress(`لاپەر ${i} / ${totalPages} — د خواندنێدا...`);
        const page = await pdfDoc.getPage(i);
        const tc = await page.getTextContent();
        interface TItem { str: string; transform: number[]; hasEOL?: boolean }
        const items = tc.items as TItem[];
        let text = ""; let lastY: number | null = null;
        for (const it of items) {
          const y = Math.round(it.transform[5]);
          if (lastY !== null && Math.abs(y - lastY) > 4) text += "\n";
          text += it.str;
          if (it.hasEOL) text += "\n";
          lastY = y;
        }
        const lines = text.trim().split("\n").map(l => l.trim()).filter(Boolean);
        const title = lines[0] || `لاپەر ${i}`;
        const body = lines.slice(1).join("\n");
        pageTexts.push({ title, body });
      }

      // 2. Build PPTX
      setProgress("د دروستکرنا سلایدان...");
      const PptxGenJS = (await import("pptxgenjs")).default;
      const prs = new PptxGenJS();
      prs.layout = "LAYOUT_16x9";
      prs.title = file.name.replace(/\.pdf$/i, "");

      pageTexts.forEach(({ title, body }, idx) => {
        const slide = prs.addSlide();
        // Background
        slide.background = { color: "FFFFFF" };
        // Slide number badge
        slide.addText(`${idx + 1}`, {
          x: 8.8, y: 0.1, w: 0.6, h: 0.35,
          fontSize: 10, color: "AAAAAA", align: "center",
        });
        // Title
        slide.addText(title, {
          x: 0.4, y: 0.3, w: 8.8, h: 0.9,
          fontSize: 20, bold: true, color: "1a1a2e",
          align: "left", valign: "top",
          wrap: true,
        });
        // Divider
        slide.addShape(prs.ShapeType.line, {
          x: 0.4, y: 1.3, w: 8.8, h: 0,
          line: { color: "6C63FF", width: 2 },
        });
        // Body text
        if (body.trim()) {
          slide.addText(body, {
            x: 0.4, y: 1.5, w: 8.8, h: 4.5,
            fontSize: 12, color: "333333",
            align: "left", valign: "top",
            wrap: true,
          });
        }
      });

      setProgress("د ئامادەکرنا دانلودێدا...");
      const blob = await prs.write({ outputType: "blob" }) as Blob;
      const url = URL.createObjectURL(blob);
      setResult({ url, name: file.name.replace(/\.pdf$/i, "") + ".pptx", slides: totalPages });
    } catch (e) {
      console.error(e);
      setError("کێشەیەکێ هاتە دی د گۆڕینا PDFێدا.");
    } finally { setLoading(false); setProgress(""); }
  };

  const reset = () => { if (result?.url) URL.revokeObjectURL(result.url); setFile(null); setResult(null); setError(null); };

  return (
    <div className="rounded-2xl bg-card border border-border p-6 md:p-8" style={{ boxShadow: "var(--shadow-elegant)" }}>
      <div className="mb-6 text-right">
        <div className="flex items-center justify-end gap-3 mb-1">
          <h3 className="text-xl font-extrabold">گۆڕینا PDF بو PowerPoint</h3>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-primary-foreground shrink-0" style={{ background: "var(--gradient-primary)" }}>
            <Presentation className="w-5 h-5" />
          </div>
        </div>
        <p className="text-sm text-muted-foreground">فایلێ PDF بدانە — هەر لاپەرێ دبێت سلایدێک و دانلود دکەی.</p>
      </div>

      {!file ? (
        <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} onClick={() => fileInputRef.current?.click()}
          className={`relative w-full rounded-2xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center gap-3 py-10 px-4 mb-6 ${dropActive ? "border-primary bg-primary/5 scale-[1.01]" : "border-border hover:border-primary/60 hover:bg-secondary/40"}`}>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-primary-foreground" style={{ background: "var(--gradient-primary)" }}><Upload className="w-6 h-6" /></div>
          <div className="text-center">
            <p className="font-bold text-sm mb-0.5">فایلا PDFێ خۆ بار بکە</p>
            <p className="text-xs text-muted-foreground">کلیک بکە یان drag &amp; drop بکە</p>
          </div>
          <input ref={fileInputRef} type="file" accept="application/pdf,.pdf" onChange={(e) => pickFile(e.target.files?.[0] || null)} className="hidden" />
        </div>
      ) : (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-border bg-secondary/40 px-4 py-3">
          <FileText className="w-5 h-5 text-primary shrink-0" />
          <div className="flex-1 min-w-0 text-right">
            <p className="text-sm font-semibold truncate">{file.name}</p>
            <p className="text-xs text-muted-foreground">{formatBytes(file.size)}</p>
          </div>
          <button type="button" onClick={reset} className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition shrink-0"><X className="w-4 h-4" /></button>
        </div>
      )}

      {error && <div className="rounded-xl bg-destructive/10 text-destructive text-sm p-3 mb-4 text-right">{error}</div>}
      {loading && (
        <div className="rounded-xl bg-primary/5 border border-primary/20 p-4 mb-4 text-right">
          <div className="flex items-center justify-end gap-2"><span className="text-sm font-semibold text-primary">{progress}</span><Loader2 className="w-4 h-4 animate-spin text-primary shrink-0" /></div>
          <p className="text-xs text-muted-foreground mt-1">تکایە چاوەڕێ بکە.</p>
        </div>
      )}

      {result && (
        <div className="rounded-xl border border-border bg-background p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-muted-foreground">ئەنجام</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-success/15 text-success">ئامادەیە ✓</span>
          </div>
          <div className="rounded-lg bg-secondary/40 p-3 mb-4 text-right">
            <p className="text-xs text-muted-foreground mb-0.5">ژمارەیا سلایدان</p>
            <p className="text-sm font-bold">{result.slides} سلاید</p>
          </div>
          <a href={result.url} download={result.name} className="flex items-center justify-center gap-2 w-full rounded-xl bg-primary text-primary-foreground px-5 py-2.5 text-sm font-bold hover:opacity-90 transition" style={{ boxShadow: "var(--shadow-glow)" }}>
            <Download className="w-4 h-4" /> دانلودکرنا فایلا PPTX
          </a>
          <p className="text-center text-[10px] text-muted-foreground mt-2">{result.name}</p>
        </div>
      )}

      {!result && !loading && (
        <div className="flex justify-end">
          <button type="button" onClick={convert} disabled={!file} className="inline-flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition" style={{ boxShadow: file ? "var(--shadow-glow)" : undefined }}>
            <Presentation className="w-4 h-4" /> بگۆڕە — PPTX دانلود بکە
          </button>
        </div>
      )}
      {result && <div className="flex justify-end mt-2"><button type="button" onClick={reset} className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2 transition">فایلێکی تر بار بکە</button></div>}
    </div>
  );
}
