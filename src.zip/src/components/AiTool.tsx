import { useState, useRef, useEffect } from "react";
import { Sparkles, Copy, Check, Loader2, Volume2, Square, Upload, X, Mic, Trash2, Play, Pause, FileText } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { DesmosGraph } from "./DesmosGraph";

type ToolKey =
  | "planner"
  | "solver"
  | "math2word"
  | "tts"
  | "grader"
  | "glossary"
  | "testai"
  | "testplagiarism"
  | "quiz_generator"
  | "grapher"
  | "grammar"
  | "translator"
  | "chat_doc"
  | "audio_sum"
  | "research_assistant"
  | "paper_summarizer"
  | "abstract_generator"
  | "lit_review"
  | "research_question"
  | "methodology_assistant"
  | "citation_generator"
  | "bibtex_generator"
  | "latex_word";

interface Props {
  tool: ToolKey;
  title: string;
  description: string;
  placeholder: string;
  buttonLabel: string;
  ltr?: boolean;
  withTTS?: boolean;
  withFile?: boolean;
  fileAccept?: string;
  showPercentage?: boolean;
}

function PercentageRing({ value }: { value: number }) {
  const pct = Math.max(0, Math.min(100, value));
  const r = 60;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  return (
    <div className="flex items-center justify-center my-4">
      <div className="relative w-40 h-40">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 140 140">
          <circle cx="70" cy="70" r={r} stroke="var(--muted)" strokeWidth="12" fill="none" />
          <circle
            cx="70"
            cy="70"
            r={r}
            stroke="hsl(0 84% 60%)"
            strokeWidth="12"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={offset}
            style={{ transition: "stroke-dashoffset 1s ease-out" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-extrabold" style={{ color: "var(--primary)" }}>
            {pct}%
          </span>
        </div>
      </div>
    </div>
  );
}

export function AiTool({
  tool,
  title,
  description,
  placeholder,
  buttonLabel,
  ltr,
  withTTS,
  withFile,
  fileAccept,
  showPercentage,
}: Props) {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [speechPaused, setSpeechPaused] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Audio sum specific states
  const [audioSource, setAudioSource] = useState<"text" | "audio">("audio");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  // Clean up recording timer and speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (typeof window !== "undefined" && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      let recorder: MediaRecorder;
      try {
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      } catch (e) {
        recorder = new MediaRecorder(stream); // fallback
      }

      mediaRecorderRef.current = recorder;
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: recorder.mimeType });
        setRecordedBlob(audioBlob);
        stream.getTracks().forEach((track) => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      setRecordingDuration(0);
      timerRef.current = window.setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Microphone access error:", err);
      setError("کێشەیەک د دەستڕاگەیشتن ب مایکڕۆفۆنێدا هەیە. تکایە ڕێپێدان بدە.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const fileToBase64 = (f: Blob) =>
    new Promise<string>((res, rej) => {
      const r = new FileReader();
      r.onload = () => {
        const s = r.result as string;
        res(s.split(",")[1] || "");
      };
      r.onerror = rej;
      r.readAsDataURL(f);
    });

  const run = async () => {
    const isAudioSum = tool === "audio_sum";
    const hasAudioPayload = !!(audioFile || recordedBlob);

    if (!isAudioSum && !input.trim() && !file) return;
    if (isAudioSum && audioSource === "text" && !input.trim() && !file) return;
    if (isAudioSum && audioSource === "audio" && !hasAudioPayload) return;

    setLoading(true);
    setError(null);
    setOutput("");
    try {
      const actualTool = (isAudioSum && audioSource === "text") ? "tts" : tool;
      const payload: Record<string, unknown> = { tool: actualTool };
      
      if (isAudioSum && audioSource === "audio") {
        if (audioFile) {
          payload.fileBase64 = await fileToBase64(audioFile);
          payload.mimeType = audioFile.type || "audio/mpeg";
        } else if (recordedBlob) {
          payload.fileBase64 = await fileToBase64(recordedBlob);
          payload.mimeType = recordedBlob.type || "audio/webm";
        }
      } else {
        payload.input = input;
        if (file) {
          payload.fileBase64 = await fileToBase64(file);
          payload.mimeType = file.type || "application/octet-stream";
        }
      }

      const r = await fetch("/api/tool", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "چەوتی");
      setOutput((data.output || "").replace(/\*\*/g, ""));
    } catch (e) {
      setError(e instanceof Error ? e.message : "چەوتی");
    } finally {
      setLoading(false);
    }
  };

  const copy = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const cleanTextForSpeech = (text: string) => {
    return text
      .replace(/[#*`~_]/g, "") // Strip markdown formatting characters
      .replace(/\[([^\]]+)\]\([^\)]+\)/g, "$1") // Strip markdown links, keep text
      .replace(/[-•*+]\s+/g, " ") // Clean bullet points
      .replace(/\s+/g, " ") // Collapse whitespace
      .trim();
  };

  const startSpeaking = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      setError("براوزەرێ تە پشتەڤانیا دەنگی ناکەت.");
      return;
    }
    const synth = window.speechSynthesis;
    
    synth.cancel();
    if (synth.paused) {
      synth.resume();
    }

    const doSpeak = () => {
      const speakableText = cleanTextForSpeech(output);
      if (!speakableText) {
        setError("دەقەکێ گونجاو نینە بۆ خوێندنەوە.");
        return;
      }

      const u = new SpeechSynthesisUtterance(speakableText);
      utteranceRef.current = u;

      const voices = synth.getVoices();
      const v =
        voices.find((x) => /^(ku|ckb)/i.test(x.lang)) ||
        voices.find((x) => /^ar/i.test(x.lang)) ||
        voices.find((x) => /^fa/i.test(x.lang)) ||
        voices.find((x) => /^en/i.test(x.lang)) ||
        voices[0];
      if (v) {
        u.voice = v;
        u.lang = v.lang;
      } else {
        u.lang = "ar-SA";
      }
      u.rate = 0.95;
      u.onend = () => {
        setSpeaking(false);
        setSpeechPaused(false);
        utteranceRef.current = null;
      };
      u.onerror = (e) => {
        console.error("SpeechSynthesis error:", e);
        setSpeaking(false);
        setSpeechPaused(false);
        utteranceRef.current = null;
      };
      setSpeaking(true);
      setSpeechPaused(false);
      synth.resume();
      synth.speak(u);
    };

    if (synth.getVoices().length === 0) {
      synth.onvoiceschanged = () => {
        synth.onvoiceschanged = null;
        doSpeak();
      };
      setTimeout(() => {
        if (!speaking) doSpeak();
      }, 300);
    } else {
      doSpeak();
    }
  };

  const togglePauseSpeaking = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const synth = window.speechSynthesis;
    if (speechPaused) {
      synth.resume();
      setSpeechPaused(false);
    } else {
      synth.pause();
      setSpeechPaused(true);
    }
  };

  const stopSpeaking = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const synth = window.speechSynthesis;
    synth.cancel();
    setSpeaking(false);
    setSpeechPaused(false);
    utteranceRef.current = null;
  };

  const percentMatch = showPercentage ? output.match(/(\d{1,3})\s*%/) : null;
  const percentValue = percentMatch ? parseInt(percentMatch[1], 10) : null;

  const isAudioSum = tool === "audio_sum";

  return (
    <div
      className="rounded-2xl bg-card border border-border p-6 md:p-8"
      style={{ boxShadow: "var(--shadow-elegant)" }}
    >
      <div className="mb-4 text-right">
        <h3 className="text-xl font-extrabold mb-1">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>

      {isAudioSum && (
        <div className="flex justify-end gap-2 mb-6 border-b border-border pb-4">
          <button
            type="button"
            onClick={() => setAudioSource("text")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              audioSource === "text"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            کورتەیا دەنگی
          </button>
          <button
            type="button"
            onClick={() => setAudioSource("audio")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              audioSource === "audio"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            تۆمارکرن و بارکرنا دەنگی
          </button>
        </div>
      )}

      {(!isAudioSum || audioSource === "text") && (
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          dir={ltr ? "ltr" : "auto"}
          placeholder={placeholder}
          className="w-full min-h-[140px] rounded-xl border border-border bg-background p-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-y"
        />
      )}

      {isAudioSum && audioSource === "audio" && (
        <div className="flex flex-col items-center justify-center p-6 border border-border bg-secondary/20 rounded-2xl min-h-[180px] text-center">
          <input
            ref={audioInputRef}
            type="file"
            accept="audio/*"
            onChange={(e) => {
              setAudioFile(e.target.files?.[0] || null);
              setRecordedBlob(null);
            }}
            className="hidden"
          />

          {isRecording ? (
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-destructive animate-pulse" />
                <span className="text-sm font-bold text-destructive">د تۆمارکرنێدا...</span>
              </div>
              <div className="text-4xl font-mono font-bold tracking-wider text-foreground">
                {formatDuration(recordingDuration)}
              </div>
              <button
                type="button"
                onClick={stopRecording}
                className="w-14 h-14 rounded-full bg-destructive text-destructive-foreground hover:scale-105 active:scale-95 transition flex items-center justify-center shadow-lg"
              >
                <Square className="w-6 h-6 fill-current" />
              </button>
            </div>
          ) : recordedBlob ? (
            <div className="flex flex-col items-center gap-4 w-full">
              <span className="text-xs font-semibold text-muted-foreground">تۆمارکرن ب سەرکەفتن هاتە ئەنجامدان</span>
              <audio
                src={URL.createObjectURL(recordedBlob)}
                controls
                className="w-full max-w-md h-10 mt-1"
              />
              <button
                type="button"
                onClick={() => setRecordedBlob(null)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold border border-border bg-background hover:bg-secondary text-muted-foreground hover:text-foreground transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                ڕەشکرنەوە و تۆمارکرنا نوو
              </button>
            </div>
          ) : audioFile ? (
            <div className="flex flex-col items-center gap-4 w-full">
              <div className="flex items-center justify-between w-full max-w-md rounded-xl bg-background px-4 py-3 border border-border text-sm">
                <button
                  type="button"
                  onClick={() => setAudioFile(null)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <X className="w-4 h-4" />
                </button>
                <span className="truncate text-right font-medium">{audioFile.name}</span>
              </div>
              <audio
                src={URL.createObjectURL(audioFile)}
                controls
                className="w-full max-w-md h-10 mt-1"
              />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-lg">
              <div className="flex flex-col items-center gap-3 p-4 bg-card/50 rounded-xl border border-border">
                <span className="text-sm font-semibold text-muted-foreground">تۆمارکرنا دەنگی</span>
                <button
                  type="button"
                  onClick={startRecording}
                  className="w-14 h-14 rounded-full bg-primary text-primary-foreground hover:scale-105 active:scale-95 transition flex items-center justify-center shadow-lg animate-pulse-ring"
                >
                  <Mic className="w-6 h-6" />
                </button>
                <span className="text-xs text-muted-foreground">کلیک بکە بۆ دەستپێکردن</span>
              </div>

              <div className="flex flex-col items-center gap-3 p-4 bg-card/50 rounded-xl border border-border">
                <span className="text-sm font-semibold text-muted-foreground">بارکرنا فایلی</span>
                <button
                  type="button"
                  onClick={() => audioInputRef.current?.click()}
                  className="w-14 h-14 rounded-full bg-secondary text-foreground border border-border hover:border-primary hover:bg-primary/5 hover:scale-105 active:scale-95 transition flex items-center justify-center shadow-md"
                >
                  <Upload className="w-6 h-6 text-primary" />
                </button>
                <span className="text-xs text-muted-foreground">باربکە (MP3, WAV, M4A, WEBM)</span>
              </div>
            </div>
          )}
        </div>
      )}

      {withFile && (!isAudioSum || audioSource === "text") && (
        <div className="mt-3">
          <input
            ref={fileInputRef}
            type="file"
            accept={fileAccept || "image/*,application/pdf"}
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="hidden"
          />
          {!file ? (
            <button
              onClick={() => fileInputRef.current?.click()}
              type="button"
              className="w-full rounded-xl border-2 border-dashed border-border hover:border-primary/60 p-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition"
            >
              <Upload className="w-4 h-4" />
              فایل/وێنە بدانە (PDF, Word, PowerPoint, وێنە)
            </button>
          ) : (
            <div className="flex items-center justify-between rounded-xl bg-secondary px-4 py-3 text-sm">
              <button
                onClick={() => setFile(null)}
                type="button"
                className="text-muted-foreground hover:text-destructive"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="truncate text-right">{file.name}</span>
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between mt-3 mb-4">
        {(!isAudioSum || audioSource === "text") ? (
          <span className="text-xs text-muted-foreground">{input.length} / 10000</span>
        ) : (
          <div />
        )}
        <button
          onClick={run}
          disabled={
            loading ||
            (!isAudioSum && !input.trim() && !file) ||
            (isAudioSum && audioSource === "text" && !input.trim() && !file) ||
            (isAudioSum && audioSource === "audio" && !recordedBlob && !audioFile)
          }
          className="inline-flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-5 py-2.5 text-sm font-semibold hover:opacity-90 disabled:opacity-50"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          {loading ? "د پڕۆسێسکرنێدا..." : buttonLabel}
        </button>
      </div>

      {error && (
        <div className="rounded-xl bg-destructive/10 text-destructive text-sm p-3 mb-3 text-right">
          {error}
        </div>
      )}

      {output && (
        <div className="rounded-xl border border-border bg-background p-4">
          <div className="flex items-center justify-between mb-2 gap-2 flex-wrap">
            <div className="flex items-center gap-3">
              <button
                onClick={copy}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? "هاتە کۆپیکرن" : "کۆپی"}
              </button>
              {(withTTS || (isAudioSum && audioSource === "text")) && (
                <div className="flex items-center gap-2">
                  {!speaking ? (
                    <button
                      onClick={startSpeaking}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:opacity-80"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      گوهداری بکە
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={togglePauseSpeaking}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:opacity-80"
                      >
                        {speechPaused ? (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            دەستپێکرنەوە
                          </>
                        ) : (
                          <>
                            <Pause className="w-3.5 h-3.5" />
                            ڕاوەستاندن
                          </>
                        )}
                      </button>
                      <button
                        onClick={stopSpeaking}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-destructive hover:opacity-80"
                      >
                        <Square className="w-3.5 h-3.5" />
                        ڕاگرتن
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
            <span className="text-xs font-semibold text-muted-foreground">ئەنجام</span>
          </div>
          {showPercentage && percentValue !== null && <PercentageRing value={percentValue} />}
          
          {tool === "grapher" ? (() => {
            let graphData: { x: number; y: number }[] = [];
            let graphEquation = "";
            let graphDomain = "";
            let graphRange = "";
            let graphYIntercept = "";
            let graphXIntercepts = "";
            let graphFeatures: string[] = [];
            let graphExplanation = "";
            let graphParseError = false;
            try {
              let jsonStr = output.trim();
              if (jsonStr.includes("```")) {
                const matches = jsonStr.match(/```(?:json)?([\s\S]*?)```/);
                if (matches && matches[1]) {
                  jsonStr = matches[1].trim();
                }
              }
              const parsed = JSON.parse(jsonStr);
              if (Array.isArray(parsed.points)) {
                graphData = parsed.points.map((p: any) => ({
                  x: Number(p.x),
                  y: Number(p.y),
                }));
                graphEquation = parsed.equation || "";
                graphDomain = parsed.domain || "";
                graphRange = parsed.range || "";
                graphYIntercept = parsed.y_intercept || "";
                graphXIntercepts = parsed.x_intercepts || "";
                graphFeatures = Array.isArray(parsed.features) ? parsed.features : [];
                graphExplanation = parsed.explanation || "";
              } else {
                graphParseError = true;
              }
            } catch (e) {
              console.error("Failed to parse graph JSON:", e);
              graphParseError = true;
            }

            if (graphParseError) {
              return <p className="whitespace-pre-wrap text-sm leading-relaxed text-right">{output}</p>;
            }

            return (
              <div className="mt-3 space-y-4">
                {/* Desmos Interactive Graph */}
                <div className="w-full bg-card/60 p-4 rounded-2xl border border-border shadow-inner relative overflow-hidden backdrop-blur-md">
                  <DesmosGraph equation={graphEquation} points={graphData} />
                </div>

                {/* Academic Information Card */}
                {(graphEquation || graphDomain || graphRange || graphYIntercept || graphXIntercepts || graphFeatures.length > 0 || graphExplanation) && (
                  <div className="bg-card border border-border rounded-2xl p-5 text-right space-y-4" style={{ boxShadow: "var(--shadow-elegant)" }}>
                    <div className="border-b border-border pb-3 flex items-center justify-between flex-row-reverse">
                      <h4 className="text-sm font-extrabold text-foreground flex items-center gap-2 flex-row-reverse">
                        <span className="w-2.5 h-2.5 rounded-full bg-primary" />
                        پێزانینێن ئەکادیمی یێن نەخشەی (Academic Analysis)
                      </h4>
                      {graphEquation && (
                        <span className="font-mono text-xs px-3 py-1 bg-primary/10 text-primary font-bold rounded-lg dir-ltr">
                          {graphEquation}
                        </span>
                      )}
                    </div>

                    {/* Quick Stats Grid */}
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      {graphDomain && (
                        <div className="bg-secondary/40 p-3 rounded-xl border border-border/50">
                          <p className="text-muted-foreground text-[10px] mb-1">بوار (Domain)</p>
                          <p className="font-bold text-foreground dir-ltr inline-block">{graphDomain}</p>
                        </div>
                      )}
                      {graphRange && (
                        <div className="bg-secondary/40 p-3 rounded-xl border border-border/50">
                          <p className="text-muted-foreground text-[10px] mb-1">مەودا (Range)</p>
                          <p className="font-bold text-foreground dir-ltr inline-block">{graphRange}</p>
                        </div>
                      )}
                      {graphYIntercept && (
                        <div className="bg-secondary/40 p-3 rounded-xl border border-border/50">
                          <p className="text-muted-foreground text-[10px] mb-1">خالا بڕینا تەوەرێ Y</p>
                          <p className="font-bold text-foreground dir-ltr inline-block">{graphYIntercept}</p>
                        </div>
                      )}
                      {graphXIntercepts && (
                        <div className="bg-secondary/40 p-3 rounded-xl border border-border/50">
                          <p className="text-muted-foreground text-[10px] mb-1">خالێن بڕینا تەوەرێ X</p>
                          <p className="font-bold text-foreground dir-ltr inline-block">{graphXIntercepts}</p>
                        </div>
                      )}
                    </div>

                    {/* Key Features List */}
                    {graphFeatures.length > 0 && (
                      <div className="space-y-2 pt-1">
                        <p className="text-[10px] font-bold text-muted-foreground">تایبەتمەندیێن سەرەکی یێن نەخشەی:</p>
                        <ul className="space-y-1.5 pr-1">
                          {graphFeatures.map((feat, i) => (
                            <li key={i} className="text-xs text-foreground/90 flex items-start justify-start gap-2 pr-1">
                              <span className="text-primary mt-1 select-none text-[10px]">•</span>
                              <span className="text-right leading-relaxed">{feat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Academic Explanation */}
                    {graphExplanation && (
                      <div className="bg-secondary/20 p-3 rounded-xl border border-border/60">
                        <p className="text-[10px] font-bold text-muted-foreground mb-1">ڕوونکرنا زانستی:</p>
                        <p className="text-xs leading-relaxed text-foreground/80">{graphExplanation}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })() : (
            <div className="text-sm leading-relaxed text-right [&>p]:mb-3 [&>ul]:list-disc [&>ul]:pr-5 [&>ul]:my-2 [&>ol]:list-decimal [&>ol]:pr-5 [&>ol]:my-2 [&>table]:w-full [&>table]:my-4 [&>table]:border-collapse [&>table]:border [&>table]:border-border [&>table_th]:border [&>table_th]:border-border [&>table_th]:p-2 [&>table_th]:bg-secondary/60 [&>table_td]:border [&>table_td]:border-border [&>table_td]:p-2">
              <ReactMarkdown>{output}</ReactMarkdown>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
