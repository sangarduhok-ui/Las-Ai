import { useCallback, useEffect, useRef, useState } from "react";
import {
  Upload,
  FileText,
  X,
  Sparkles,
  Copy,
  Check,
  AlertCircle,
  Loader2,
  Brain,
  RotateCcw,
  MessageCircle,
  Send,
} from "lucide-react";

type Summary = {
  title?: string;
  language_detected?: string;
  main_points?: string[];
  definitions?: { term: string; definition: string }[];
  dates_formulas?: string[];
};

type QuizQuestion = {
  question: string;
  options: string[];
  answer_index: number;
  explanation?: string;
};

type Quiz = {
  title?: string;
  questions: QuizQuestion[];
};

const MAX_BYTES = 25 * 1024 * 1024;

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const s = String(r.result);
      const i = s.indexOf(",");
      resolve(i >= 0 ? s.slice(i + 1) : s);
    };
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}

function getMimeType(file: File): string {
  if (file.type && file.type !== "application/octet-stream") {
    return file.type;
  }
  const ext = file.name.split(".").pop()?.toLowerCase();
  switch (ext) {
    case "pdf": return "application/pdf";
    case "doc": return "application/msword";
    case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    case "xls": return "application/vnd.ms-excel";
    case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    case "ppt": return "application/vnd.ms-powerpoint";
    case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    case "png": return "image/png";
    case "jpg":
    case "jpeg": return "image/jpeg";
    case "webp": return "image/webp";
    default: return file.type || "application/octet-stream";
  }
}

export function Uploader() {
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [quizLoading, setQuizLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const quizRef = useRef<HTMLDivElement>(null);

  // Chat with File states
  const [chatActive, setChatActive] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([]);
  const [chatInput, setChatInput] = useState("");
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatActive && chatMessages.length === 0) {
      setChatMessages([
        {
          role: "assistant",
          content: "سلاڤ! ئەڤە دەقێ فایلا تە هاتیە خاندن. هەر پرسیارەکا تە هەبیت لسەر ناوەڕۆکێ فایلی، بپرسە.",
        },
      ]);
    }
  }, [chatActive, chatMessages.length]);

  useEffect(() => {
    chatScrollRef.current?.scrollTo({ top: chatScrollRef.current.scrollHeight, behavior: "smooth" });
  }, [chatMessages, chatLoading]);

  const handleFile = (f: File | null) => {
    setError(null);
    setSummary(null);
    setQuiz(null);
    setChatActive(false);
    setChatMessages([]);
    setChatInput("");
    setAnswers({});
    setSubmitted(false);
    if (!f) return;
    if (f.size > MAX_BYTES) {
      setError("قەبارا فایلێ پر یە. پترین قەبارە ٢٥ مێگابایتە.");
      return;
    }
    const mime = getMimeType(f);
    const isImage = mime.startsWith("image/");
    const isPdf = mime === "application/pdf";
    const isOffice = [
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-powerpoint",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    ].includes(mime) || 
    /\.(docx?|xlsx?|pptx?)$/i.test(f.name);

    if (!isImage && !isPdf && !isOffice) {
      setError("تنێ PDF، وێنە یان فایلێن ئۆفیس قبوول دبن.");
      return;
    }
    setFile(f);
  };


  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files?.[0] ?? null);
  }, []);

  const summarize = async () => {
    if (!file) return;
    setChatActive(false);
    setLoading(true);
    setError(null);
    setSummary(null);
    try {
      const b64 = await fileToBase64(file);
      const res = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileBase64: b64, mimeType: getMimeType(file), fileName: file.name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "چەوتی د سەرڤیسێدا");
      setSummary(data.summary as Summary);
    } catch (e) {
      setError(e instanceof Error ? e.message : "چەوتیەک ڕویدا");
    } finally {
      setLoading(false);
    }
  };

  const generateQuiz = async () => {
    if (!file) return;
    setChatActive(false);
    setQuizLoading(true);
    setError(null);
    setQuiz(null);
    setAnswers({});
    setSubmitted(false);
    try {
      const b64 = await fileToBase64(file);
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileBase64: b64, mimeType: getMimeType(file), fileName: file.name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "چەوتی د سەرڤیسێدا");
      setQuiz(data.quiz as Quiz);
      setTimeout(
        () => quizRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
        100,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "چەوتیەک ڕویدا");
    } finally {
      setQuizLoading(false);
    }
  };

  const sendChatMessage = async () => {
    const text = chatInput.trim();
    if (!text || chatLoading || !file) return;
    setError(null);
    const next: Array<{ role: "user" | "assistant"; content: string }> = [
      ...chatMessages,
      { role: "user", content: text },
    ];
    setChatMessages(next);
    setChatInput("");
    setChatLoading(true);

    try {
      const b64 = await fileToBase64(file);
      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next,
          fileBase64: b64,
          mimeType: getMimeType(file),
          fileName: file.name,
        }),
      });

      if (!resp.ok || !resp.body) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j?.error || "چەوتی د پەیوەندیکرنێدا");
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let acc = "";
      setChatMessages((m) => [...m, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let nl: number;
        while ((nl = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, nl);
          buffer = buffer.slice(nl + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;
          try {
            const parsed = JSON.parse(jsonStr);
            const delta = parsed?.choices?.[0]?.delta?.content;
            if (delta) {
              acc += delta;
              setChatMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = { role: "assistant", content: acc };
                return copy;
              });
            }
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "چەوتی");
    } finally {
      setChatLoading(false);
    }
  };


  const fileRef = useRef(file);
  const busyRef = useRef(false);
  useEffect(() => {
    fileRef.current = file;
    busyRef.current = loading || quizLoading;
  }, [file, loading, quizLoading]);

  useEffect(() => {
    const hSum = () => {
      if (fileRef.current && !busyRef.current) summarize();
    };
    const hQuiz = () => {
      if (fileRef.current && !busyRef.current) generateQuiz();
    };
    window.addEventListener("trigger-summarize", hSum);
    window.addEventListener("trigger-quiz", hQuiz);
    return () => {
      window.removeEventListener("trigger-summarize", hSum);
      window.removeEventListener("trigger-quiz", hQuiz);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const summaryText = summary
    ? [
        summary.title ? `📘 ${summary.title}` : "",
        "",
        "🔹 خالێن سەرەکی:",
        ...(summary.main_points ?? []).map((p, i) => `${i + 1}. ${p}`),
        "",
        "📖 پێناسێن گرنگ:",
        ...(summary.definitions ?? []).map((d) => `• ${d.term}: ${d.definition}`),
        "",
        "📅 دەم و فۆرمول:",
        ...(summary.dates_formulas ?? []).map((d) => `• ${d}`),
      ].join("\n")
    : "";

  const copy = async () => {
    await navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const score = quiz
    ? quiz.questions.reduce((acc, q, i) => acc + (answers[i] === q.answer_index ? 1 : 0), 0)
    : 0;

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={`relative cursor-pointer rounded-3xl border-2 border-dashed p-10 md:p-14 text-center transition-all bg-card ${
          dragOver
            ? "border-primary bg-accent/30 scale-[1.01]"
            : "border-border hover:border-primary/60 hover:bg-accent/10"
        }`}
        style={{ boxShadow: "var(--shadow-elegant)" }}
      >
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf,image/*,.doc,.docx,.xls,.xlsx,.ppt,.pptx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
        />
        <div className="flex flex-col items-center gap-4">
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center text-primary-foreground animate-float"
            style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
          >
            <Upload className="w-9 h-9" />
          </div>
          {file ? (
            <div className="flex items-center gap-3 bg-secondary px-4 py-2 rounded-full">
              <FileText className="w-5 h-5 text-primary" />
              <span className="font-medium text-sm">{file.name}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFile(null);
                  setSummary(null);
                  setQuiz(null);
                }}
                className="text-muted-foreground hover:text-destructive"
                aria-label="ژێبرن"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <>
              <h3 className="text-xl md:text-2xl font-bold">فایلا خۆ ڕاکێشە یان کلیک بکە</h3>
              <p className="text-muted-foreground text-sm">
                پشتەڤانیا وێنە و PDF و فایلان دکەت • پترین قەبارە ٢٥ مێگابایت
              </p>
            </>
          )}
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={summarize}
          disabled={!file || loading || quizLoading || chatLoading}
          className="relative overflow-hidden rounded-xl px-4 py-3 text-sm font-bold text-primary-foreground transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.01]"
          style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
        >
          <span className="flex items-center justify-center gap-3">
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>د کورتکرنێدا...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>کورت بکە</span>
              </>
            )}
          </span>
          {loading && <span className="absolute inset-0 shimmer pointer-events-none" />}
        </button>

        <button
          onClick={generateQuiz}
          disabled={!file || loading || quizLoading || chatLoading}
          className="relative overflow-hidden rounded-xl px-4 py-3 text-sm font-bold border-2 border-primary text-primary bg-background transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/5 hover:scale-[1.01]"
        >
          <span className="flex items-center justify-center gap-3">
            {quizLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>د تاقیکرنێدا...</span>
              </>
            ) : (
              <>
                <Brain className="w-4 h-4" />
                <span>تاقیکرنێ دروست بکە</span>
              </>
            )}
          </span>
        </button>

        <button
          onClick={() => {
            setChatActive(true);
            setSummary(null);
            setQuiz(null);
            setTimeout(() => {
              chatRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
            }, 100);
          }}
          disabled={!file || loading || quizLoading || chatLoading}
          className={`relative overflow-hidden rounded-xl px-4 py-3 text-sm font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.01] flex items-center justify-center ${
            chatActive
              ? "bg-primary text-primary-foreground shadow-lg"
              : "border-2 border-primary text-primary bg-background hover:bg-primary/5"
          }`}
        >
          <span className="flex items-center justify-center gap-3">
            {chatLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>د چاتکرنێدا...</span>
              </>
            ) : (
              <>
                <MessageCircle className="w-4 h-4" />
                <span>چات دگەل فایلی</span>
              </>
            )}
          </span>
        </button>
      </div>


      {(loading || quizLoading) && (
        <div className="mt-8 flex flex-col items-center gap-4 py-8">
          <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center animate-pulse-ring">
            <Sparkles className="w-7 h-7 text-primary" />
          </div>
          <p className="text-muted-foreground">
            {quizLoading ? "پرسیار تێنە ئامادەکرن..." : "پەڕە تێنە خواندن و کورتە ئامادە دبیت..."}
          </p>
        </div>
      )}

      {error && (
        <div className="mt-6 flex items-start gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-5">
          <AlertCircle className="w-6 h-6 text-destructive shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-destructive">چەوتی</p>
            <p className="text-sm text-foreground/80 mt-1">{error}</p>
          </div>
        </div>
      )}

      {quiz && !quizLoading && (
        <article
          ref={quizRef}
          className="mt-8 rounded-3xl p-6 md:p-8 border border-border"
          style={{ background: "var(--gradient-card)", boxShadow: "var(--shadow-elegant)" }}
        >
          <header className="flex items-start justify-between gap-4 mb-6 pb-4 border-b border-border">
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-primary-foreground"
                style={{ background: "var(--gradient-primary)" }}
              >
                <Brain className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-extrabold text-foreground">
                  {quiz.title ?? "تاقیکرن"}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">{quiz.questions.length} پرسیار</p>
              </div>
            </div>
            {submitted && (
              <div className="text-center shrink-0">
                <div className="text-3xl font-extrabold text-primary">
                  {score}/{quiz.questions.length}
                </div>
                <div className="text-xs text-muted-foreground">نمرە</div>
              </div>
            )}
          </header>

          <div className="space-y-6">
            {quiz.questions.map((q, qi) => {
              const userAns = answers[qi];
              return (
                <div key={qi} className="rounded-2xl bg-card/60 p-5 border border-border">
                  <div className="flex gap-3 mb-4">
                    <span className="shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center text-sm">
                      {qi + 1}
                    </span>
                    <h3 className="font-bold text-base md:text-lg leading-relaxed">{q.question}</h3>
                  </div>
                  <div className="grid gap-2">
                    {q.options.map((opt, oi) => {
                      const selected = userAns === oi;
                      const isCorrect = oi === q.answer_index;
                      let cls =
                        "border-border bg-background hover:border-primary/60 hover:bg-accent/20";
                      if (submitted) {
                        if (isCorrect) cls = "border-success bg-success/10";
                        else if (selected && !isCorrect)
                          cls = "border-destructive bg-destructive/10";
                        else cls = "border-border bg-background opacity-70";
                      } else if (selected) {
                        cls = "border-primary bg-primary/10";
                      }
                      return (
                        <button
                          key={oi}
                          disabled={submitted}
                          onClick={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                          className={`text-right rounded-xl border-2 px-4 py-3 transition-all flex items-center gap-3 ${cls} disabled:cursor-default`}
                        >
                          <span className="shrink-0 w-7 h-7 rounded-full border-2 border-current font-bold flex items-center justify-center text-xs">
                            {["أ", "ب", "ج", "د"][oi] ?? oi + 1}
                          </span>
                          <span className="flex-1 text-sm md:text-base">{opt}</span>
                          {submitted && isCorrect && <Check className="w-5 h-5 text-success" />}
                          {submitted && selected && !isCorrect && (
                            <X className="w-5 h-5 text-destructive" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                  {submitted && q.explanation && (
                    <div className="mt-3 text-sm rounded-xl bg-accent/30 p-3 leading-relaxed">
                      <span className="font-bold">💡 ڕوونکرن: </span>
                      {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-6 flex flex-wrap gap-3 justify-end">
            {!submitted ? (
              <button
                onClick={() => setSubmitted(true)}
                disabled={Object.keys(answers).length < quiz.questions.length}
                className="rounded-xl bg-primary text-primary-foreground px-6 py-3 font-bold hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                پێشکێشکرنا بەرسڤان
              </button>
            ) : (
              <button
                onClick={() => {
                  setAnswers({});
                  setSubmitted(false);
                }}
                className="flex items-center gap-2 rounded-xl border-2 border-primary text-primary px-6 py-3 font-bold hover:bg-primary/5 transition"
              >
                <RotateCcw className="w-4 h-4" />
                دیسا تاقی بکە
              </button>
            )}
          </div>
        </article>
      )}

      {summary && !loading && (
        <article
          className="mt-8 rounded-3xl p-6 md:p-8 border border-border"
          style={{ background: "var(--gradient-card)", boxShadow: "var(--shadow-elegant)" }}
        >
          <header className="flex items-start justify-between gap-4 mb-6 pb-4 border-b border-border">
            <div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-foreground">
                {summary.title ?? "کورتەیا بەلگەنامێ"}
              </h2>
              <p className="text-sm text-muted-foreground mt-1">کورتەیەکا ئامادەکری بو خواندنێ</p>
            </div>
            <button
              onClick={copy}
              className="flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition shrink-0"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? "هاتە کۆپیکرن" : "کۆپی"}
            </button>
          </header>

          {!!summary.main_points?.length && (
            <section className="mb-6">
              <h3 className="text-lg font-bold mb-3 text-primary">🔹 خالێن سەرەکی</h3>
              <ul className="space-y-2">
                {summary.main_points.map((p, i) => (
                  <li key={i} className="flex gap-3 leading-relaxed">
                    <span className="font-bold text-primary shrink-0">{i + 1}.</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {!!summary.definitions?.length && (
            <section className="mb-6">
              <h3 className="text-lg font-bold mb-3 text-primary">📖 پێناسێن گرنگ</h3>
              <div className="grid gap-3">
                {summary.definitions.map((d, i) => (
                  <div key={i} className="rounded-xl bg-secondary/60 p-4">
                    <div className="font-bold text-foreground">{d.term}</div>
                    <div className="text-muted-foreground text-sm mt-1 leading-relaxed">
                      {d.definition}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {!!summary.dates_formulas?.length && (
            <section>
              <h3 className="text-lg font-bold mb-3 text-primary">📅 دەم و فۆرمول</h3>
              <ul className="space-y-2">
                {summary.dates_formulas.map((d, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="text-primary">•</span>
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </article>
      )}

      {chatActive && (
        <article
          ref={chatRef}
          className="mt-8 rounded-3xl p-6 md:p-8 border border-border flex flex-col"
          style={{ 
            background: "var(--gradient-card)", 
            boxShadow: "var(--shadow-elegant)",
            height: "min(70vh, 600px)"
          }}
        >
          <header className="flex items-center gap-3 mb-6 pb-4 border-b border-border">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center text-primary-foreground"
              style={{ background: "var(--gradient-primary)" }}
            >
              <MessageCircle className="w-6 h-6" />
            </div>
            <div className="text-right">
              <h2 className="text-2xl md:text-3xl font-extrabold text-foreground">
                چات دگەل فایلی
              </h2>
              <p className="text-sm text-muted-foreground mt-1">پرسیاران ژ ناوەڕۆکێ فایلی بکە</p>
            </div>
          </header>

          <div 
            ref={chatScrollRef} 
            className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 border border-border rounded-2xl bg-card/40 mb-4"
          >
            {chatMessages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-start" : "justify-end"}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm md:text-base leading-relaxed whitespace-pre-wrap text-right ${
                    m.role === "user"
                      ? "bg-primary text-primary-foreground rounded-bl-sm"
                      : "bg-secondary text-foreground rounded-br-sm"
                  }`}
                >
                  {m.content || (chatLoading && i === chatMessages.length - 1 ? "…" : "")}
                </div>
              </div>
            ))}
            {chatLoading && chatMessages[chatMessages.length - 1]?.role === "user" && (
              <div className="flex justify-end">
                <div className="bg-secondary rounded-2xl rounded-br-sm px-4 py-3">
                  <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                </div>
              </div>
            )}
          </div>

          <div className="flex items-end gap-2 bg-background/50 p-2 rounded-2xl border border-border">
            <textarea
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendChatMessage();
                }
              }}
              placeholder="پرسیارەکێ بنڤیسە..."
              rows={1}
              className="flex-1 resize-none rounded-xl border-0 bg-transparent px-4 py-3 text-sm md:text-base focus:outline-none max-h-32 text-right"
            />
            <button
              onClick={sendChatMessage}
              disabled={chatLoading || !chatInput.trim()}
              className="rounded-xl bg-primary text-primary-foreground w-12 h-12 flex items-center justify-center hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
            >
              {chatLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5 rotate-180" />
              )}
            </button>
          </div>
        </article>
      )}
    </div>
  );
}

