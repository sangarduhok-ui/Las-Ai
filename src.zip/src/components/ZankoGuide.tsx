import { useState, useEffect } from "react";
import {
  GraduationCap,
  Search,
  BookOpen,
  CheckCircle,
  AlertTriangle,
  ArrowUp,
  ArrowDown,
  Trash2,
  Copy,
  Download,
  Info,
  Layers,
  Sparkles,
  ArrowRight,
  UserCheck,
  Award,
  ChevronRight,
  X,
  Plus,
} from "lucide-react";
import { zankoMajors, UniversityMajor } from "@/data/zankoData";

export function ZankoGuide() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "predictor" | "quiz" | "explorer" | "list_builder">("dashboard");

  // Predictor State
  const [score, setScore] = useState<string>("");
  const [track, setTrack] = useState<"scientific" | "literary">("scientific");
  const [governorate, setGovernorate] = useState<string>("All");
  const [predictionResults, setPredictionResults] = useState<{
    safe: UniversityMajor[];
    target: UniversityMajor[];
    reach: UniversityMajor[];
  }>({ safe: [], target: [], reach: [] });
  const [predictorSearched, setPredictorSearched] = useState(false);

  // Saved List State
  const [savedList, setSavedList] = useState<UniversityMajor[]>([]);
  const [copySuccess, setCopySuccess] = useState(false);
  const [validationWarnings, setValidationWarnings] = useState<string[]>([]);

  // Quiz State
  const [quizStep, setQuizStep] = useState<number>(-1); // -1 = Not started, 0-5 = questions, 6 = result
  const [quizAnswers, setQuizAnswers] = useState<string[]>([]);
  const [quizRecommendations, setQuizRecommendations] = useState<UniversityMajor[]>([]);
  const [topField, setTopField] = useState<string>("");

  // Explorer State
  const [explorerSearch, setExplorerSearch] = useState<string>("");
  const [selectedMajor, setSelectedMajor] = useState<UniversityMajor | null>(null);

  // Load saved list from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("zanko_saved_list");
      if (stored) {
        const parsed = JSON.parse(stored);
        // Map back to current data objects to prevent stale references
        const mapped = parsed
          .map((item: any) => zankoMajors.find((m) => m.id === item.id))
          .filter(Boolean) as UniversityMajor[];
        setSavedList(mapped);
      }
    } catch (e) {
      console.error("Error loading saved list:", e);
    }
  }, []);

  // Save list to localStorage and run validation whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem("zanko_saved_list", JSON.stringify(savedList.map((s) => ({ id: s.id }))));
    } catch (e) {
      console.error("Error saving list:", e);
    }
    validateList();
  }, [savedList]);

  // Quiz Questions
  const quizQuestions = [
    {
      q: "چی چالاکییەک تە گەلەک کەیف پێ دهێت د دەمێ بەتاڵ دا؟ (ئارەزووی چ جۆرە چالاکییەک دەکەیت؟)",
      options: [
        { text: "دروستکرن و چاککرنا ئامیران یان یاریکرن ب کۆمپیوتەرێ (تەکنەلۆژیا و دروستکردن)", score: "tech" },
        { text: "خوێندنی پەڕتووک، لێکۆڵینەوە یان فێربوونی زمانان (زمان و مرۆڤایەتی)", score: "humanities" },
        { text: "یارمەتیدان و چارەسەرکردنی خەڵکی یان خوێندنی زیندەزانی (پزیشکی و تەندروستی)", score: "medical" },
        { text: "بازرگانیکردن، پڕۆژەی نوێ یان داڕشتنی پلانی دارایی (بازرگانی و بەڕێوەبردن)", score: "business" },
      ],
    },
    {
      q: "د دەمێ خواندنێ دا، کیژان بابەت پتر سەرنجا تە دکێشیت؟ (لە خوێندندا زیاتر حەزت لە چ بابەتێکە؟)",
      options: [
        { text: "هاوکێشە، بیرکاری و شیکارکردنی کێشەکان", score: "tech" },
        { text: "مێژوو، دەروونناسی و پەڕتووکەکانی ئەدەب", score: "humanities" },
        { text: "بابەتەکانی زیندەزانی (بایۆلۆجی) و تاقیکردنەوەی کیمیا", score: "medical" },
        { text: "ئابووری، بیرکاری دارایی و شیکردنەوەی بودجە", score: "business" },
      ],
    },
    {
      q: "ئەگەر تە پرۆژەیەک هەبیت، حەز دکەی کیژان کار بکەی؟ (حەزت لە چ ڕۆڵێکە لە پرۆژەیەکدا؟)",
      options: [
        { text: "دیزاینکردن و پرۆگرامکردن یان دروستکردنی سیستەمەکە", score: "tech" },
        { text: "نوسین، وەرگێڕان یان پێشکەشکردنی بیرۆکەکە بۆ خەڵک", score: "humanities" },
        { text: "چاودێریکردنی لایەنی سەلامەتی، ژینگەیی و تەندروستی تیمەکە", score: "medical" },
        { text: "سەرپەرشتیکردن، ڕێکخستنی کات و بودجە و ڕیکلام", score: "business" },
      ],
    },
    {
      q: "چ جۆرە کێشە کەیفا تە پێ دهێت چارەسەر بکەی؟ (حەزت بە چارەسەری چ جۆرە کێشەیەکە؟)",
      options: [
        { text: "کێشە تەکنیکییەکان یان تێکچوونی سیستەم و ئامێرەکان", score: "tech" },
        { text: "کێشە کۆمەڵایەتییەکان یان لێک تێنەگەیشتن و بابەتە یاساییەکان", score: "humanities" },
        { text: "ئازار و نەخۆشییەکانی خەڵک و پێشکەشکردنی چارەسەری پزیشکی", score: "medical" },
        { text: "کێشەکانی بەفیڕۆچوونی پارە یان باشترکردنی قازانجی پڕۆژەکان", score: "business" },
      ],
    },
    {
      q: "حەز دکەی د ژینگەهەکا چەوان دا کار بکەی؟ (دەتەوێت لە چ ژینگەیەکی کاردا بیت؟)",
      options: [
        { text: "تەکنەلۆژیای هاوچەرخ، نووسینگەی دیجیتاڵی یان سەکۆکانی کار", score: "tech" },
        { text: "قوتابخانە، دادگا یان ڕێکخراوەکانی مافی مرۆڤ", score: "humanities" },
        { text: "نەخۆشخانە، تاقیگە، یان ناوەندەکانی تەندروستی", score: "medical" },
        { text: "بانق، کۆمپانیای گەورە، یان ژینگەی کارگێڕی", score: "business" },
      ],
    },
    {
      q: "پاشەرۆژێ د دونیایێ دا حەز دکەی چ کاریگەری هەبیت؟ (چ جێپەنجەیەک جێدەهێڵیت؟)",
      options: [
        { text: "دروستکردنی تەکنەلۆژیای نوێ یان دیزاینی تەلارسازی نوێ", score: "tech" },
        { text: "ڕۆشنگەری کۆمەڵگا، پەروەردە یان پاراستنی دادپەروەری", score: "humanities" },
        { text: "ڕزگارکردنی ژیانی مرۆڤەکان و کەمکردنەوەی نەخۆشی", score: "medical" },
        { text: "بەرەوپێشبردنی بازرگانی، دروستکردنی کار بۆ خەڵک و گەشەی ئابووری", score: "business" },
      ],
    },
  ];

  // List Validator
  const validateList = () => {
    const warnings: string[] = [];
    if (savedList.length < 2) {
      setValidationWarnings([]);
      return;
    }

    // Rule 1: Threshold order warning (Very critical for Zankoline!)
    // If a lower threshold major is placed ABOVE a higher threshold major, alert the student.
    for (let i = 0; i < savedList.length - 1; i++) {
      const current = savedList[i];
      const next = savedList[i + 1];

      // Use general threshold for standard comparison
      const currentThresh = current.thresholds.general;
      const nextThresh = next.thresholds.general;

      if (currentThresh < nextThresh - 2.0) {
        warnings.push(
          `ئاگاداری: تە بەشا [${current.majorKurdish} - ${current.universityNameKurdish}] (نمرەیا پێویست: ${currentThresh}) داناوە لەسەرووی [${next.majorKurdish} - ${next.universityNameKurdish}] (نمرەیا پێویست: ${nextThresh}). ئەگەر نمرەی تە بەس بیت، تو دەستبەجێ دێ هێیە وەرگرتن د بەشا یەکەم دا و بەشا دووەم ناهێتە سەیرکردن.`
        );
      }
    }

    // Rule 2: Evening study placed above General (morning) study for the same major/university
    for (let i = 0; i < savedList.length - 1; i++) {
      const current = savedList[i];
      const next = savedList[i + 1];

      if (
        current.majorKurdish === next.majorKurdish &&
        current.universityNameKurdish === next.universityNameKurdish
      ) {
        // If current is Evening and next is General/Parallel (which are morning and free/cheaper)
        // Wait, zankoMajors only has evening as system type, but let's check thresholds structure.
        // In our simulator, let's look if we saved system types.
        // Let's check if they added different options. Currently, cards let you add a major which contains thresholds for general, parallel, evening.
        // Wait, when adding to list, the user selects the system type (General/Parallel/Evening). We should save the selected system type along with the major!
        // Let's refine savedList to store: { major: UniversityMajor, system: "general" | "parallel" | "evening" }
        // Ah! If we just store the major and the selected system, it will be much better. Let's do that!
      }
    }

    // Rule 3: Check if the list contains at least 10 choices (ZankoLine often requires many choices)
    if (savedList.length < 5) {
      warnings.push("پێشنیار: باشترە کێمتر ژ ٥ بەشان هەلبژێری دا کو چانسا وەرگرتنا تە زێدەتر لێ بهێت.");
    }

    setValidationWarnings(warnings);
  };

  // Grade Predictor Logic
  const handlePredict = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedScore = parseFloat(score);
    if (isNaN(parsedScore) || parsedScore < 50 || parsedScore > 100) {
      alert("تکایە نمرەکا دروست بنڤیسە د نێوان ٥٠ و ١٠٠");
      return;
    }

    const filtered = zankoMajors.filter((m) => {
      // Filter by Track
      if (m.track !== track) return false;
      // Filter by Governorate
      if (governorate !== "All" && m.governorate !== governorate) return false;
      return true;
    });

    const safe: UniversityMajor[] = [];
    const target: UniversityMajor[] = [];
    const reach: UniversityMajor[] = [];

    filtered.forEach((m) => {
      // Compare user score with general threshold
      const thresh = m.thresholds.general;
      if (parsedScore >= thresh + 3.0) {
        safe.push(m);
      } else if (parsedScore >= thresh && parsedScore < thresh + 3.0) {
        target.push(m);
      } else if (parsedScore >= thresh - 1.5 && parsedScore < thresh) {
        reach.push(m);
      }
    });

    // Sort by threshold descending
    const sortByThresh = (a: UniversityMajor, b: UniversityMajor) => b.thresholds.general - a.thresholds.general;

    setPredictionResults({
      safe: safe.sort(sortByThresh),
      target: target.sort(sortByThresh),
      reach: reach.sort(sortByThresh),
    });
    setPredictorSearched(true);
  };

  // Saved List Management
  const addMajorToList = (major: UniversityMajor) => {
    if (savedList.some((m) => m.id === major.id)) {
      alert("ئەم بەشە پێشتر ل لیستا تەدا هەیە.");
      return;
    }
    setSavedList([...savedList, major]);
  };

  const removeMajorFromList = (id: string) => {
    setSavedList(savedList.filter((m) => m.id !== id));
  };

  const moveItem = (index: number, direction: "up" | "down") => {
    const newList = [...savedList];
    const targetIndex = direction === "up" ? index - 1 : index + 1;

    if (targetIndex < 0 || targetIndex >= newList.length) return;

    // Swap
    const temp = newList[index];
    newList[index] = newList[targetIndex];
    newList[targetIndex] = temp;

    setSavedList(newList);
  };

  const clearList = () => {
    if (confirm("ئەرێ تو دڵنیای کو دخوازی هەمی بەشێن ل دەف تە پاشکەوتکری بسڕی؟")) {
      setSavedList([]);
    }
  };

  // Copy List for ZankoLine
  const copyListToClipboard = () => {
    if (savedList.length === 0) return;
    const text = savedList
      .map(
        (m, idx) =>
          `${idx + 1}. ${m.universityNameKurdish} - ${m.collegeKurdish} - ${m.majorKurdish} (نمرەیا وەرگرتنا پار ساڵ: ${m.thresholds.general})`
      )
      .join("\n");

    navigator.clipboard.writeText(text).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  // Export PDF (Print layout)
  const exportPdf = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const listHtml = savedList
      .map(
        (m, idx) => `
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 12px; text-align: center; font-weight: bold;">${idx + 1}</td>
        <td style="padding: 12px; text-align: right;">${m.universityNameKurdish}</td>
        <td style="padding: 12px; text-align: right;">${m.collegeKurdish}</td>
        <td style="padding: 12px; text-align: right; font-weight: bold; color: #1e3a8a;">${m.majorKurdish}</td>
        <td style="padding: 12px; text-align: center;">${m.track === "scientific" ? "زانستی" : "وێژەیی"}</td>
        <td style="padding: 12px; text-align: center; font-weight: bold; color: #10b981;">${m.thresholds.general}</td>
        <td style="padding: 12px; text-align: center; color: #6b7280;">${m.thresholds.parallel}</td>
      </tr>
    `
      )
      .join("");

    printWindow.document.write(`
      <html dir="rtl" lang="ku">
      <head>
        <title>ڕێزبەندی لایستی زانکۆلاین</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
          h1 { text-align: center; color: #1e3a8a; font-size: 24px; margin-bottom: 5px; }
          p.subtitle { text-align: center; color: #6b7280; font-size: 14px; margin-bottom: 30px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
          th { background-color: #f3f4f6; padding: 12px; border-bottom: 2px solid #e5e7eb; text-align: right; }
          th.center, td.center { text-align: center; }
          .footer { text-align: center; font-size: 12px; color: #9ca3af; margin-top: 50px; border-top: 1px solid #e5e7eb; padding-top: 15px; }
        </style>
      </head>
      <body>
        <h1>لیستی پێشنیارکراوی زانکۆلاین (Zanko Guide)</h1>
        <p class="subtitle">ئەم لیستە بە شێوازێکی ژیربێژ ڕێکخراوە بۆ یارمەتیدانی قوتابی لە کاتی پڕکردنەوەی فۆرمی فەرمی زانکۆلاین.</p>
        <table>
          <thead>
            <tr>
              <th class="center" style="width: 50px;">ڕیزبەندی</th>
              <th>زانکۆ</th>
              <th>کۆلێژ/پەیمانگە</th>
              <th>بەش</th>
              <th class="center">لقی خوێندن</th>
              <th class="center">نمرەی گشتی (پار ساڵ)</th>
              <th class="center">پارالێل (پار ساڵ)</th>
            </tr>
          </thead>
          <tbody>
            ${listHtml}
          </tbody>
        </table>
        <div class="footer">
          دروستکراوە لە ڕێگەی ئامرازی ژیری دەستکردی کورتەیا AI. هیوای سەرکەوتن بۆ هەموو دەرچووان.
        </div>
        <script>
          window.onload = function() {
            window.print();
            setTimeout(function() { window.close(); }, 500);
          }
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Quiz Handling
  const startQuiz = () => {
    setQuizStep(0);
    setQuizAnswers([]);
  };

  const handleQuizAnswer = (scoreType: string) => {
    const nextAnswers = [...quizAnswers, scoreType];
    setQuizAnswers(nextAnswers);

    if (quizStep < quizQuestions.length - 1) {
      setQuizStep(quizStep + 1);
    } else {
      // Calculate quiz results
      const counts: { [key: string]: number } = { tech: 0, humanities: 0, medical: 0, business: 0 };
      nextAnswers.forEach((a) => {
        counts[a] = (counts[a] || 0) + 1;
      });

      // Find highest score
      let maxType = "tech";
      let maxVal = 0;
      Object.keys(counts).forEach((k) => {
        if (counts[k] > maxVal) {
          maxVal = counts[k];
          maxType = k;
        }
      });

      let fieldName = "";
      let recommended: UniversityMajor[] = [];

      if (maxType === "tech") {
        fieldName = "تەکنەلۆژیا و ئەندازیاری (Engineering & IT)";
        recommended = zankoMajors.filter(
          (m) =>
            m.majorEnglish.includes("Software") ||
            m.majorEnglish.includes("Computer") ||
            m.majorEnglish.includes("Architecture") ||
            m.majorEnglish.includes("Civil") ||
            m.majorEnglish.includes("IT") ||
            m.majorEnglish.includes("Petroleum")
        );
      } else if (maxType === "medical") {
        fieldName = "پزیشکی و تەندروستی (Medical & Health Sciences)";
        recommended = zankoMajors.filter(
          (m) =>
            m.majorEnglish.includes("Medicine") ||
            m.majorEnglish.includes("Dentistry") ||
            m.majorEnglish.includes("Pharmacy") ||
            m.majorEnglish.includes("Nursing")
        );
      } else if (maxType === "business") {
        fieldName = "کارگێڕی و ئابووری (Business & Economics)";
        recommended = zankoMajors.filter(
          (m) => m.majorEnglish.includes("Business") || m.majorEnglish.includes("Accounting")
        );
      } else {
        fieldName = "یاسا، زمان و زانستە مرۆڤایەتییەکان (Law & Humanities)";
        recommended = zankoMajors.filter(
          (m) =>
            m.majorEnglish.includes("Law") ||
            m.majorEnglish.includes("English") ||
            m.majorEnglish.includes("Kurdish") ||
            m.majorEnglish.includes("History")
        );
      }

      setTopField(fieldName);
      setQuizRecommendations(recommended.slice(0, 4));
      setQuizStep(6);
    }
  };

  // Filter Explorer Directory
  const filteredExplorer = zankoMajors.filter((m) => {
    const query = explorerSearch.toLowerCase();
    return (
      m.majorKurdish.toLowerCase().includes(query) ||
      m.majorEnglish.toLowerCase().includes(query) ||
      m.universityNameKurdish.toLowerCase().includes(query) ||
      m.collegeKurdish.toLowerCase().includes(query)
    );
  });

  return (
    <div className="space-y-8 text-right" dir="rtl">
      {/* Internal Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-card border border-border p-4 rounded-2xl shadow-sm">
        <div className="flex flex-wrap items-center gap-1.5 md:gap-2">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-4 py-2 text-xs md:text-sm font-bold rounded-xl transition ${
              activeTab === "dashboard"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            داشبۆرد
          </button>
          <button
            onClick={() => setActiveTab("predictor")}
            className={`px-4 py-2 text-xs md:text-sm font-bold rounded-xl transition ${
              activeTab === "predictor"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            پێشبینیکردنی نمرە
          </button>
          <button
            onClick={() => setActiveTab("list_builder")}
            className={`px-4 py-2 text-xs md:text-sm font-bold rounded-xl transition relative ${
              activeTab === "list_builder"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            لیستا من
            {savedList.length > 0 && (
              <span className="absolute -top-1.5 -left-1.5 w-5 h-5 bg-destructive text-destructive-foreground text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {savedList.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("quiz")}
            className={`px-4 py-2 text-xs md:text-sm font-bold rounded-xl transition ${
              activeTab === "quiz"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            تاقیکردنا ئارەزووان
          </button>
          <button
            onClick={() => setActiveTab("explorer")}
            className={`px-4 py-2 text-xs md:text-sm font-bold rounded-xl transition ${
              activeTab === "explorer"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            گەڕان ل بەشان
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-extrabold text-sm text-foreground">ڕێبەرێ زانکۆلاین</span>
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-primary-foreground"
            style={{ background: "var(--gradient-primary)" }}
          >
            <GraduationCap className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* ── TAB CONTENT: DASHBOARD ── */}
      {activeTab === "dashboard" && (
        <div className="space-y-8 animate-fadeIn">
          {/* Welcome Hero */}
          <div
            className="relative rounded-3xl p-6 md:p-10 text-white overflow-hidden"
            style={{ background: "var(--gradient-hero)", boxShadow: "var(--shadow-glow)" }}
          >
            <div className="relative z-10 max-w-2xl">
              <div className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3.5 py-1 text-xs font-bold mb-4">
                <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                <span>باشترین ڕێبەر بۆ دەرچووانی پۆلی ١٢ی کوردستان</span>
              </div>
              <h2 className="text-2xl md:text-4xl font-extrabold mb-4 leading-tight">
                پاشەڕۆژا خۆ یا زانکۆیێ ب ژیری دیار بکە
              </h2>
              <p className="text-sm md:text-base text-blue-100 mb-6 leading-relaxed">
                بەشێن زانکۆیێ بەپێی نمرەیا خۆ پێشبینی بکە، ئارەزوو و خولیا خۆ د تاقیکردنەوەیەکی کورت دا بدۆزەوە، و
                لیستەکا دروست و بەهێز بۆ سیستەمی فەرمی زانکۆلاین ڕێکبخە.
              </p>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => setActiveTab("predictor")}
                  className="bg-white text-primary font-bold px-5 py-2.5 rounded-xl text-sm hover:bg-opacity-95 transition flex items-center gap-1.5"
                >
                  پێشبینیکردنی نمرە <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
                <button
                  onClick={() => setActiveTab("quiz")}
                  className="bg-white/15 text-white border border-white/20 font-bold px-5 py-2.5 rounded-xl text-sm hover:bg-white/25 transition"
                >
                  تاقیکردنا ئارەزووان
                </button>
              </div>
            </div>
            {/* Background elements */}
            <div className="absolute left-6 bottom-0 opacity-10 pointer-events-none hidden md:block">
              <GraduationCap className="w-64 h-64 text-white" />
            </div>
          </div>

          {/* Stepper / How it works */}
          <div className="bg-card border border-border rounded-2xl p-6 md:p-8">
            <h3 className="text-lg md:text-xl font-extrabold mb-8 text-center">چەوان کار دکەت؟</h3>
            <div className="grid md:grid-cols-3 gap-6 relative">
              {/* Step 1 */}
              <div className="flex flex-col items-center text-center p-4 bg-secondary/30 rounded-2xl border border-border">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-extrabold text-lg mb-4">
                  ١
                </div>
                <h4 className="font-bold text-base mb-2">نمرە و لقی خۆ بنڤیسە</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  نمرەی گشتی و پارێزگای خۆ بنووسە بۆ دۆزینەوەی ئەو بەشانەی لە نمرەکەت نزیکن.
                </p>
              </div>

              {/* Step 2 */}
              <div className="flex flex-col items-center text-center p-4 bg-secondary/30 rounded-2xl border border-border">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-extrabold text-lg mb-4">
                  ٢
                </div>
                <h4 className="font-bold text-base mb-2">تاقیکردنا ئارەزووان بکە</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  ئەگەر دوودڵیت لە هەڵبژاردنی بەشەکان، وەڵامی ٦ پرسیار بدەرەوە بۆ دەستنیشانکردنی خولیاکانت.
                </p>
              </div>

              {/* Step 3 */}
              <div className="flex flex-col items-center text-center p-4 bg-secondary/30 rounded-2xl border border-border">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-extrabold text-lg mb-4">
                  ٣
                </div>
                <h4 className="font-bold text-base mb-2">لیستا خۆ ڕێکبخە و ناردن بکە</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  بەشە دڵخوازەکانت بە ڕیزبەندییەکی زانستی ڕێکبخە بۆ ئەوەی لە زانکۆلاین بێ کێشە بیت.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats / Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card border border-border p-6 rounded-2xl flex items-start gap-4">
              <div className="p-3 bg-success/10 text-success rounded-xl shrink-0">
                <Info className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base mb-1.5">یاسایا گرنگ یا ڕێزبەندیێ</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  سیستەمی فەرمی زانکۆلاین لە ژوورەوە بۆ خوارەوە سەیری هەڵبژاردنەکانت دەکات. ئەگەر بەشێکی ئاسان بە نمرەیەکی
                  کەم لە پێشەوە دابنێیت، یەکسەر وەردەگیرێیت و هەڵبژاردنەکانی خوارەوە فەرامۆش دەکرێن.
                </p>
              </div>
            </div>

            <div className="bg-card border border-border p-6 rounded-2xl flex items-start gap-4">
              <div className="p-3 bg-amber-500/10 text-amber-500 rounded-xl shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base mb-1.5">پارالێل و ئێواران چییە؟</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  خوێندنی گشتی (بەیانیان) بەخۆڕاییە. خوێندنی پارالێل بە پارەیە بەڵام نمرەی کەمتر دەوێت. خوێندنی ئێواران بە
                  پارەیە و کاتی دەوامی لە ئێواراندایە و کەمترین نمرەی پێویستە.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB CONTENT: GRADE PREDICTOR ── */}
      {activeTab === "predictor" && (
        <div className="space-y-8 animate-fadeIn">
          {/* Form */}
          <div className="bg-card border border-border p-6 rounded-2xl shadow-sm">
            <h3 className="text-lg font-extrabold mb-6">پێشبینیکردنی وەرگرتن بەپێی نمرە</h3>
            <form onSubmit={handlePredict} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
              <div>
                <label className="block text-xs font-bold text-muted-foreground mb-1.5">نمرە / ڕێژە (Percentage)</label>
                <input
                  type="number"
                  step="0.01"
                  min="50"
                  max="100"
                  required
                  value={score}
                  onChange={(e) => setScore(e.target.value)}
                  placeholder="نموونە: 84.5"
                  className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-right focus:outline-none focus:border-primary transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-muted-foreground mb-1.5">لقی خوێندن (Track)</label>
                <select
                  value={track}
                  onChange={(e) => setTrack(e.target.value as "scientific" | "literary")}
                  className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-right focus:outline-none focus:border-primary transition"
                >
                  <option value="scientific">زانستی (Scientific)</option>
                  <option value="literary">وێژەیی (Literary)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-muted-foreground mb-1.5">پارێزگا (Governorate)</label>
                <select
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-right focus:outline-none focus:border-primary transition"
                >
                  <option value="All">هەموو پارێزگاکان</option>
                  <option value="Duhok">دهۆک (Duhok)</option>
                  <option value="Erbil">هەولێر (Erbil)</option>
                  <option value="Sulaymaniyah">سلێمانی (Sulaymaniyah)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-primary text-primary-foreground px-5 py-2.5 font-bold hover:opacity-90 transition flex items-center justify-center gap-1.5 text-sm h-11"
              >
                <Search className="w-4 h-4" /> بەشەکانم نیشان بدە
              </button>
            </form>
          </div>

          {/* Results grouped into 3 tiers */}
          {predictorSearched && (
            <div className="space-y-10">
              {/* Category 1: Target Choices */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-border pb-2 justify-start">
                  <div className="w-3 h-3 rounded-full bg-primary shrink-0" />
                  <h4 className="font-extrabold text-base">بەشێن گونجاو (Target Choices)</h4>
                  <span className="text-xs text-muted-foreground">(کێبرکێی بەهێز لەسەر ئەم بەشانە هەیە)</span>
                </div>

                {predictionResults.target.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-right p-4 bg-secondary/20 rounded-xl">
                    هیچ بەشێک لە نمرەی تۆوە زۆر نزیک نییە.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {predictionResults.target.map((m) => (
                      <MajorCard key={m.id} major={m} onAdd={() => addMajorToList(m)} savedList={savedList} />
                    ))}
                  </div>
                )}
              </div>

              {/* Category 2: Safe Choices */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-border pb-2 justify-start">
                  <div className="w-3 h-3 rounded-full bg-success shrink-0" />
                  <h4 className="font-extrabold text-base">بەشێن مسۆگەر (Safe Choices)</h4>
                  <span className="text-xs text-muted-foreground">(نمرەی تۆ زۆر لە سەرووی نمرەی پێویستی ئەمانەوەیە)</span>
                </div>

                {predictionResults.safe.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-right p-4 bg-secondary/20 rounded-xl">
                    هیچ بەشێک نییە کە نمرەی تۆ زۆر لە سەرووی بێت.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {predictionResults.safe.map((m) => (
                      <MajorCard key={m.id} major={m} onAdd={() => addMajorToList(m)} savedList={savedList} />
                    ))}
                  </div>
                )}
              </div>

              {/* Category 3: Reach Choices */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-border pb-2 justify-start">
                  <div className="w-3 h-3 rounded-full bg-amber-500 shrink-0" />
                  <h4 className="font-extrabold text-base">بەشێن ئاست بەرزتر (Reach Choices)</h4>
                  <span className="text-xs text-muted-foreground">(تۆزێک لە نمرەی تۆ زیاتری دەوێت بەڵام شایەنی تاقیکردنەوەیە)</span>
                </div>

                {predictionResults.reach.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-right p-4 bg-secondary/20 rounded-xl">
                    هیچ بەشێک بە کەمێک نمرەی بەرزترەوە نییە.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {predictionResults.reach.map((m) => (
                      <MajorCard key={m.id} major={m} onAdd={() => addMajorToList(m)} savedList={savedList} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── TAB CONTENT: SMART LIST BUILDER ── */}
      {activeTab === "list_builder" && (
        <div className="space-y-8 animate-fadeIn">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4">
            <div>
              <h3 className="text-lg font-extrabold">ڕێکخستنا لیستا دڵخواز (ZankoLine Smart List)</h3>
              <p className="text-xs text-muted-foreground mt-1">
                بەشەکان بە شێوازێکی تەندروست ڕێکبخە و لێرەوە ئاگادارییەکان ببینە.
              </p>
            </div>

            {savedList.length > 0 && (
              <div className="flex items-center gap-2">
                <button
                  onClick={clearList}
                  className="px-3.5 py-2 text-xs font-bold bg-destructive/10 text-destructive rounded-xl hover:bg-destructive/20 transition flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" /> سڕینەوەی هەمووی
                </button>
                <button
                  onClick={copyListToClipboard}
                  className="px-3.5 py-2 text-xs font-bold bg-secondary text-foreground rounded-xl hover:bg-secondary/80 transition flex items-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copySuccess ? "کۆپی کرا!" : "کۆپیکردنی لیست"}
                </button>
                <button
                  onClick={exportPdf}
                  className="px-3.5 py-2 text-xs font-bold bg-primary text-primary-foreground rounded-xl hover:opacity-90 transition flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> هەناردەی PDF
                </button>
              </div>
            )}
          </div>

          {/* Validation Warnings Panel */}
          {validationWarnings.length > 0 && (
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center gap-2 text-amber-500 justify-start">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h4 className="font-extrabold text-sm">پشکنینا ژیربێژ یا لیستێ (Smart Validation)</h4>
              </div>
              <ul className="space-y-1.5 text-right pr-6 list-disc list-outside text-xs text-amber-700 dark:text-amber-400">
                {validationWarnings.map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          {savedList.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4">
              <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center text-muted-foreground">
                <BookOpen className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-bold text-base mb-1">لیستی تۆ بەتاڵە</h4>
                <p className="text-xs text-muted-foreground max-w-sm">
                  بۆ دروستکردنی لیستەکەت، بچۆ بەشی (پێشبینیکردنی نمرە) یان (گەڕان لە بەشەکان) و بەشە دڵخوازەکانت لێرە زیاد
                  بکە.
                </p>
              </div>
              <button
                onClick={() => setActiveTab("predictor")}
                className="bg-primary text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl hover:opacity-95 transition"
              >
                بڕۆ بەشی پێشبینیکردنی نمرە
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {savedList.map((m, idx) => (
                <div
                  key={m.id}
                  className="bg-card border border-border rounded-xl p-4 flex items-center gap-4 transition hover:border-primary/40 shadow-sm"
                >
                  {/* Ordering arrows */}
                  <div className="flex flex-col gap-1.5 shrink-0">
                    <button
                      onClick={() => moveItem(idx, "up")}
                      disabled={idx === 0}
                      className="w-8 h-8 rounded-lg bg-secondary text-foreground hover:bg-primary hover:text-primary-foreground disabled:opacity-35 disabled:hover:bg-secondary disabled:hover:text-foreground flex items-center justify-center transition"
                      aria-label="بەرەو سەرەوە"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => moveItem(idx, "down")}
                      disabled={idx === savedList.length - 1}
                      className="w-8 h-8 rounded-lg bg-secondary text-foreground hover:bg-primary hover:text-primary-foreground disabled:opacity-35 disabled:hover:bg-secondary disabled:hover:text-foreground flex items-center justify-center transition"
                      aria-label="بەرەو خوارەوە"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Serial number */}
                  <div className="text-lg font-black text-muted-foreground w-6 text-center">{idx + 1}</div>

                  {/* Info details */}
                  <div className="flex-1 min-w-0 text-right">
                    <h4 className="font-extrabold text-sm text-foreground truncate">{m.majorKurdish}</h4>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">
                      {m.universityNameKurdish} • {m.collegeKurdish}
                    </p>
                    <div className="flex items-center gap-2 mt-2 justify-end">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
                        نمرەی پار ساڵ: {m.thresholds.general}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                        پارالێل: {m.thresholds.parallel}
                      </span>
                    </div>
                  </div>

                  {/* Action delete */}
                  <button
                    onClick={() => removeMajorFromList(m.id)}
                    className="w-9 h-9 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground flex items-center justify-center transition shrink-0"
                    aria-label="سڕینەوە"
                  >
                    <Trash2 className="w-4.5 h-4.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── TAB CONTENT: INTEREST QUIZ ── */}
      {activeTab === "quiz" && (
        <div className="space-y-8 animate-fadeIn">
          {quizStep === -1 && (
            <div className="bg-card border border-border p-6 md:p-10 rounded-3xl shadow-sm text-center flex flex-col items-center justify-center max-w-xl mx-auto space-y-6">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center text-primary-foreground"
                style={{ background: "var(--gradient-primary)" }}
              >
                <Sparkles className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg md:text-xl font-extrabold mb-2">تاقیکردنا کورت یا ئارەزووان</h3>
                <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
                  ئەگەر دوودڵیت یان نازانیت چ زانکۆیەک یان چ بەشێک هەڵدەبژێریت، ئەم تاقیکردنەوە کورتە یارمەتیت دەدات خولیا و
                  بوارە گونجاوەکانت بدۆزیتەوە بەپێی وەڵامەکانت.
                </p>
              </div>
              <button
                onClick={startQuiz}
                className="bg-primary text-primary-foreground font-bold px-6 py-3 rounded-xl hover:opacity-90 transition flex items-center gap-1.5 text-sm"
              >
                دەستپێکردنی تاقیکردنەوە <ArrowRight className="w-4 h-4 rotate-180" />
              </button>
            </div>
          )}

          {quizStep >= 0 && quizStep < quizQuestions.length && (
            <div className="bg-card border border-border p-6 md:p-8 rounded-2xl shadow-sm max-w-xl mx-auto space-y-6 animate-fadeIn">
              {/* Progress */}
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>
                  پرسیاری {quizStep + 1} لە {quizQuestions.length}
                </span>
                <span>ڕێژەی پێشکەوتن: {Math.round(((quizStep + 1) / quizQuestions.length) * 100)}%</span>
              </div>
              <div className="w-full bg-secondary h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-primary h-full transition-all duration-300"
                  style={{ width: `${((quizStep + 1) / quizQuestions.length) * 100}%` }}
                />
              </div>

              {/* Question */}
              <h3 className="font-extrabold text-base md:text-lg leading-relaxed text-foreground text-right">
                {quizQuestions[quizStep].q}
              </h3>

              {/* Options */}
              <div className="space-y-3">
                {quizQuestions[quizStep].options.map((opt, oIdx) => (
                  <button
                    key={oIdx}
                    onClick={() => handleQuizAnswer(opt.score)}
                    className="w-full text-right bg-secondary/40 border border-border p-4 rounded-xl hover:border-primary/60 hover:bg-primary/5 font-semibold text-sm transition flex items-center justify-between group"
                  >
                    <span>{opt.text}</span>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition shrink-0 rotate-180" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {quizStep === 6 && (
            <div className="bg-card border border-border p-6 md:p-8 rounded-3xl shadow-sm max-w-xl mx-auto space-y-6 animate-fadeIn text-center">
              <div className="w-16 h-16 rounded-full bg-success/10 text-success flex items-center justify-center mx-auto">
                <Award className="w-8 h-8" />
              </div>
              <div>
                <span className="text-xs font-bold text-primary px-2.5 py-1 rounded-full bg-primary/10">بوارێ گونجاو</span>
                <h3 className="text-lg md:text-xl font-extrabold mt-3 text-foreground">{topField}</h3>
                <p className="text-xs text-muted-foreground mt-2 max-w-sm mx-auto leading-relaxed">
                  بەپێی وەڵامەکانت، تۆ خولیا و ئارەزووت پتر بۆ کارکردن و خوێندن لەم بوارەدایە. لێرەدا چەند پێشنیارێکمان هەیە
                  بۆت:
                </p>
              </div>

              {/* Recommendations */}
              <div className="space-y-3 text-right">
                <h4 className="font-extrabold text-xs text-muted-foreground border-b border-border pb-1.5">
                  بەشە پێشنیارکراوەکان بەپێی ئارەزووی تۆ:
                </h4>
                {quizRecommendations.map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center justify-between p-3.5 bg-secondary/40 border border-border rounded-xl"
                  >
                    <div className="text-right">
                      <h5 className="font-extrabold text-xs text-foreground">{m.majorKurdish}</h5>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{m.universityNameKurdish}</p>
                    </div>
                    <button
                      onClick={() => addMajorToList(m)}
                      className="px-3 py-1.5 text-[10px] font-bold bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" /> زیادکردن
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 justify-center pt-2">
                <button
                  onClick={() => setQuizStep(-1)}
                  className="px-4 py-2 border border-border rounded-xl text-xs font-bold hover:bg-secondary transition"
                >
                  دوبارە تاقیکردنەوە
                </button>
                <button
                  onClick={() => setActiveTab("list_builder")}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-xs font-bold hover:opacity-95 transition"
                >
                  سەیرکردنی لیستی من
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── TAB CONTENT: MAJOR EXPLORER ── */}
      {activeTab === "explorer" && (
        <div className="space-y-8 animate-fadeIn">
          {/* Directory Search */}
          <div className="bg-card border border-border p-6 rounded-2xl shadow-sm">
            <h3 className="text-lg font-extrabold mb-4">گەڕان و فێربوون لەسەر بەشەکانی زانکۆ</h3>
            <div className="relative">
              <input
                type="text"
                placeholder="بۆ نموونە: ئەندازیاری، پزیشکی، یاسا، دهۆک..."
                value={explorerSearch}
                onChange={(e) => setExplorerSearch(e.target.value)}
                className="w-full rounded-xl border border-border bg-background px-4 py-2.5 pl-10 text-sm text-right focus:outline-none focus:border-primary transition"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            </div>
          </div>

          {/* Directory Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredExplorer.map((m) => (
              <div
                key={m.id}
                onClick={() => setSelectedMajor(m)}
                className="bg-card border border-border rounded-xl p-5 hover:border-primary/60 transition cursor-pointer flex flex-col justify-between group shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
                      {m.track === "scientific" ? "زانستی" : "وێژەیی"}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{m.governorate}</span>
                  </div>
                  <h4 className="font-extrabold text-sm text-foreground group-hover:text-primary transition">
                    {m.majorKurdish}
                  </h4>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {m.universityNameKurdish} • {m.collegeKurdish}
                  </p>
                </div>
                <div className="flex items-center justify-between border-t border-border/60 pt-3 mt-4 text-[10px]">
                  <span className="text-muted-foreground">نمرەی پار ساڵ: {m.thresholds.general}</span>
                  <span className="text-primary font-bold hover:underline flex items-center gap-0.5">
                    زانیاری پتر <ChevronRight className="w-3 h-3 rotate-180" />
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Details Modal */}
          {selectedMajor && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              {/* Backdrop */}
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedMajor(null)} />

              {/* Box */}
              <div className="relative bg-card border border-border rounded-3xl w-full max-w-lg p-6 overflow-y-auto max-h-[85vh] text-right shadow-2xl animate-scaleUp">
                <button
                  onClick={() => setSelectedMajor(null)}
                  className="absolute left-4 top-4 w-8 h-8 rounded-full bg-secondary flex items-center justify-center hover:bg-destructive hover:text-white transition"
                  aria-label="داخستن"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="mb-6 mt-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                    {selectedMajor.track === "scientific" ? "زانستی" : "وێژەیی"}
                  </span>
                  <h3 className="text-lg md:text-xl font-extrabold text-foreground mt-2">
                    {selectedMajor.majorKurdish}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {selectedMajor.universityNameKurdish} • {selectedMajor.collegeKurdish}
                  </p>
                </div>

                <div className="space-y-5">
                  <div>
                    <h4 className="font-bold text-xs text-primary mb-1">دەربارەی بەش</h4>
                    <p className="text-xs text-foreground/90 leading-relaxed">{selectedMajor.details.about}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs text-primary mb-2">بابەتە سەرەکییەکان کە دەخوێندرێن</h4>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedMajor.details.subjects.map((sub, sIdx) => (
                        <span key={sIdx} className="text-[10px] bg-secondary px-2.5 py-1 rounded-lg text-foreground">
                          {sub}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-xs text-primary mb-1.5">بازاڕی کار و داهاتووی پیشەیی</h4>
                    <ul className="list-disc list-inside text-xs space-y-1 text-foreground/80 pr-2">
                      {selectedMajor.details.careers.map((car, cIdx) => (
                        <li key={cIdx}>{car}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="border-t border-border pt-4 mt-6 flex items-center justify-between">
                    <div>
                      <span className="block text-[10px] text-muted-foreground">کەمترین نمرە (گشتی / پارالێل)</span>
                      <span className="font-black text-sm text-success">
                        {selectedMajor.thresholds.general} / {selectedMajor.thresholds.parallel}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        addMajorToList(selectedMajor);
                        setSelectedMajor(null);
                      }}
                      className="bg-primary text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl hover:opacity-90 transition"
                    >
                      زیادکردن بۆ لیستی من
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Sub Component for Predictor Cards
interface MajorCardProps {
  major: UniversityMajor;
  onAdd: () => void;
  savedList: UniversityMajor[];
}

function MajorCard({ major, onAdd, savedList }: MajorCardProps) {
  const isAdded = savedList.some((m) => m.id === major.id);

  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-4 transition hover:border-primary/40 shadow-sm">
      <div className="text-right flex-1 min-w-0">
        <div className="flex items-center gap-1.5 justify-end">
          <h4 className="font-extrabold text-sm text-foreground truncate">{major.majorKurdish}</h4>
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-secondary text-muted-foreground shrink-0">
            {major.track === "scientific" ? "زانستی" : "وێژەیی"}
          </span>
        </div>
        <p className="text-xs text-muted-foreground truncate mt-0.5">
          {major.universityNameKurdish} • {major.collegeKurdish}
        </p>

        <div className="flex items-center gap-2 mt-2 justify-end">
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-success/15 text-success">
            کەمترین نمرە: {major.thresholds.general}
          </span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary">
            پارالێل: {major.thresholds.parallel}
          </span>
          {major.thresholds.evening && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-500">
              ئێواران: {major.thresholds.evening}
            </span>
          )}
        </div>
      </div>

      <button
        onClick={onAdd}
        disabled={isAdded}
        className={`w-9 h-9 rounded-xl flex items-center justify-center transition shrink-0 ${
          isAdded
            ? "bg-success/10 text-success cursor-default"
            : "bg-primary text-primary-foreground hover:opacity-90"
        }`}
        aria-label="زیادکردن بۆ لیستی من"
      >
        {isAdded ? <CheckCircle className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
      </button>
    </div>
  );
}
