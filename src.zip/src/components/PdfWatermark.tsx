import { useState, useRef, DragEvent } from "react";
import { Upload, X, Loader2, FileText, Download, Stamp } from "lucide-react";
import { PDFDocument, rgb, StandardFonts, degrees } from "@cantoo/pdf-lib";

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function PdfWatermark() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dropActive, setDropActive] = useState(false);
  const [text, setText] = useState("CONFIDENTIAL");
  const [opacity, setOpacity] = useState(0.25);
  const [result, setResult] = useState<{ url: string; name: string; size: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const pickFile = (f: File | null) => {
    if (!f) return;
    if (f.type !== "application/pdf" && !f.name.endsWith(".pdf")) { setError("تنێ فایلێن PDF قبول دکرن."); return; }
    setFile(f); setError(null); setResult(null);
  };

  const onDragOver = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDropActive(true); };
  const onDragLeave = () => setDropActive(false);
  const onDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDropActive(false); pickFile(e.dataTransfer.files?.[0] || null); };

  const applyWatermark = async () => {
    if (!file || !text.trim()) return;
    setLoading(true); setError(null); setResult(null);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      const font = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      const fontSize = 48;

      pdfDoc.getPages().forEach((page) => {
        const { width, height } = page.getSize();
        page.drawText(text.trim(), {
          x: width / 2 - (font.widthOfTextAtSize(text.trim(), fontSize) / 2),
          y: height / 2,
          size: fontSize,
          font,
          color: rgb(0.6, 0.1, 0.1),
          opacity,
          rotate: degrees(45),
        });
      });

      const bytes = await pdfDoc.save({ useObjectStreams: true });
      const blob = new Blob([bytes.buffer as ArrayBuffer], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      setResult({ url, name: file.name.replace(/\.pdf$/i, "") + "_watermarked.pdf", size: bytes.byteLength });
    } catch (e) {
      setError(e instanceof Error ? e.message : "کێشەیەک هاتە دیتن د زێدەکرنا نیشانا ئاڤێدا.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => { if (result?.url) URL.revokeObjectURL(result.url); setFile(null); setResult(null); setError(null); };

  return (
    <div className="rounded-2xl bg-card border border-border p-6 md:p-8" style={{ boxShadow: "var(--shadow-elegant)" }}>
      {/* Header */}
      <div className="mb-6 text-right">
        <div className="flex items-center justify-end gap-3 mb-1">
          <h3 className="text-xl font-extrabold">نیشانا Watermark لسەر PDF</h3>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center text-primary-foreground shrink-0" style={{ background: "var(--gradient-primary)" }}>
            <Stamp className="w-5 h-5" />
          </div>
        </div>
        <p className="text-sm text-muted-foreground">نڤیسینا Watermark بنڤیسە و فایلێ PDF بدانە</p>
      </div>

      {/* Upload */}
      {!file ? (
        <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} onClick={() => fileInputRef.current?.click()}
          className={`relative w-full rounded-2xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center gap-3 py-10 px-4 mb-6 ${dropActive ? "border-primary bg-primary/5 scale-[1.01]" : "border-border hover:border-primary/60 hover:bg-secondary/40"}`}>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-primary-foreground" style={{ background: "var(--gradient-primary)" }}>
            <Upload className="w-6 h-6" />
          </div>
          <div className="text-center">
            <p className="font-bold text-sm mb-0.5">فایلا PDFێ خۆ بار بکە</p>
            <p className="text-xs text-muted-foreground">کلیک بکە یان drag &amp; drop بکە</p>
          </div>
          <input ref={fileInputRef} type="file" accept="application/pdf,.pdf" onChange={(e) => pickFile(e.target.files?.[0] || null)} className="hidden" />
        </div>
      ) : (
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-border bg-secondary/40 px-4 py-3">
          <FileText className="w-5 h-5 text-primary shrink-0" />
          <div className="flex-1 min-w-0 text-right">
            <p className="text-sm font-semibold truncate">{file.name}</p>
            <p className="text-xs text-muted-foreground">{formatBytes(file.size)}</p>
          </div>
          <button type="button" onClick={reset} className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Settings */}
      {file && !result && (
        <div className="mb-5 space-y-4">
          {/* Watermark text */}
          <div className="text-right">
            <label className="text-xs font-bold text-muted-foreground block mb-2">نڤیسینا Watermark</label>
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="نموونە: CONFIDENTIAL"
              maxLength={40}
              dir="ltr"
              className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm font-bold text-center focus:outline-none focus:ring-2 focus:ring-primary/40 transition"
            />
          </div>
          {/* Opacity */}
          <div className="text-right">
            <label className="text-xs font-bold text-muted-foreground block mb-2">
              ئاستا ڕوناکیێ — <span className="text-primary">{Math.round(opacity * 100)}%</span>
            </label>
            <input
              type="range"
              min={5} max={60} step={5}
              value={Math.round(opacity * 100)}
              onChange={(e) => setOpacity(parseInt(e.target.value) / 100)}
              className="w-full accent-primary"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
              <span>کێمتر دیار</span>
              <span>زێدە دیار</span>
            </div>
          </div>
          {/* Preview label */}
          <div className="rounded-xl border border-dashed border-border bg-secondary/20 py-6 flex items-center justify-center overflow-hidden">
            <span className="font-bold text-2xl select-none" style={{ opacity, color: "rgb(153,26,26)", transform: "rotate(-45deg)", display: "inline-block" }}>
              {text || "WATERMARK"}
            </span>
          </div>
        </div>
      )}

      {error && <div className="rounded-xl bg-destructive/10 text-destructive text-sm p-3 mb-4 text-right">{error}</div>}

      {/* Result */}
      {result && (
        <div className="rounded-xl border border-border bg-background p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-muted-foreground">ئەنجام</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-success/15 text-success">ئامادەیە ✓</span>
          </div>
          <a href={result.url} download={result.name}
            className="flex items-center justify-center gap-2 w-full rounded-xl bg-primary text-primary-foreground px-5 py-2.5 text-sm font-bold hover:opacity-90 transition"
            style={{ boxShadow: "var(--shadow-glow)" }}>
            <Download className="w-4 h-4" /> دانلودکرن
          </a>
        </div>
      )}

      {!result && !loading && (
        <div className="flex justify-end">
          <button type="button" onClick={applyWatermark} disabled={!file || !text.trim()}
            className="inline-flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-6 py-2.5 text-sm font-bold hover:opacity-90 disabled:opacity-50 transition"
            style={{ boxShadow: file ? "var(--shadow-glow)" : undefined }}>
            <Stamp className="w-4 h-4" /> زێدە بکە و دانلود بکە
          </button>
        </div>
      )}
      {loading && (
        <div className="flex items-center justify-end gap-2 text-primary">
          <span className="text-sm font-semibold">د ئامادەکرنێدا...</span>
          <Loader2 className="w-4 h-4 animate-spin" />
        </div>
      )}
      {result && (
        <div className="flex justify-end mt-2">
          <button type="button" onClick={reset} className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2 transition">فایلێکی تر بار بکە</button>
        </div>
      )}
    </div>
  );
}
