import { useState, useRef, DragEvent, useEffect } from "react";
import { Upload, X, FileText, FileType2, Presentation, Table2, PenTool, Compass, Loader2, Download } from "lucide-react";
import html2canvas from "html2canvas";

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function FilesToPdf() {
  const [file, setFile] = useState<File | null>(null);
  const [dropActive, setDropActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState("");
  const [result, setResult] = useState<{ url: string; name: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileAccept = ".doc,.docx,.ppt,.pptx,.xls,.xlsx,.ai,.psd,.pdf,.dwg,.dxf";

  const pickFile = (f: File | null) => {
    if (!f) return;
    setFile(f); 
    setError(null);
    setResult(null);
  };

  const onDragOver = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDropActive(true); };
  const onDragLeave = () => setDropActive(false);
  const onDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDropActive(false); pickFile(e.dataTransfer.files?.[0] || null); };

  const reset = () => { 
    if (result?.url) URL.revokeObjectURL(result.url); 
    setFile(null); 
    setError(null); 
    setResult(null); 
  };

  const convertToPdf = async () => {
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    
    if (!['docx', 'xlsx', 'xls'].includes(ext)) {
      setError(`ببورە، د نوکەدا ب تنێ فایلێن Word (.docx) و Excel (.xlsx, .xls) بشێوەیێ ئۆفلاین و ئێکسەر دهێنە گۆڕین. بۆ فایلێن ${ext.toUpperCase()} پێویستیا تە ب خزمەتگوزاریێن ئۆنلاین هەیە.`);
      return;
    }

    setLoading(true); setError(null); setResult(null);
    
    try {
      if (ext === 'docx') {
        setProgress("د خواندنا فایلا Wordda...");
        const mammoth = await import("mammoth");
        const ab = await file.arrayBuffer();
        const { value: html } = await mammoth.convertToHtml({ arrayBuffer: ab });

        setProgress("د دروستکرنا PDFda...");
        
        const iframe = document.createElement("iframe");
        iframe.style.cssText = "position:fixed;left:-9999px;top:-9999px;width:794px;border:none;";
        document.body.appendChild(iframe);

        const iDoc = iframe.contentDocument!;
        iDoc.open();
        iDoc.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
          <style>
            body{font-family:Arial,sans-serif;font-size:12pt;line-height:1.6;padding:40px;margin:0;color:#111;direction:auto;background:white;}
            h1,h2,h3{color:#1a1a2e;margin-bottom:8px;}
            p{margin-bottom:8px;}
            table{border-collapse:collapse;width:100%;}
            td,th{border:1px solid #ccc;padding:6px 8px;}
            img{max-width:100%;}
          </style></head><body>${html}</body></html>`);
        iDoc.close();

        await new Promise(r => setTimeout(r, 600));

        const canvas = await html2canvas(iDoc.body, { scale: 1.5, useCORS: true, logging: false });
        
        const { PDFDocument, rgb } = await import("@cantoo/pdf-lib");
        const pdfDoc = await PDFDocument.create();

        const PAGE_W = 794; 
        const PAGE_H = 1123;
        const totalHeight = canvas.height;
        const scaledPageHeight = Math.floor((PAGE_H / PAGE_W) * canvas.width); 
        
        const totalPages = Math.ceil(totalHeight / scaledPageHeight) || 1;

        for (let p = 0; p < totalPages; p++) {
          setProgress(`لاپەر ${p + 1} / ${totalPages}...`);
          
          const pageCanvas = document.createElement("canvas");
          pageCanvas.width = canvas.width;
          const currentHeight = Math.min(scaledPageHeight, totalHeight - p * scaledPageHeight);
          pageCanvas.height = currentHeight;
          
          const pCtx = pageCanvas.getContext("2d")!;
          pCtx.fillStyle = "#ffffff";
          pCtx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
          pCtx.drawImage(
            canvas,
            0, p * scaledPageHeight, canvas.width, currentHeight,
            0, 0, pageCanvas.width, currentHeight
          );

          const jpegDataUrl = pageCanvas.toDataURL("image/jpeg", 0.9);
          const base64 = jpegDataUrl.split(",")[1];
          const jpegBytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
          
          const jpegImg = await pdfDoc.embedJpg(jpegBytes);
          const page = pdfDoc.addPage([PAGE_W, PAGE_H]);
          
          const drawH = (currentHeight / canvas.width) * PAGE_W;
          page.drawImage(jpegImg, { x: 0, y: PAGE_H - drawH, width: PAGE_W, height: drawH });
          
          page.drawText(`${p + 1}`, { x: PAGE_W - 30, y: 15, size: 10, color: rgb(0.6, 0.6, 0.6) });
        }

        document.body.removeChild(iframe);

        setProgress("د ئامادەکرنا دانلودێدا...");
        const pdfBytes = await pdfDoc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: "application/pdf" });
        const url = URL.createObjectURL(blob);
        setResult({ url, name: file.name.replace(/\.docx$/i, "") + ".pdf" });

      } else if (ext === 'xlsx' || ext === 'xls') {
        setProgress("د خواندنا فایلا Excelda...");
        const XLSX = await import("xlsx");
        const ab = await file.arrayBuffer();
        const wb = XLSX.read(ab, { type: "array" });

        const { PDFDocument, rgb, StandardFonts } = await import("@cantoo/pdf-lib");
        const pdfDoc = await PDFDocument.create();
        const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
        const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

        const PAGE_W = 841.89; 
        const PAGE_H = 595.28;
        const MARGIN = 30;
        const ROW_H = 18;
        const HEADER_H = 24;

        for (let si = 0; si < wb.SheetNames.length; si++) {
          const sheetName = wb.SheetNames[si];
          setProgress(`Sheet "${sheetName}" — د پڕۆسێسکرنێدا...`);

          const ws = wb.Sheets[sheetName];
          const data: string[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }) as string[][];
          if (!data.length) continue;

          const colCount = Math.max(...data.map(r => r.length));
          const maxColW = Math.floor((PAGE_W - 2 * MARGIN) / Math.max(colCount, 1));
          const colWidths = Array(colCount).fill(Math.min(maxColW, 120));

          const usableH = PAGE_H - 2 * MARGIN;
          const rowsPerPage = Math.floor((usableH - HEADER_H) / ROW_H);
          const dataRows = data.slice(1);
          const header = data[0] ?? [];

          const totalPageCount = Math.ceil(dataRows.length / rowsPerPage) || 1;

          for (let pi = 0; pi < totalPageCount; pi++) {
            const page = pdfDoc.addPage([PAGE_W, PAGE_H]);

            page.drawText(`${sheetName}  (${pi + 1}/${totalPageCount})`, {
              x: MARGIN, y: PAGE_H - MARGIN,
              size: 11, font: boldFont, color: rgb(0.1, 0.1, 0.5),
            });

            let y = PAGE_H - MARGIN - HEADER_H;

            page.drawRectangle({ x: MARGIN, y, width: PAGE_W - 2 * MARGIN, height: HEADER_H, color: rgb(0.22, 0.19, 0.85), opacity: 0.9 });
            let x = MARGIN;
            header.forEach((cell, ci) => {
              const text = String(cell ?? "").substring(0, 20);
              page.drawText(text, { x: x + 3, y: y + 6, size: 8, font: boldFont, color: rgb(1, 1, 1) });
              x += colWidths[ci] ?? maxColW;
            });
            y -= ROW_H;

            const pageData = dataRows.slice(pi * rowsPerPage, (pi + 1) * rowsPerPage);
            pageData.forEach((row, ri) => {
              if (ri % 2 === 0) {
                page.drawRectangle({ x: MARGIN, y, width: PAGE_W - 2 * MARGIN, height: ROW_H, color: rgb(0.96, 0.96, 0.99) });
              }
              let rx = MARGIN;
              for (let ci = 0; ci < colCount; ci++) {
                const text = String(row[ci] ?? "").substring(0, 22);
                if (text) page.drawText(text, { x: rx + 3, y: y + 4, size: 8, font, color: rgb(0.1, 0.1, 0.1) });
                rx += colWidths[ci] ?? maxColW;
              }
              page.drawLine({ start: { x: MARGIN, y }, end: { x: PAGE_W - MARGIN, y }, thickness: 0.3, color: rgb(0.85, 0.85, 0.85) });
              y -= ROW_H;
            });
          }
        }

        setProgress("د ئامادەکرنا دانلودێدا...");
        const pdfBytes = await pdfDoc.save();
        const blob = new Blob([pdfBytes.buffer as ArrayBuffer], { type: "application/pdf" });
        const url = URL.createObjectURL(blob);
        setResult({ url, name: file.name.replace(/\.(xlsx|xls)$/i, "") + ".pdf" });
      }
    } catch (e: any) {
      console.error(e);
      setError("کێشەیەکێ هاتە دی د گۆڕینێدا: " + (e.message || String(e)));
    } finally { 
      setLoading(false); 
      setProgress(""); 
    }
  };

  useEffect(() => {
    if (file && !result && !loading && !error) {
      convertToPdf();
    }
  }, [file]);

  return (
    <div className="rounded-2xl bg-card border border-border p-6 md:p-8" style={{ boxShadow: "var(--shadow-elegant)" }}>
      {/* Header */}
      <div className="mb-8 text-right">
        <div className="flex items-center justify-end gap-3 mb-2">
          <h3 className="text-2xl font-extrabold bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-primary)" }}>
            گەڕۆکا گۆڕینا فایلان بو PDF
          </h3>
          <div className="w-12 h-12 rounded-xl flex items-center justify-center text-primary-foreground shrink-0 shadow-lg" style={{ background: "var(--gradient-primary)" }}>
            <FileType2 className="w-6 h-6" />
          </div>
        </div>
        <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
          هەر فایلەکێ (Word, PowerPoint, Excel, Adobe, AutoCAD) بدانە لێرە بۆ گۆڕین بو PDFێکا جوان.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
        {[
          { label: "Word", icon: FileType2, color: "text-blue-500 bg-blue-500/10 border-blue-500/20" },
          { label: "PowerPoint", icon: Presentation, color: "text-red-500 bg-red-500/10 border-red-500/20" },
          { label: "Excel", icon: Table2, color: "text-green-500 bg-green-500/10 border-green-500/20" },
          { label: "Adobe", icon: PenTool, color: "text-purple-500 bg-purple-500/10 border-purple-500/20" },
          { label: "AutoCAD", icon: Compass, color: "text-teal-500 bg-teal-500/10 border-teal-500/20" }
        ].map(cat => (
          <div key={cat.label} className={`flex flex-col items-center justify-center p-3 rounded-xl border ${cat.color}`}>
            <cat.icon className="w-6 h-6 mb-1.5" />
            <span className="text-xs font-bold">{cat.label}</span>
          </div>
        ))}
      </div>

      {/* Upload zone */}
      {!file ? (
        <div onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop} onClick={() => fileInputRef.current?.click()}
          className={`relative w-full rounded-3xl border-2 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center gap-4 py-12 px-4 mb-8 ${dropActive ? "border-primary bg-primary/5 scale-[1.01]" : "border-border hover:border-primary/60 hover:bg-secondary/40"}`}>
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-primary-foreground shadow-lg" style={{ background: "var(--gradient-primary)" }}>
            <Upload className="w-7 h-7" />
          </div>
          <div className="text-center">
            <p className="font-extrabold text-base mb-1">فایلا خۆ بار بکە (Office, Adobe, AutoCAD)</p>
            <p className="text-sm text-muted-foreground">کلیک بکە یان drag &amp; drop بکە</p>
          </div>
          <input ref={fileInputRef} type="file" accept={fileAccept} onChange={(e) => pickFile(e.target.files?.[0] || null)} className="hidden" />
        </div>
      ) : (
        <div className="mb-8 flex items-center gap-4 rounded-2xl border border-primary/20 bg-primary/5 px-5 py-4 shadow-sm">
          <FileText className="w-7 h-7 text-primary shrink-0" />
          <div className="flex-1 min-w-0 text-right">
            <p className="text-base font-bold truncate text-foreground">{file.name}</p>
            <p className="text-xs font-medium text-muted-foreground mt-0.5">{formatBytes(file.size)}</p>
          </div>
          <button type="button" onClick={reset} className="w-9 h-9 rounded-xl flex items-center justify-center bg-background border border-border text-muted-foreground hover:text-destructive hover:border-destructive/30 hover:bg-destructive/10 transition shrink-0 shadow-sm">
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {error && <div className="rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm font-semibold p-4 mb-6 text-right shadow-sm">{error}</div>}

      {loading && (
        <div className="rounded-xl bg-primary/5 border border-primary/20 p-4 mb-4 text-right">
          <div className="flex items-center justify-end gap-2">
            <span className="text-sm font-semibold text-primary">{progress}</span>
            <Loader2 className="w-4 h-4 animate-spin text-primary shrink-0" />
          </div>
          <p className="text-xs text-muted-foreground mt-1">تکایە چاوەڕێ بکە.</p>
        </div>
      )}

      {result && (
        <div className="rounded-xl border border-border bg-background p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-muted-foreground">ئەنجام</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-success/15 text-success">ئامادەیە ✓</span>
          </div>
          <a href={result.url} download={result.name} className="flex items-center justify-center gap-2 w-full rounded-xl bg-primary text-primary-foreground px-5 py-2.5 text-sm font-bold hover:opacity-90 transition" style={{ boxShadow: "var(--shadow-glow)" }}>
            <Download className="w-4 h-4" /> دانلودکرنا فایلا PDF
          </a>
          <p className="text-center text-[10px] text-muted-foreground mt-2">{result.name}</p>
        </div>
      )}
    </div>
  );
}
