import { useState, useRef, useMemo, useEffect } from "react";
import * as XLSX from "xlsx";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  ReferenceLine,
} from "recharts";
import {
  Calculator,
  BarChart2,
  TrendingUp,
  FileSpreadsheet,
  Upload,
  Download,
  Printer,
  Table2,
  Sparkles,
  PieChart as PieIcon,
  Layers,
  ArrowUpDown,
  RefreshCw,
  Copy,
  Check,
  FileText,
  Sliders,
  CheckCircle2,
  Info,
  LineChart as LineChartIcon,
} from "lucide-react";

interface ColumnStats {
  column: string;
  count: number;
  validCount: number;
  mean: number;
  median: number;
  mode: number[];
  variance: number;
  stdDev: number;
  min: number;
  max: number;
  range: number;
  q1: number;
  q3: number;
  iqr: number;
  skewness: number;
  kurtosis: number;
  outliers: number[];
  values: number[];
}

interface RegressionResult {
  xCol: string;
  yCol: string;
  slope: number;
  intercept: number;
  r: number;
  r2: number;
  equation: string;
}

// Preset Datasets for quick exploration
const PRESET_DATASETS = [
  {
    name: "نمرەی خوێندکاران و کاتژمێری خوێندن (Student Grades & Study Hours)",
    data: [
      { Student: "ئاسۆ", StudyHours: 12, ExamScore: 88, Attendance: 95, SleepHours: 7.5 },
      { Student: "دیار", StudyHours: 8, ExamScore: 72, Attendance: 80, SleepHours: 6 },
      { Student: "هەڵمەت", StudyHours: 15, ExamScore: 94, Attendance: 98, SleepHours: 8 },
      { Student: "کاروان", StudyHours: 5, ExamScore: 58, Attendance: 65, SleepHours: 5.5 },
      { Student: "سۆران", StudyHours: 10, ExamScore: 82, Attendance: 90, SleepHours: 7 },
      { Student: "ڕێبین", StudyHours: 7, ExamScore: 68, Attendance: 75, SleepHours: 6.5 },
      { Student: "شوان", StudyHours: 14, ExamScore: 91, Attendance: 92, SleepHours: 8 },
      { Student: "بەهمەن", StudyHours: 4, ExamScore: 50, Attendance: 60, SleepHours: 5 },
      { Student: "لانە", StudyHours: 16, ExamScore: 97, Attendance: 100, SleepHours: 8.5 },
      { Student: "شنۆ", StudyHours: 9, ExamScore: 79, Attendance: 85, SleepHours: 7 },
      { Student: "ئارام", StudyHours: 11, ExamScore: 85, Attendance: 90, SleepHours: 7.5 },
      { Student: "هێرش", StudyHours: 6, ExamScore: 64, Attendance: 70, SleepHours: 6 },
    ],
  },
  {
    name: "فرۆش و بودجەی ڕیکلامی مانگانە (Sales & Ad Budget)",
    data: [
      { Month: "January", AdBudget: 1200, SalesUnits: 450, Revenue: 22500, Customers: 320 },
      { Month: "February", AdBudget: 1500, SalesUnits: 520, Revenue: 26000, Customers: 380 },
      { Month: "March", AdBudget: 1800, SalesUnits: 610, Revenue: 30500, Customers: 430 },
      { Month: "April", AdBudget: 1400, SalesUnits: 490, Revenue: 24500, Customers: 350 },
      { Month: "May", AdBudget: 2200, SalesUnits: 750, Revenue: 37500, Customers: 510 },
      { Month: "June", AdBudget: 2500, SalesUnits: 840, Revenue: 42000, Customers: 580 },
      { Month: "July", AdBudget: 2800, SalesUnits: 920, Revenue: 46000, Customers: 640 },
      { Month: "August", AdBudget: 2000, SalesUnits: 680, Revenue: 34000, Customers: 470 },
      { Month: "September", AdBudget: 1900, SalesUnits: 650, Revenue: 32500, Customers: 450 },
      { Month: "October", AdBudget: 2400, SalesUnits: 800, Revenue: 40000, Customers: 550 },
      { Month: "November", AdBudget: 3100, SalesUnits: 1050, Revenue: 52500, Customers: 710 },
      { Month: "December", AdBudget: 3500, SalesUnits: 1200, Revenue: 60000, Customers: 820 },
    ],
  },
];

// Helper: Statistical Math Computations
function computeStats(values: number[], colName: string): ColumnStats {
  const cleanVals = values.filter((v) => typeof v === "number" && !isNaN(v)).sort((a, b) => a - b);
  const n = cleanVals.length;

  if (n === 0) {
    return {
      column: colName,
      count: 0,
      validCount: 0,
      mean: 0,
      median: 0,
      mode: [],
      variance: 0,
      stdDev: 0,
      min: 0,
      max: 0,
      range: 0,
      q1: 0,
      q3: 0,
      iqr: 0,
      skewness: 0,
      kurtosis: 0,
      outliers: [],
      values: [],
    };
  }

  // Mean
  const sum = cleanVals.reduce((acc, val) => acc + val, 0);
  const mean = sum / n;

  // Median
  const mid = Math.floor(n / 2);
  const median = n % 2 !== 0 ? cleanVals[mid] : (cleanVals[mid - 1] + cleanVals[mid]) / 2;

  // Mode
  const frequency: Record<number, number> = {};
  let maxFreq = 0;
  cleanVals.forEach((val) => {
    frequency[val] = (frequency[val] || 0) + 1;
    if (frequency[val] > maxFreq) maxFreq = frequency[val];
  });
  const mode = maxFreq > 1 ? Object.keys(frequency).filter((k) => frequency[Number(k)] === maxFreq).map(Number) : [];

  // Variance & StdDev (Sample Variance with n - 1)
  const sqDiffSum = cleanVals.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
  const variance = n > 1 ? sqDiffSum / (n - 1) : 0;
  const stdDev = Math.sqrt(variance);

  // Min, Max, Range
  const min = cleanVals[0];
  const max = cleanVals[n - 1];
  const range = max - min;

  // Quartiles (Tukey's method)
  const getPercentile = (p: number) => {
    const idx = (n - 1) * p;
    const base = Math.floor(idx);
    const rest = idx - base;
    if (cleanVals[base + 1] !== undefined) {
      return cleanVals[base] + rest * (cleanVals[base + 1] - cleanVals[base]);
    }
    return cleanVals[base];
  };
  const q1 = getPercentile(0.25);
  const q3 = getPercentile(0.75);
  const iqr = q3 - q1;

  // Outliers: < Q1 - 1.5*IQR or > Q3 + 1.5*IQR
  const lowerBound = q1 - 1.5 * iqr;
  const upperBound = q3 + 1.5 * iqr;
  const outliers = cleanVals.filter((v) => v < lowerBound || v > upperBound);

  // Skewness & Kurtosis
  let m3Sum = 0;
  let m4Sum = 0;
  cleanVals.forEach((v) => {
    m3Sum += Math.pow((v - mean) / (stdDev || 1), 3);
    m4Sum += Math.pow((v - mean) / (stdDev || 1), 4);
  });
  const skewness = n > 2 ? (n / ((n - 1) * (n - 2))) * m3Sum : 0;
  const kurtosis = n > 3 ? (m4Sum / n) - 3 : 0;

  return {
    column: colName,
    count: values.length,
    validCount: n,
    mean,
    median,
    mode,
    variance,
    stdDev,
    min,
    max,
    range,
    q1,
    q3,
    iqr,
    skewness,
    kurtosis,
    outliers,
    values: cleanVals,
  };
}

// Compute Pearson Correlation between two columns
function computeCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  if (n <= 1) return 0;

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += x[i];
    sumY += y[i];
    sumXY += x[i] * y[i];
    sumX2 += x[i] * x[i];
    sumY2 += y[i] * y[i];
  }

  const num = n * sumXY - sumX * sumY;
  const den = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
  if (den === 0) return 0;
  return num / den;
}

// Compute Linear Regression y = mx + b
function computeLinearRegression(x: number[], y: number[], xName: string, yName: string): RegressionResult {
  const n = Math.min(x.length, y.length);
  if (n <= 1) {
    return { xCol: xName, yCol: yName, slope: 0, intercept: 0, r: 0, r2: 0, equation: "y = 0" };
  }

  const meanX = x.reduce((a, b) => a + b, 0) / n;
  const meanY = y.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (x[i] - meanX) * (y[i] - meanY);
    den += Math.pow(x[i] - meanX, 2);
  }

  const slope = den !== 0 ? num / den : 0;
  const intercept = meanY - slope * meanX;
  const r = computeCorrelation(x, y);
  const r2 = Math.pow(r, 2);

  const sign = intercept >= 0 ? "+" : "-";
  const equation = `y = ${slope.toFixed(3)}x ${sign} ${Math.abs(intercept).toFixed(3)}`;

  return {
    xCol: xName,
    yCol: yName,
    slope,
    intercept,
    r,
    r2,
    equation,
  };
}

export function StatisticsLab() {
  const [dataset, setDataset] = useState<any[]>(PRESET_DATASETS[0].data);
  const [datasetName, setDatasetName] = useState<string>("Student Grades & Study Hours");
  const [activeTab, setActiveTab] = useState<"summary" | "charts" | "regression" | "correlation" | "report">("summary");
  const [selectedCol, setSelectedCol] = useState<string>("ExamScore");
  const [regXCol, setRegXCol] = useState<string>("StudyHours");
  const [regYCol, setRegYCol] = useState<string>("ExamScore");
  const [predictX, setPredictX] = useState<number>(13);
  const [chartType, setChartType] = useState<"histogram" | "scatter" | "line" | "area">("histogram");
  const [copiedReport, setCopiedReport] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Extract Numeric Columns
  const numericColumns = useMemo(() => {
    if (!dataset || dataset.length === 0) return [];
    const keys = Object.keys(dataset[0]);
    return keys.filter((key) => {
      const vals = dataset.map((d) => d[key]);
      const validCount = vals.filter((v) => typeof v === "number" && !isNaN(v)).length;
      return validCount > dataset.length * 0.5;
    });
  }, [dataset]);

  // Make sure selected column is valid
  useEffect(() => {
    if (numericColumns.length > 0 && !numericColumns.includes(selectedCol)) {
      setSelectedCol(numericColumns[0]);
    }
    if (numericColumns.length >= 2) {
      if (!numericColumns.includes(regXCol)) setRegXCol(numericColumns[0]);
      if (!numericColumns.includes(regYCol)) setRegYCol(numericColumns[1]);
    }
  }, [numericColumns]);

  // Compute stats for all numeric columns
  const allStats = useMemo(() => {
    const map: Record<string, ColumnStats> = {};
    numericColumns.forEach((col) => {
      const rawVals = dataset.map((d) => Number(d[col])).filter((v) => !isNaN(v));
      map[col] = computeStats(rawVals, col);
    });
    return map;
  }, [dataset, numericColumns]);

  const currentStats = allStats[selectedCol] || null;

  // Compute Linear Regression
  const regression = useMemo(() => {
    if (!regXCol || !regYCol || !dataset.length) return null;
    const xVals: number[] = [];
    const yVals: number[] = [];
    dataset.forEach((row) => {
      const x = Number(row[regXCol]);
      const y = Number(row[regYCol]);
      if (!isNaN(x) && !isNaN(y)) {
        xVals.push(x);
        yVals.push(y);
      }
    });
    return computeLinearRegression(xVals, yVals, regXCol, regYCol);
  }, [dataset, regXCol, regYCol]);

  // Histogram Data for Selected Column
  const histogramData = useMemo(() => {
    if (!currentStats || currentStats.values.length === 0) return [];
    const vals = currentStats.values;
    const binCount = Math.min(8, Math.max(4, Math.ceil(Math.sqrt(vals.length))));
    const binWidth = (currentStats.range || 1) / binCount;

    const bins: { binRange: string; count: number; min: number; max: number }[] = [];
    for (let i = 0; i < binCount; i++) {
      const bMin = currentStats.min + i * binWidth;
      const bMax = i === binCount - 1 ? currentStats.max : bMin + binWidth;
      const count = vals.filter((v) => (i === binCount - 1 ? v >= bMin && v <= bMax : v >= bMin && v < bMax)).length;
      bins.push({
        binRange: `${bMin.toFixed(1)} - ${bMax.toFixed(1)}`,
        count,
        min: bMin,
        max: bMax,
      });
    }
    return bins;
  }, [currentStats]);

  // Scatter / Regression chart points
  const scatterData = useMemo(() => {
    if (!regression) return [];
    return dataset
      .map((row, idx) => ({
        index: idx + 1,
        x: Number(row[regXCol]),
        y: Number(row[regYCol]),
        predictedY: Number((regression.slope * Number(row[regXCol]) + regression.intercept).toFixed(2)),
        label: row.Student || row.Month || `Item ${idx + 1}`,
      }))
      .filter((d) => !isNaN(d.x) && !isNaN(d.y))
      .sort((a, b) => a.x - b.x);
  }, [dataset, regression, regXCol, regYCol]);

  // Correlation Matrix
  const correlationMatrix = useMemo(() => {
    const matrix: Record<string, Record<string, number>> = {};
    numericColumns.forEach((c1) => {
      matrix[c1] = {};
      const v1 = dataset.map((d) => Number(d[c1])).filter((v) => !isNaN(v));
      numericColumns.forEach((c2) => {
        const v2 = dataset.map((d) => Number(d[c2])).filter((v) => !isNaN(v));
        matrix[c1][c2] = computeCorrelation(v1, v2);
      });
    });
    return matrix;
  }, [dataset, numericColumns]);

  // File Upload Parser (Excel / CSV / JSON)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const dataBuffer = evt.target?.result;
        const workbook = XLSX.read(dataBuffer, { type: "binary" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet);

        if (json && json.length > 0) {
          setDataset(json);
          setDatasetName(file.name.replace(/\.[^/.]+$/, ""));
          const firstRow = json[0] as Record<string, any>;
          const keys = Object.keys(firstRow);
          const numKey = keys.find((k) => typeof firstRow[k] === "number") || keys[0];
          setSelectedCol(numKey);
        }
      } catch (err) {
        console.error("Failed to parse dataset file:", err);
      }
    };
    reader.readAsBinaryString(file);
  };

  // Generate Formatted Academic Markdown Report
  const generateReportText = () => {
    let report = `# راپۆرتی شیکاری ئاماری زانستی (Statistical Analysis Report)\n`;
    report += `**ناوی داتاسێت:** ${datasetName}\n`;
    report += `**ژمارەی تۆمارەکان (Sample Size N):** ${dataset.length}\n`;
    report += `**بەروار:** ${new Date().toLocaleDateString()}\n\n`;
    report += `---\n\n`;

    report += `## ١. خشتەی ئاماری وەسفی (Descriptive Statistics Table)\n\n`;
    report += `| ستوون (Variable) | N | ناوەند (Mean) | نێوەڕاست (Median) | لادانی پێوانەیی (SD) | جیاوازی (Variance) | کەمترین (Min) | زۆرترین (Max) | چارەکی ١ (Q1) | چارەکی ٣ (Q3) | لاری (Skewness) |\n`;
    report += `|---|---|---|---|---|---|---|---|---|---|---|\n`;
    numericColumns.forEach((col) => {
      const s = allStats[col];
      if (s) {
        report += `| **${col}** | ${s.validCount} | ${s.mean.toFixed(2)} | ${s.median.toFixed(2)} | ${s.stdDev.toFixed(2)} | ${s.variance.toFixed(2)} | ${s.min} | ${s.max} | ${s.q1.toFixed(2)} | ${s.q3.toFixed(2)} | ${s.skewness.toFixed(2)} |\n`;
      }
    });

    if (regression) {
      report += `\n## ٢. شیکاری ڕیگرێشنی هێڵی (Linear Regression Model)\n\n`;
      report += `- **گۆڕاوی سەربەخۆ (X):** ${regXCol}\n`;
      report += `- **گۆڕاوی پاشکۆ (Y):** ${regYCol}\n`;
      report += `- **هاوکێشەی مۆدێل:** \`${regression.equation}\`\n`;
      report += `- **هاوکۆلکەی پەیوەندی (Pearson r):** ${regression.r.toFixed(4)}\n`;
      report += `- **هاوکۆلکەی دیاریکردن (R²):** ${(regression.r2 * 100).toFixed(2)}% (واتە ڕێژەی گۆڕانکاری ڕوونکراوە)\n`;
    }

    report += `\n## ٣. دەستنیشانکردنی داتای نامۆ (Outliers Detection)\n\n`;
    numericColumns.forEach((col) => {
      const s = allStats[col];
      if (s && s.outliers.length > 0) {
        report += `- **${col}:** داتای نامۆ دۆزرایەوە [${s.outliers.join(", ")}]\n`;
      } else {
        report += `- **${col}:** هیچ داتایەکی نامۆ (Outlier) نەدۆزرایەوە (داتاکان ڕێکوپێکن).\n`;
      }
    });

    report += `\n---\n*ڕاپۆرتی ئامادەکراو لەلایەن پلاتفۆرمی کورتەیا AI — Statistics Lab*`;
    return report;
  };

  const copyReport = () => {
    const text = generateReportText();
    navigator.clipboard.writeText(text);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Dataset Uploader */}
      <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 text-xs font-bold mb-2">
              <Calculator className="w-3.5 h-3.5" /> تاقیگەی ئامار و شیکاری پێشکەوتووی داتا
            </div>
            <h2 className="text-xl md:text-2xl font-extrabold text-foreground">
              Statistics Lab & Data Science Engine
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              accept=".csv,.xlsx,.xls,.json"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="py-2.5 px-4 rounded-xl bg-primary text-primary-foreground text-xs font-bold flex items-center gap-2 shadow-sm hover:opacity-95 transition cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              بارکردنی داتاسێت (CSV / Excel)
            </button>

            {/* Presets dropdown */}
            <select
              onChange={(e) => {
                const idx = Number(e.target.value);
                if (PRESET_DATASETS[idx]) {
                  setDataset(PRESET_DATASETS[idx].data);
                  setDatasetName(PRESET_DATASETS[idx].name);
                }
              }}
              className="h-10 px-3 rounded-xl bg-secondary border border-border text-xs font-bold"
            >
              <option value="0">نموونەی ١: خوێندکاران و نمرە</option>
              <option value="1">نموونەی ٢: فرۆش و ڕیکلامی مانگانە</option>
            </select>
          </div>
        </div>

        {/* Dataset Summary Pill */}
        <div className="p-3.5 rounded-2xl bg-secondary/40 border border-border flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-primary" />
            <span className="font-bold text-foreground">داتاسێتی چالاک:</span>
            <span className="font-mono text-primary font-extrabold">{datasetName}</span>
          </div>
          <div className="flex items-center gap-4 text-muted-foreground font-mono">
            <span>ژمارەی ڕیزەکان (Rows): <strong className="text-foreground">{dataset.length}</strong></span>
            <span>ستوونە ژمارەییەکان: <strong className="text-foreground">{numericColumns.length}</strong></span>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex gap-1.5 overflow-x-auto p-1.5 rounded-2xl bg-secondary/80 border border-border no-scrollbar">
        {[
          { id: "summary", label: "ئاماری وەسفی (Summary Stats)", icon: Table2 },
          { id: "charts", label: "خشتە و دیاگرامەکان (Charts)", icon: BarChart2 },
          { id: "regression", label: "ڕیگرێشن و پێشبینی (Regression)", icon: TrendingUp },
          { id: "correlation", label: "هاوکۆلکەی پەیوەندی (Correlation)", icon: Layers },
          { id: "report", label: "ڕاپۆرتی زانستی (Academic Report)", icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`shrink-0 py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                isActive
                  ? "bg-primary text-primary-foreground shadow-sm font-extrabold"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: DESCRIPTIVE SUMMARY STATS */}
      {activeTab === "summary" && (
        <div className="space-y-6 animate-in fade-in-0 duration-200">
          {/* Select Target Column */}
          <div className="p-4 rounded-2xl bg-card border border-border flex items-center justify-between flex-wrap gap-3">
            <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-primary" /> هەڵبژاردنی ستوونی ژمارەیی بۆ شیکاری ورد:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {numericColumns.map((col) => (
                <button
                  key={col}
                  onClick={() => setSelectedCol(col)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer border ${
                    selectedCol === col
                      ? "bg-primary text-primary-foreground border-primary shadow-xs"
                      : "bg-secondary border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {col}
                </button>
              ))}
            </div>
          </div>

          {currentStats && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {[
                { label: "ناوەند (Mean)", val: currentStats.mean.toFixed(2), desc: "تێکڕای ژمێرەیی", highlight: true },
                { label: "نێوەڕاست (Median)", val: currentStats.median.toFixed(2), desc: "خاڵی نێوەڕاست (50%)", highlight: true },
                { label: "باو (Mode)", val: currentStats.mode.length > 0 ? currentStats.mode.join(", ") : "بێ باو", desc: "باوترین داتای دوبارەبوو" },
                { label: "لادانی پێوانەیی (SD)", val: currentStats.stdDev.toFixed(2), desc: "Standard Deviation (s)", highlight: true },
                { label: "جیاوازی (Variance)", val: currentStats.variance.toFixed(2), desc: "Sample Variance (s²)" },
                { label: "مەودا (Range)", val: currentStats.range.toFixed(2), desc: "Max - Min" },
                { label: "کەمترین (Min)", val: currentStats.min.toString(), desc: "نزمترین ژمارە" },
                { label: "زۆرترین (Max)", val: currentStats.max.toString(), desc: "بەرزترین ژمارە" },
                { label: "چارەکی یەکەم (Q1)", val: currentStats.q1.toFixed(2), desc: "25th Percentile" },
                { label: "چارەکی سێیەم (Q3)", val: currentStats.q3.toFixed(2), desc: "75th Percentile" },
                { label: "مەودای چارەکان (IQR)", val: currentStats.iqr.toFixed(2), desc: "Q3 - Q1" },
                { label: "لاری (Skewness)", val: currentStats.skewness.toFixed(2), desc: currentStats.skewness > 0 ? "ڕاست-لار (Right)" : currentStats.skewness < 0 ? "چەپ-لار (Left)" : "هاوسەنگ" },
              ].map((card, i) => (
                <div
                  key={i}
                  className={`p-4 rounded-2xl border transition ${
                    card.highlight
                      ? "bg-primary/5 border-primary/30 ring-1 ring-primary/20"
                      : "bg-card border-border"
                  }`}
                >
                  <span className="text-[11px] font-bold text-muted-foreground block mb-1">{card.label}</span>
                  <span className="text-xl font-black font-mono text-foreground block mb-0.5">{card.val}</span>
                  <span className="text-[10px] text-muted-foreground block">{card.desc}</span>
                </div>
              ))}
            </div>
          )}

          {/* Full Descriptive Table for All Columns */}
          <div className="p-6 rounded-3xl bg-card border border-border shadow-sm space-y-4">
            <h3 className="text-sm font-extrabold text-foreground flex items-center gap-2">
              <Table2 className="w-4 h-4 text-primary" /> خشتەی بەراوردکاری سەرجەم ستوونەکان (All Variables Summary)
            </h3>
            <div className="overflow-x-auto rounded-2xl border border-border">
              <table className="w-full text-right text-xs">
                <thead className="bg-secondary/40 border-b border-border font-bold text-foreground">
                  <tr>
                    <th className="p-3">ستوون (Variable)</th>
                    <th className="p-3 text-center">N</th>
                    <th className="p-3 text-center">Mean (ناوەند)</th>
                    <th className="p-3 text-center">Median</th>
                    <th className="p-3 text-center">Std Dev (SD)</th>
                    <th className="p-3 text-center">Min</th>
                    <th className="p-3 text-center">Max</th>
                    <th className="p-3 text-center">Q1</th>
                    <th className="p-3 text-center">Q3</th>
                    <th className="p-3 text-center">IQR</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/60">
                  {numericColumns.map((col) => {
                    const s = allStats[col];
                    if (!s) return null;
                    return (
                      <tr key={col} className="hover:bg-secondary/20 transition font-mono">
                        <td className="p-3 font-bold text-foreground font-sans">{col}</td>
                        <td className="p-3 text-center">{s.validCount}</td>
                        <td className="p-3 text-center font-bold text-primary">{s.mean.toFixed(2)}</td>
                        <td className="p-3 text-center">{s.median.toFixed(2)}</td>
                        <td className="p-3 text-center">{s.stdDev.toFixed(2)}</td>
                        <td className="p-3 text-center">{s.min}</td>
                        <td className="p-3 text-center">{s.max}</td>
                        <td className="p-3 text-center">{s.q1.toFixed(2)}</td>
                        <td className="p-3 text-center">{s.q3.toFixed(2)}</td>
                        <td className="p-3 text-center">{s.iqr.toFixed(2)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CHARTS & VISUALIZATIONS */}
      {activeTab === "charts" && (
        <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm space-y-6 animate-in fade-in-0 duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-extrabold text-foreground">
                خشتە و دیاگرامی دابەشبوون (Distribution Charts)
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                بینینی فرێکوێنسی و دابەشبوونی داتای ستوونی <strong className="text-foreground">{selectedCol}</strong>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedCol}
                onChange={(e) => setSelectedCol(e.target.value)}
                className="h-9 px-3 rounded-xl bg-secondary border border-border text-xs font-bold font-mono"
              >
                {numericColumns.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Histogram Chart */}
          <div className="h-80 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={histogramData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="binRange" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: "var(--color-card)", borderColor: "var(--color-border)", borderRadius: "12px" }}
                  formatter={(val) => [`${val} تۆمار`, "ژمارەی فرێکوێنسی"]}
                />
                <Bar dataKey="count" fill="var(--color-primary, #6366f1)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* TAB 3: LINEAR REGRESSION & PREDICTION */}
      {activeTab === "regression" && regression && (
        <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm space-y-6 animate-in fade-in-0 duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold mb-2">
                <TrendingUp className="w-3.5 h-3.5" /> شیکاری پەیوەندی هێڵی و مۆدێلی پێشبینیکەر
              </div>
              <h3 className="text-xl font-extrabold text-foreground">Linear Regression Analysis</h3>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-muted-foreground">X (سەربەخۆ):</span>
              <select
                value={regXCol}
                onChange={(e) => setRegXCol(e.target.value)}
                className="h-8 px-2 rounded-lg bg-secondary border border-border text-xs font-bold"
              >
                {numericColumns.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>

              <span className="font-bold text-muted-foreground mr-2">Y (پاشکۆ):</span>
              <select
                value={regYCol}
                onChange={(e) => setRegYCol(e.target.value)}
                className="h-8 px-2 rounded-lg bg-secondary border border-border text-xs font-bold"
              >
                {numericColumns.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Regression Formula Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
              <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 block mb-1">
                هاوکێشەی ڕیگرێشن (Equation):
              </span>
              <span className="text-lg font-black font-mono text-emerald-600 dark:text-emerald-400">
                {regression.equation}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-secondary/40 border border-border">
              <span className="text-[11px] font-bold text-muted-foreground block mb-1">
                هاوکۆلکەی دیاریکردن (R²):
              </span>
              <span className="text-lg font-black font-mono text-foreground">
                {(regression.r2 * 100).toFixed(2)}%
              </span>
              <span className="text-[10px] text-muted-foreground block">توانای ڕوونکردنەوەی مۆدێل</span>
            </div>

            <div className="p-4 rounded-2xl bg-secondary/40 border border-border">
              <span className="text-[11px] font-bold text-muted-foreground block mb-1">
                پەیوەندی (Pearson r):
              </span>
              <span className="text-lg font-black font-mono text-primary">
                {regression.r.toFixed(4)}
              </span>
              <span className="text-[10px] text-muted-foreground block">
                {regression.r > 0.7 ? "پەیوەندی بەهێزی ئەرێنی" : regression.r < -0.7 ? "پەیوەندی بەهێزی نەرێنی" : "پەیوەندی مامناوەند"}
              </span>
            </div>
          </div>

          {/* Interactive Prediction Calculator */}
          <div className="p-5 rounded-2xl bg-secondary/30 border border-border space-y-3">
            <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-primary" /> تاقیکەرەوە و پێشبینیکەری خێرا (Predictor):
            </span>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold">ئەگەر {regXCol} =</span>
                <input
                  type="number"
                  value={predictX}
                  onChange={(e) => setPredictX(Number(e.target.value))}
                  className="w-24 h-9 px-2 text-center font-mono rounded-lg bg-background border border-border text-xs font-bold"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold">ئەوا {regYCol} پێشبینیکراو دەبێتە:</span>
                <span className="text-sm font-black font-mono text-emerald-600 dark:text-emerald-400 px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                  {(regression.slope * predictX + regression.intercept).toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Scatter Chart with Regression Line */}
          <div className="h-80 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scatterData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="x" name={regXCol} tick={{ fontSize: 11 }} />
                <YAxis dataKey="y" name={regYCol} tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: "var(--color-card)", borderColor: "var(--color-border)", borderRadius: "12px" }}
                  formatter={(val, name) => [val, name === "y" ? `Actual ${regYCol}` : `Predicted ${regYCol}`]}
                />
                <Legend />
                <Line type="monotone" dataKey="predictedY" stroke="#10b981" strokeWidth={2.5} dot={false} name={`هێڵی ڕیگرێشن (Trend Line)`} />
                <Line type="monotone" dataKey="y" stroke="var(--color-primary, #6366f1)" strokeWidth={0} dot={{ r: 5, fill: "var(--color-primary, #6366f1)" }} name={`داتای ڕاستەقینە (${regYCol})`} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* TAB 4: CORRELATION MATRIX */}
      {activeTab === "correlation" && (
        <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm space-y-6 animate-in fade-in-0 duration-200">
          <div>
            <h3 className="text-base font-extrabold text-foreground">
              ماتریسی پەیوەندی نێوان گۆڕاوەکان (Pearson Correlation Matrix)
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              بەهای (1+) پەیوەندی تەواوی ئەرێنی دەگەیەنێت، (-1) پەیوەندی تەواوی نەرێنی، و (0) نەبوونی پەیوەندی.
            </p>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-border">
            <table className="w-full text-center text-xs">
              <thead className="bg-secondary/50 border-b border-border font-bold text-foreground">
                <tr>
                  <th className="p-3 text-right">Variable</th>
                  {numericColumns.map((col) => (
                    <th key={col} className="p-3 font-mono">{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/60 font-mono">
                {numericColumns.map((rCol) => (
                  <tr key={rCol}>
                    <td className="p-3 text-right font-bold text-foreground font-sans">{rCol}</td>
                    {numericColumns.map((cCol) => {
                      const val = correlationMatrix[rCol]?.[cCol] ?? 0;
                      const isSelf = rCol === cCol;
                      const isStrong = Math.abs(val) >= 0.7 && !isSelf;
                      return (
                        <td
                          key={cCol}
                          className={`p-3 font-bold transition ${
                            isSelf
                              ? "bg-secondary/40 text-muted-foreground"
                              : isStrong
                              ? val > 0
                                ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
                                : "bg-rose-500/15 text-rose-600 dark:text-rose-400"
                              : "text-foreground"
                          }`}
                        >
                          {val.toFixed(3)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: AUTOMATED COMPREHENSIVE REPORT */}
      {activeTab === "report" && (
        <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm space-y-6 animate-in fade-in-0 duration-200">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs font-bold mb-2">
                <FileText className="w-3.5 h-3.5" /> ڕاپۆرتی زانستی ئامادەکراوی ئاماری
              </div>
              <h3 className="text-xl font-extrabold text-foreground">Statistical Report Generator</h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={copyReport}
                className="py-2.5 px-4 rounded-xl bg-primary text-primary-foreground text-xs font-bold flex items-center gap-1.5 shadow-sm hover:opacity-95 transition cursor-pointer"
              >
                {copiedReport ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedReport ? "کۆپی کرا!" : "کۆپیکردنی ڕاپۆرت (Markdown)"}
              </button>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-secondary/30 border border-border text-xs leading-relaxed font-mono whitespace-pre-wrap select-all max-h-[500px] overflow-y-auto">
            {generateReportText()}
          </div>
        </div>
      )}
    </div>
  );
}
