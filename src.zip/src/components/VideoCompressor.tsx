import { useState, useRef, useEffect } from "react";
import {
  Upload,
  Minimize2,
  Download,
  X,
  FileVideo,
  ArrowRight,
  Loader2,
  CheckCircle2,
  AlertCircle,
  HardDrive,
  Sparkles,
  Zap,
  Sliders,
  Check,
  StopCircle,
} from "lucide-react";

export function VideoCompressor() {
  const [file, setFile] = useState<File | null>(null);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [compressionPreset, setCompressionPreset] = useState<"high" | "balanced" | "light">("balanced");
  const [targetResolution, setTargetResolution] = useState<"original" | "720p" | "480p" | "360p">("720p");
  const [converting, setConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState("");
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [outputSize, setOutputSize] = useState<number>(0);
  const [outputMime, setOutputMime] = useState<string>("video/mp4");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const fileBlobRef = useRef<Blob | null>(null);
  const activeVideoRef = useRef<HTMLVideoElement | null>(null);
  const activeRecorderRef = useRef<MediaRecorder | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (fileUrl) URL.revokeObjectURL(fileUrl);
      if (outputUrl) URL.revokeObjectURL(outputUrl);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (activeRecorderRef.current && activeRecorderRef.current.state !== "inactive") {
        activeRecorderRef.current.stop();
      }
    };
  }, [fileUrl, outputUrl]);

  const handleFileSelect = (f: File) => {
    if (fileUrl) URL.revokeObjectURL(fileUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    setFile(f);
    const blob = f.slice(0, f.size, f.type);
    fileBlobRef.current = blob;
    const url = URL.createObjectURL(blob);
    setFileUrl(url);

    setOutputUrl(null);
    setProgress(0);
    setConverting(false);
    setErrorMsg(null);
  };

  const getEstimatedSize = () => {
    if (!file) return { size: 0, text: "0 MB", percentSaved: 0 };
    const originalMB = file.size / (1024 * 1024);

    let factor = 0.45; // Balanced
    if (compressionPreset === "high") factor = 0.22; // ~78% reduction
    if (compressionPreset === "light") factor = 0.65; // ~35% reduction

    if (targetResolution === "480p") factor *= 0.7;
    if (targetResolution === "360p") factor *= 0.5;

    const finalMB = Math.max(0.5, originalMB * factor);
    const saved = Math.min(95, Math.max(10, Math.round(((originalMB - finalMB) / originalMB) * 100)));

    return {
      size: finalMB,
      text: finalMB > 1000 ? `${(finalMB / 1024).toFixed(2)} GB` : `${finalMB.toFixed(1)} MB`,
      percentSaved: saved,
    };
  };

  // Real client-side video encoder & compressor
  const compressVideoReal = async (
    videoUrl: string,
    resolution: "original" | "720p" | "480p" | "360p",
    preset: "high" | "balanced" | "light"
  ): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement("video");
      activeVideoRef.current = video;
      video.src = videoUrl;
      video.crossOrigin = "anonymous";
      video.muted = true;
      video.playsInline = true;

      video.onloadedmetadata = () => {
        let targetWidth = video.videoWidth || 1280;
        let targetHeight = video.videoHeight || 720;
        const aspectRatio = targetWidth / targetHeight;

        if (resolution === "720p" && targetHeight > 720) {
          targetHeight = 720;
          targetWidth = Math.round(targetHeight * aspectRatio);
        } else if (resolution === "480p" && targetHeight > 480) {
          targetHeight = 480;
          targetWidth = Math.round(targetHeight * aspectRatio);
        } else if (resolution === "360p" && targetHeight > 360) {
          targetHeight = 360;
          targetWidth = Math.round(targetHeight * aspectRatio);
        }

        targetWidth = Math.floor(targetWidth / 2) * 2;
        targetHeight = Math.floor(targetHeight / 2) * 2;

        let videoBitsPerSecond = 1_200_000; // Balanced (1.2 Mbps)
        if (preset === "high") videoBitsPerSecond = 600_000; // 600 kbps (high compression)
        if (preset === "light") videoBitsPerSecond = 2_200_000; // 2.2 Mbps

        if (resolution === "480p") videoBitsPerSecond = Math.min(videoBitsPerSecond, 800_000);
        if (resolution === "360p") videoBitsPerSecond = Math.min(videoBitsPerSecond, 450_000);

        const canvas = document.createElement("canvas");
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas context failed"));

        const canvasStream = canvas.captureStream(25);

        try {
          const audioStream = (video as any).captureStream ? (video as any).captureStream() : (video as any).mozCaptureStream ? (video as any).mozCaptureStream() : null;
          if (audioStream && audioStream.getAudioTracks().length > 0) {
            audioStream.getAudioTracks().forEach((track: any) => canvasStream.addTrack(track));
          }
        } catch (e) {
          console.warn("Audio track capture not available", e);
        }

        let chosenMime = "video/webm;codecs=vp8,opus";
        if (MediaRecorder.isTypeSupported("video/mp4")) {
          chosenMime = "video/mp4";
        } else if (MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")) {
          chosenMime = "video/webm;codecs=vp9,opus";
        } else if (MediaRecorder.isTypeSupported("video/webm")) {
          chosenMime = "video/webm";
        }

        let recorder: MediaRecorder;
        try {
          recorder = new MediaRecorder(canvasStream, {
            mimeType: chosenMime,
            videoBitsPerSecond,
            audioBitsPerSecond: 96_000,
          });
        } catch (err) {
          recorder = new MediaRecorder(canvasStream);
        }

        activeRecorderRef.current = recorder;
        const chunks: Blob[] = [];

        recorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) {
            chunks.push(e.data);
          }
        };

        recorder.onstop = () => {
          const mime = recorder.mimeType || chosenMime;
          setOutputMime(mime);
          const finalBlob = new Blob(chunks, { type: mime });
          resolve(finalBlob);
        };

        recorder.onerror = (e) => reject(e);

        const duration = video.duration || 10;

        const drawLoop = () => {
          if (!video.paused && !video.ended) {
            ctx.drawImage(video, 0, 0, targetWidth, targetHeight);
            const percent = Math.min(99, Math.round((video.currentTime / duration) * 100));
            setProgress(percent);
            setProgressText(`پەستاندن و کەمکردنەوەی قەبارەی ڤیدیۆ... ${percent}%`);
            animFrameRef.current = requestAnimationFrame(drawLoop);
          }
        };

        video.onended = () => {
          if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
          setProgress(100);
          setProgressText("پەستاندن بە سەرکەوتوویی تەواو بوو!");
          setTimeout(() => {
            if (recorder.state !== "inactive") recorder.stop();
          }, 300);
        };

        // Accelerated playback speed for fast encoding (2x to 3x)
        video.playbackRate = 2.5;

        recorder.start(250);
        video.play().then(() => {
          drawLoop();
        }).catch(reject);
      };

      video.onerror = () => reject(new Error("نەتوانرا ڤیدیۆکە بۆ پەستاندن بخوێنرێتەوە"));
    });
  };

  const startCompression = async () => {
    if (!file || !fileUrl) return;

    setConverting(true);
    setErrorMsg(null);
    setProgress(5);
    setProgressText("دەستپێکردنی بزوێنەری پەستاندنی ڕاستەقینە...");

    try {
      const compressedBlob = await compressVideoReal(fileUrl, targetResolution, compressionPreset);
      
      const url = URL.createObjectURL(compressedBlob);
      setOutputUrl(url);
      setOutputSize(compressedBlob.size);
      setProgress(100);
      setProgressText("پەستاندن بە سەرکەوتوویی تەواو بوو!");
      setConverting(false);
    } catch (err: any) {
      console.error("Compression error:", err);
      setConverting(false);
      setProgress(0);
      setErrorMsg(err?.message || "هەڵەیەک لە کاتی پەستاندنی ڤیدیۆکە ڕوویدا");
    }
  };

  const cancelCompression = () => {
    if (activeVideoRef.current) {
      activeVideoRef.current.pause();
      activeVideoRef.current.src = "";
    }
    if (activeRecorderRef.current && activeRecorderRef.current.state !== "inactive") {
      activeRecorderRef.current.stop();
    }
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    setConverting(false);
    setProgress(0);
    setProgressText("");
  };

  const formatFileSize = (bytes: number) => {
    if (bytes >= 1024 * 1024 * 1024) {
      return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const getSourceExt = () => {
    if (!file) return "";
    return file.name.split(".").pop()?.toUpperCase() || "FILE";
  };

  const getOutputExt = () => {
    if (outputMime.includes("mp4")) return "mp4";
    return "webm";
  };

  const estimated = getEstimatedSize();

  return (
    <div className="space-y-6">
      <div className="p-6 md:p-8 rounded-3xl bg-card border border-border shadow-sm">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold mb-2">
              <Minimize2 className="w-3.5 h-3.5" /> ئامرازی پەستاندنی ڤیدیۆ
            </div>
            <h2 className="text-xl md:text-2xl font-extrabold text-foreground">
              Video Compressor (کەمکردنەوەی قەبارەی ڤیدیۆ)
            </h2>
            <p className="text-xs md:text-sm text-muted-foreground mt-1">
              بچووککردنەوەی قەبارەی فایلی ڤیدیۆی گەورە لە گێگابایت (GB) بۆ مێگابایت (MB) بە شێوەیەکی ڕاستەقینە لەسەر براوزەر.
            </p>
          </div>
        </div>

        {/* File Upload Box */}
        <div className="mb-6">
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFileSelect(f);
            }}
            accept="video/*,.mkv,.avi,.mov,.flv,.webm,.3gp,.ts,.mp4,.mpg"
            className="hidden"
          />

          {!file ? (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                const f = e.dataTransfer.files?.[0];
                if (f) handleFileSelect(f);
              }}
              onClick={() => fileInputRef.current?.click()}
              className={`py-10 px-4 rounded-3xl border-2 border-dashed transition flex flex-col items-center justify-center gap-3 text-center cursor-pointer ${
                dragOver
                  ? "border-emerald-500 bg-emerald-500/5 scale-[0.99]"
                  : "border-border hover:border-emerald-500/50 bg-secondary/20 hover:bg-secondary/40"
              }`}
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shadow-xs">
                <Upload className="w-7 h-7" />
              </div>
              <div>
                <span className="text-sm font-extrabold text-foreground block">
                  فایلی ڤیدیۆکەت لێرە دابنێ یان کلیک بکە
                </span>
                <span className="text-xs text-muted-foreground mt-1 block">
                  پشتگیری هەموو جۆرەکان (MP4, MKV, MOV, AVI, MPG, WebM) تەنانەت قەبارەی گەورەی چەندین GB
                </span>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-secondary/50 border border-emerald-500/30 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                  <FileVideo className="w-6 h-6" />
                </div>
                <div className="text-right min-w-0">
                  <span className="font-extrabold text-sm text-foreground block truncate max-w-[220px] sm:max-w-md">
                    {file.name}
                  </span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 uppercase">
                      {getSourceExt()}
                    </span>
                    <span className="text-[11px] font-bold text-foreground">
                      قەبارەی ڕەسەن: {formatFileSize(file.size)}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setFile(null);
                  if (fileUrl) URL.revokeObjectURL(fileUrl);
                  fileBlobRef.current = null;
                  setFileUrl(null);
                  setOutputUrl(null);
                  setErrorMsg(null);
                  if (fileInputRef.current) fileInputRef.current.value = "";
                }}
                className="p-2 rounded-xl bg-background hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition cursor-pointer"
                title="لابردنی فایل"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Compression Options */}
        {file && (
          <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-emerald-500/10 border border-emerald-500/30 space-y-5 mb-6 animate-in fade-in-0 duration-200">
            {/* Presets */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-foreground block text-right">
                ئاستی کەمکردنەوەی قەبارە (Compression Preset):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  { id: "high", label: "زۆر کەمکردنەوە", desc: "~٧٥٪ کەمتر (بۆ واتسئاپ و ئیمەیڵ)", icon: "🚀" },
                  { id: "balanced", label: "مامناوەند و هاوسەنگ", desc: "~٥٠٪ کەمتر (پێشنیارکراو)", icon: "⚖️" },
                  { id: "light", label: "کوالیتی باڵا", desc: "~٣٠٪ کەمتر (دەستکاری کەم)", icon: "💎" },
                ].map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setCompressionPreset(preset.id as any)}
                    className={`p-3.5 rounded-2xl border text-right transition cursor-pointer flex flex-col justify-between ${
                      compressionPreset === preset.id
                        ? "bg-emerald-500/20 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold ring-2 ring-emerald-500/20 shadow-xs"
                        : "bg-card/80 border-border/70 text-foreground hover:bg-card"
                    }`}
                  >
                    <span className="text-xs font-extrabold block">{preset.icon} {preset.label}</span>
                    <span className="text-[10px] text-muted-foreground block mt-0.5">{preset.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Resolution Downscaling */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-foreground block text-right">
                ڕوونی ڤیدیۆ (Video Resolution):
              </label>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: "original", label: "ڕەسەن (Original)" },
                  { id: "720p", label: "720p HD (سووک)" },
                  { id: "480p", label: "480p SD (زۆر کەم)" },
                  { id: "360p", label: "360p (کەمترین قەبارە)" },
                ].map((res) => (
                  <button
                    key={res.id}
                    onClick={() => setTargetResolution(res.id as any)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      targetResolution === res.id
                        ? "bg-emerald-600 text-white shadow-xs"
                        : "bg-card border border-border text-foreground hover:bg-secondary"
                    }`}
                  >
                    {res.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Live Estimated Savings Bar */}
            <div className="p-3.5 rounded-2xl bg-card border border-emerald-500/30 flex items-center justify-between flex-wrap gap-2 text-xs">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-emerald-500" />
                <span>قەبارەی ڕەسەن: <strong>{formatFileSize(file.size)}</strong></span>
                <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                  خەمڵێنراوی نوێ: ~{estimated.text}
                </span>
              </div>
              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-extrabold text-[11px]">
                🎉 نزیکەی {estimated.percentSaved}٪ پاشەکەوت دەکرێت
              </span>
            </div>
          </div>
        )}

        {/* Action Button */}
        <div className="flex gap-2">
          {converting && (
            <button
              onClick={cancelCompression}
              className="px-4 py-4 rounded-2xl bg-destructive/10 hover:bg-destructive/20 text-destructive font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <StopCircle className="w-4 h-4" />
              <span>ڕاگرتن</span>
            </button>
          )}

          <button
            onClick={startCompression}
            disabled={!file || converting}
            className={`flex-1 py-4 rounded-2xl font-extrabold text-sm text-white flex items-center justify-center gap-2 shadow-lg transition cursor-pointer ${
              !file || converting
                ? "opacity-50 cursor-not-allowed bg-slate-500"
                : "bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 active:scale-[0.99] shadow-emerald-500/25"
            }`}
          >
            {converting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{progressText}</span>
              </>
            ) : (
              <>
                <Minimize2 className="w-5 h-5" />
                <span>پەستاندن و کەمکردنەوەی قەبارەی ڤیدیۆ (دەستپێبکە)</span>
              </>
            )}
          </button>
        </div>

        {/* Progress Bar */}
        {converting && (
          <div className="mt-4 space-y-1.5">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>{progressText}</span>
              <span className="font-mono font-bold text-emerald-600">{progress}%</span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-secondary overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 transition-all duration-300 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMsg && (
          <div className="mt-4 p-4 rounded-2xl bg-destructive/10 border border-destructive/30 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            <div className="text-right min-w-0">
              <p className="font-bold text-sm text-destructive">هەڵەیەک ڕوویدا:</p>
              <p className="text-xs text-muted-foreground mt-0.5">{errorMsg}</p>
            </div>
          </div>
        )}

        {/* Success Output & Download Box */}
        {outputUrl && (
          <div className="mt-6 p-6 rounded-3xl bg-emerald-500/10 border-2 border-emerald-500/30 space-y-4 animate-in fade-in-0 duration-300">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shrink-0">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div className="text-right">
                  <span className="font-extrabold text-sm text-foreground block">
                    ڤیدیۆکە بە سەرکەوتوویی پەستێندرا و قەبارەکەی کەمکرایەوە!
                  </span>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                    <span>قەبارەی نوێی ڕاستەقینە: <strong className="text-emerald-600 dark:text-emerald-400 font-extrabold text-sm">{formatFileSize(outputSize)}</strong></span>
                    {file && file.size > outputSize && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold">
                        {Math.round(((file.size - outputSize) / file.size) * 100)}٪ کەمکرایەوە
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <a
                href={outputUrl}
                download={`${file?.name.replace(/\.[^/.]+$/, "") || "video"}_compressed.${getOutputExt()}`}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm shadow-md transition active:scale-95 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                داگرتنی فایلی کەمکراوە ({formatFileSize(outputSize)})
              </a>
            </div>

            {/* Video Player Preview */}
            <div className="pt-3 border-t border-emerald-500/20">
              <span className="text-xs font-bold text-muted-foreground block mb-2 text-right">
                پێشبینینی ڤیدیۆی پەستێنراو (Video Preview):
              </span>
              <video controls src={outputUrl} className="w-full max-h-64 rounded-2xl bg-black shadow-md border border-border" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
